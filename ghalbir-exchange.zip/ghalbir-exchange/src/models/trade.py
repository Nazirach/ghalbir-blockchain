from dataclasses import dataclass
from decimal import Decimal
from datetime import datetime
from typing import Optional, List

@dataclass
class Trade:
    id: str
    buyer_order_id: str
    seller_order_id: str
    trading_pair: str
    amount: Decimal
    price: Decimal
    fee: Decimal
    buyer_id: str
    seller_id: str
    created_at: datetime = datetime.now()
    
    def to_dict(self) -> dict:
        """Convert trade to dictionary"""
        return {
            "id": self.id,
            "buyer_order_id": self.buyer_order_id,
            "seller_order_id": self.seller_order_id,
            "trading_pair": self.trading_pair,
            "amount": str(self.amount),
            "price": str(self.price),
            "fee": str(self.fee),
            "buyer_id": self.buyer_id,
            "seller_id": self.seller_id,
            "created_at": self.created_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Trade':
        """Create trade from dictionary"""
        return cls(
            id=data["id"],
            buyer_order_id=data["buyer_order_id"],
            seller_order_id=data["seller_order_id"],
            trading_pair=data["trading_pair"],
            amount=Decimal(data["amount"]),
            price=Decimal(data["price"]),
            fee=Decimal(data["fee"]),
            buyer_id=data["buyer_id"],
            seller_id=data["seller_id"],
            created_at=datetime.fromisoformat(data["created_at"])
        )
