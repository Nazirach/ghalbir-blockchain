from dataclasses import dataclass
from enum import Enum
from decimal import Decimal
from datetime import datetime
from typing import Optional, List

class OrderType(Enum):
    LIMIT = "limit"
    MARKET = "market"
    STOP_LIMIT = "stop_limit"

class OrderSide(Enum):
    BUY = "buy"
    SELL = "sell"

class OrderStatus(Enum):
    PENDING = "pending"
    FILLED = "filled"
    PARTIALLY_FILLED = "partially_filled"
    CANCELLED = "cancelled"

@dataclass
class Order:
    id: str
    user_id: str
    side: OrderSide
    order_type: OrderType
    trading_pair: str
    amount: Decimal
    price: Decimal
    status: OrderStatus
    filled_amount: Decimal = Decimal('0')
    remaining_amount: Optional[Decimal] = None
    created_at: datetime = datetime.now()
    updated_at: datetime = datetime.now()
    
    def __post_init__(self):
        if self.remaining_amount is None:
            self.remaining_amount = self.amount
    
    def fill(self, amount: Decimal, price: Decimal) -> None:
        """Fill order with specified amount and price"""
        if amount > self.remaining_amount:
            raise ValueError(f"Fill amount {amount} exceeds remaining amount {self.remaining_amount}")
        
        self.filled_amount += amount
        self.remaining_amount -= amount
        self.updated_at = datetime.now()
        
        if self.remaining_amount == Decimal('0'):
            self.status = OrderStatus.FILLED
        else:
            self.status = OrderStatus.PARTIALLY_FILLED
    
    def cancel(self) -> None:
        """Cancel the order"""
        if self.status in [OrderStatus.FILLED, OrderStatus.CANCELLED]:
            raise ValueError(f"Cannot cancel order with status {self.status}")
        
        self.status = OrderStatus.CANCELLED
        self.updated_at = datetime.now()
    
    def is_active(self) -> bool:
        """Check if order is active"""
        return self.status in [OrderStatus.PENDING, OrderStatus.PARTIALLY_FILLED]
    
    def to_dict(self) -> dict:
        """Convert order to dictionary"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "side": self.side.value,
            "order_type": self.order_type.value,
            "trading_pair": self.trading_pair,
            "amount": str(self.amount),
            "price": str(self.price),
            "status": self.status.value,
            "filled_amount": str(self.filled_amount),
            "remaining_amount": str(self.remaining_amount),
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Order':
        """Create order from dictionary"""
        return cls(
            id=data["id"],
            user_id=data["user_id"],
            side=OrderSide(data["side"]),
            order_type=OrderType(data["order_type"]),
            trading_pair=data["trading_pair"],
            amount=Decimal(data["amount"]),
            price=Decimal(data["price"]),
            status=OrderStatus(data["status"]),
            filled_amount=Decimal(data["filled_amount"]),
            remaining_amount=Decimal(data["remaining_amount"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"])
        )
