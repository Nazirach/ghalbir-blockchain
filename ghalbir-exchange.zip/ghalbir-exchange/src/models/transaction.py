from dataclasses import dataclass
from enum import Enum
from decimal import Decimal
from datetime import datetime
from typing import Optional

class TransactionType(Enum):
    DEPOSIT = "deposit"
    WITHDRAWAL = "withdrawal"

class TransactionStatus(Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"

@dataclass
class Transaction:
    id: str
    user_id: str
    type: TransactionType
    asset: str
    amount: Decimal
    fee: Decimal
    address: str
    tx_hash: Optional[str] = None
    status: TransactionStatus = TransactionStatus.PENDING
    created_at: datetime = datetime.now()
    updated_at: datetime = datetime.now()
    
    def complete(self, tx_hash: str) -> None:
        """Mark transaction as completed"""
        if self.status != TransactionStatus.PENDING:
            raise ValueError(f"Cannot complete transaction with status {self.status}")
        
        self.status = TransactionStatus.COMPLETED
        self.tx_hash = tx_hash
        self.updated_at = datetime.now()
    
    def fail(self, reason: str = None) -> None:
        """Mark transaction as failed"""
        if self.status != TransactionStatus.PENDING:
            raise ValueError(f"Cannot fail transaction with status {self.status}")
        
        self.status = TransactionStatus.FAILED
        self.updated_at = datetime.now()
    
    def to_dict(self) -> dict:
        """Convert transaction to dictionary"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "type": self.type.value,
            "asset": self.asset,
            "amount": str(self.amount),
            "fee": str(self.fee),
            "address": self.address,
            "tx_hash": self.tx_hash,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Transaction':
        """Create transaction from dictionary"""
        return cls(
            id=data["id"],
            user_id=data["user_id"],
            type=TransactionType(data["type"]),
            asset=data["asset"],
            amount=Decimal(data["amount"]),
            fee=Decimal(data["fee"]),
            address=data["address"],
            tx_hash=data.get("tx_hash"),
            status=TransactionStatus(data["status"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"])
        )
