from dataclasses import dataclass
from decimal import Decimal
from datetime import datetime
from typing import Optional

@dataclass
class Wallet:
    id: str
    user_id: str
    asset: str
    balance: Decimal
    address: str
    created_at: datetime = datetime.now()
    updated_at: datetime = datetime.now()
    
    def deposit(self, amount: Decimal) -> None:
        """Add funds to wallet"""
        if amount <= Decimal('0'):
            raise ValueError("Deposit amount must be positive")
        
        self.balance += amount
        self.updated_at = datetime.now()
    
    def withdraw(self, amount: Decimal) -> None:
        """Remove funds from wallet"""
        if amount <= Decimal('0'):
            raise ValueError("Withdrawal amount must be positive")
        
        if amount > self.balance:
            raise ValueError(f"Insufficient balance: {self.balance} < {amount}")
        
        self.balance -= amount
        self.updated_at = datetime.now()
    
    def has_sufficient_balance(self, amount: Decimal) -> bool:
        """Check if wallet has sufficient balance"""
        return self.balance >= amount
    
    def to_dict(self) -> dict:
        """Convert wallet to dictionary"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "asset": self.asset,
            "balance": str(self.balance),
            "address": self.address,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Wallet':
        """Create wallet from dictionary"""
        return cls(
            id=data["id"],
            user_id=data["user_id"],
            asset=data["asset"],
            balance=Decimal(data["balance"]),
            address=data["address"],
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"])
        )
