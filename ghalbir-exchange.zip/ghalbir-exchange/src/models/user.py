from dataclasses import dataclass
from enum import Enum
from decimal import Decimal
from datetime import datetime
from typing import Optional

class UserStatus(Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    LOCKED = "locked"

class KYCStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"

@dataclass
class User:
    id: str
    email: str
    password_hash: str
    full_name: str
    kyc_status: KYCStatus = KYCStatus.PENDING
    two_factor_enabled: bool = False
    status: UserStatus = UserStatus.ACTIVE
    created_at: datetime = datetime.now()
    updated_at: datetime = datetime.now()
    
    def to_dict(self) -> dict:
        """Convert user to dictionary"""
        return {
            "id": self.id,
            "email": self.email,
            "password_hash": self.password_hash,
            "full_name": self.full_name,
            "kyc_status": self.kyc_status.value,
            "two_factor_enabled": self.two_factor_enabled,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'User':
        """Create user from dictionary"""
        return cls(
            id=data["id"],
            email=data["email"],
            password_hash=data["password_hash"],
            full_name=data["full_name"],
            kyc_status=KYCStatus(data["kyc_status"]),
            two_factor_enabled=data["two_factor_enabled"],
            status=UserStatus(data["status"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"])
        )
    
    def is_active(self) -> bool:
        """Check if user is active"""
        return self.status == UserStatus.ACTIVE
    
    def is_kyc_approved(self) -> bool:
        """Check if user's KYC is approved"""
        return self.kyc_status == KYCStatus.APPROVED
    
    def suspend(self) -> None:
        """Suspend user account"""
        self.status = UserStatus.SUSPENDED
        self.updated_at = datetime.now()
    
    def activate(self) -> None:
        """Activate user account"""
        self.status = UserStatus.ACTIVE
        self.updated_at = datetime.now()
    
    def lock(self) -> None:
        """Lock user account"""
        self.status = UserStatus.LOCKED
        self.updated_at = datetime.now()
    
    def enable_two_factor(self) -> None:
        """Enable two-factor authentication"""
        self.two_factor_enabled = True
        self.updated_at = datetime.now()
    
    def disable_two_factor(self) -> None:
        """Disable two-factor authentication"""
        self.two_factor_enabled = False
        self.updated_at = datetime.now()
    
    def update_kyc_status(self, status: KYCStatus) -> None:
        """Update KYC status"""
        self.kyc_status = status
        self.updated_at = datetime.now()
