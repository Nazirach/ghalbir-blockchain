from typing import Dict, List, Optional, Any
import json
import os
import requests
from web3 import Web3
from eth_account import Account
from eth_account.signers.local import LocalAccount
from eth_account.messages import encode_defunct
import time
from decimal import Decimal

class GhalbirBlockchainConnector:
    """
    Connector class for interacting with the Ghalbir blockchain.
    This class provides methods for interacting with the Ghalbir blockchain,
    including sending transactions, checking balances, and interacting with smart contracts.
    """
    
    def __init__(self, rpc_url: str, chain_id: int, contract_address: str, abi_path: str):
        """
        Initialize the Ghalbir blockchain connector.
        
        Args:
            rpc_url: The URL of the Ghalbir blockchain RPC endpoint
            chain_id: The chain ID of the Ghalbir blockchain
            contract_address: The address of the GBR token contract
            abi_path: Path to the ABI file for the GBR token contract
        """
        self.rpc_url = rpc_url
        self.chain_id = chain_id
        self.contract_address = contract_address
        
        # Initialize Web3 provider
        self.w3 = Web3(Web3.HTTPProvider(rpc_url))
        
        # Check connection
        if not self.w3.is_connected():
            raise ConnectionError(f"Failed to connect to Ghalbir blockchain at {rpc_url}")
        
        # Load contract ABI
        with open(abi_path, 'r') as f:
            contract_abi = json.load(f)
        
        # Initialize contract
        self.contract = self.w3.eth.contract(address=self.w3.to_checksum_address(contract_address), abi=contract_abi)
        
        # Initialize account cache
        self.accounts_cache = {}
    
    def create_wallet(self) -> Dict[str, str]:
        """
        Create a new Ghalbir wallet.
        
        Returns:
            Dict containing the address and private key of the new wallet
        """
        account: LocalAccount = Account.create()
        address = account.address
        private_key = account.key.hex()
        
        return {
            "address": address,
            "private_key": private_key
        }
    
    def import_wallet(self, private_key: str) -> Dict[str, str]:
        """
        Import a wallet using a private key.
        
        Args:
            private_key: The private key of the wallet to import
            
        Returns:
            Dict containing the address and private key of the imported wallet
        """
        account: LocalAccount = Account.from_key(private_key)
        address = account.address
        
        return {
            "address": address,
            "private_key": private_key
        }
    
    def get_balance(self, address: str) -> Decimal:
        """
        Get the GBR token balance of an address.
        
        Args:
            address: The address to check the balance of
            
        Returns:
            The balance of the address in GBR tokens
        """
        checksum_address = self.w3.to_checksum_address(address)
        balance_wei = self.contract.functions.balanceOf(checksum_address).call()
        balance = Decimal(balance_wei) / Decimal(10**18)  # Convert from wei to GBR
        
        return balance
    
    def get_eth_balance(self, address: str) -> Decimal:
        """
        Get the native ETH balance of an address.
        
        Args:
            address: The address to check the balance of
            
        Returns:
            The balance of the address in ETH
        """
        checksum_address = self.w3.to_checksum_address(address)
        balance_wei = self.w3.eth.get_balance(checksum_address)
        balance = Decimal(balance_wei) / Decimal(10**18)  # Convert from wei to ETH
        
        return balance
    
    def transfer(self, from_private_key: str, to_address: str, amount: Decimal) -> Dict[str, Any]:
        """
        Transfer GBR tokens from one address to another.
        
        Args:
            from_private_key: The private key of the sender
            to_address: The address of the recipient
            amount: The amount of GBR tokens to transfer
            
        Returns:
            Dict containing the transaction hash and status
        """
        # Get sender account
        sender_account = Account.from_key(from_private_key)
        sender_address = sender_account.address
        
        # Convert amount to wei
        amount_wei = int(amount * Decimal(10**18))
        
        # Get nonce
        nonce = self.w3.eth.get_transaction_count(sender_address)
        
        # Build transaction
        to_checksum_address = self.w3.to_checksum_address(to_address)
        tx = self.contract.functions.transfer(
            to_checksum_address,
            amount_wei
        ).build_transaction({
            'chainId': self.chain_id,
            'gas': 100000,
            'gasPrice': self.w3.eth.gas_price,
            'nonce': nonce,
        })
        
        # Sign transaction
        signed_tx = self.w3.eth.account.sign_transaction(tx, from_private_key)
        
        # Send transaction
        tx_hash = self.w3.eth.send_raw_transaction(signed_tx.rawTransaction)
        
        # Wait for transaction receipt
        tx_receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash)
        
        return {
            "tx_hash": tx_hash.hex(),
            "status": "success" if tx_receipt.status == 1 else "failed",
            "block_number": tx_receipt.blockNumber,
            "gas_used": tx_receipt.gasUsed
        }
    
    def get_transaction(self, tx_hash: str) -> Dict[str, Any]:
        """
        Get information about a transaction.
        
        Args:
            tx_hash: The hash of the transaction to get information about
            
        Returns:
            Dict containing information about the transaction
        """
        # Get transaction
        tx = self.w3.eth.get_transaction(tx_hash)
        
        # Get transaction receipt
        tx_receipt = self.w3.eth.get_transaction_receipt(tx_hash)
        
        # Check if this is a token transfer
        is_token_transfer = (tx['to'] == self.w3.to_checksum_address(self.contract_address))
        
        result = {
            "tx_hash": tx_hash,
            "from": tx['from'],
            "to": tx['to'],
            "value": Decimal(tx['value']) / Decimal(10**18),
            "gas": tx['gas'],
            "gas_price": Decimal(tx['gasPrice']) / Decimal(10**9),  # Convert to Gwei
            "nonce": tx['nonce'],
            "block_number": tx['blockNumber'],
            "status": "success" if tx_receipt.status == 1 else "failed",
            "gas_used": tx_receipt.gasUsed,
            "is_token_transfer": is_token_transfer
        }
        
        # If this is a token transfer, decode the input data
        if is_token_transfer:
            try:
                func_obj, func_params = self.contract.decode_function_input(tx['input'])
                if func_obj.fn_name == 'transfer':
                    result["token_to"] = func_params['to']
                    result["token_value"] = Decimal(func_params['value']) / Decimal(10**18)
            except:
                pass
        
        return result
    
    def get_block(self, block_number: int) -> Dict[str, Any]:
        """
        Get information about a block.
        
        Args:
            block_number: The number of the block to get information about
            
        Returns:
            Dict containing information about the block
        """
        # Get block
        block = self.w3.eth.get_block(block_number, full_transactions=True)
        
        return {
            "block_number": block.number,
            "hash": block.hash.hex(),
            "parent_hash": block.parentHash.hex(),
            "timestamp": block.timestamp,
            "transactions": [tx.hash.hex() for tx in block.transactions],
            "gas_used": block.gasUsed,
            "gas_limit": block.gasLimit,
            "miner": block.miner
        }
    
    def get_latest_block_number(self) -> int:
        """
        Get the latest block number.
        
        Returns:
            The latest block number
        """
        return self.w3.eth.block_number
    
    def validate_address(self, address: str) -> bool:
        """
        Validate a Ghalbir address.
        
        Args:
            address: The address to validate
            
        Returns:
            True if the address is valid, False otherwise
        """
        return self.w3.is_address(address)
    
    def sign_message(self, private_key: str, message: str) -> str:
        """
        Sign a message with a private key.
        
        Args:
            private_key: The private key to sign with
            message: The message to sign
            
        Returns:
            The signature of the message
        """
        account = Account.from_key(private_key)
        message_encoded = encode_defunct(text=message)
        signed_message = self.w3.eth.account.sign_message(message_encoded, private_key=private_key)
        
        return signed_message.signature.hex()
    
    def verify_signature(self, address: str, message: str, signature: str) -> bool:
        """
        Verify a signature.
        
        Args:
            address: The address that supposedly signed the message
            message: The message that was signed
            signature: The signature to verify
            
        Returns:
            True if the signature is valid, False otherwise
        """
        message_encoded = encode_defunct(text=message)
        recovered_address = self.w3.eth.account.recover_message(message_encoded, signature=signature)
        
        return recovered_address.lower() == address.lower()
    
    def get_transaction_history(self, address: str, start_block: int = 0, end_block: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get the transaction history of an address.
        
        Args:
            address: The address to get the transaction history of
            start_block: The block number to start from
            end_block: The block number to end at (defaults to latest block)
            
        Returns:
            List of transactions involving the address
        """
        if end_block is None:
            end_block = self.w3.eth.block_number
        
        # This is a simplified implementation that would be inefficient for a real blockchain
        # In a real implementation, you would use an indexer or API service
        
        transactions = []
        checksum_address = self.w3.to_checksum_address(address)
        
        # Check for token transfers (this is a simplified approach)
        transfer_filter = self.contract.events.Transfer.create_filter(
            fromBlock=start_block,
            toBlock=end_block,
            argument_filters={'from': checksum_address}
        )
        from_events = transfer_filter.get_all_entries()
        
        transfer_filter = self.contract.events.Transfer.create_filter(
            fromBlock=start_block,
            toBlock=end_block,
            argument_filters={'to': checksum_address}
        )
        to_events = transfer_filter.get_all_entries()
        
        # Process events
        for event in from_events + to_events:
            tx_hash = event['transactionHash'].hex()
            
            # Get transaction details
            tx = self.get_transaction(tx_hash)
            transactions.append(tx)
        
        return transactions
    
    def estimate_gas(self, from_address: str, to_address: str, amount: Decimal) -> int:
        """
        Estimate the gas required for a transaction.
        
        Args:
            from_address: The address sending the transaction
            to_address: The address receiving the transaction
            amount: The amount of GBR tokens to transfer
            
        Returns:
            The estimated gas required for the transaction
        """
        # Convert amount to wei
        amount_wei = int(amount * Decimal(10**18))
        
        # Estimate gas
        from_checksum_address = self.w3.to_checksum_address(from_address)
        to_checksum_address = self.w3.to_checksum_address(to_address)
        
        gas_estimate = self.contract.functions.transfer(
            to_checksum_address,
            amount_wei
        ).estimate_gas({'from': from_checksum_address})
        
        return gas_estimate
    
    def get_gas_price(self) -> Decimal:
        """
        Get the current gas price.
        
        Returns:
            The current gas price in Gwei
        """
        gas_price_wei = self.w3.eth.gas_price
        gas_price_gwei = Decimal(gas_price_wei) / Decimal(10**9)  # Convert to Gwei
        
        return gas_price_gwei
