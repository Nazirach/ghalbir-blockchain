from typing import Dict, List, Optional, Any
import os
import json
import time
from decimal import Decimal
import threading
import uuid

from src.blockchain.blockchain_connector import GhalbirBlockchainConnector
from src.models.transaction import Transaction, TransactionType, TransactionStatus
from src.services.transaction_service import TransactionService
from src.services.wallet_service import WalletService

class BlockchainService:
    """
    Service for interacting with the Ghalbir blockchain.
    This service provides methods for deposits, withdrawals, and blockchain monitoring.
    """
    
    def __init__(self, 
                 blockchain_connector: GhalbirBlockchainConnector,
                 transaction_service: TransactionService,
                 wallet_service: WalletService,
                 data_dir: str = "/home/ubuntu/ghalbir-exchange/data"):
        """
        Initialize the blockchain service.
        
        Args:
            blockchain_connector: The blockchain connector to use
            transaction_service: The transaction service to use
            wallet_service: The wallet service to use
            data_dir: The data directory to use
        """
        self.blockchain_connector = blockchain_connector
        self.transaction_service = transaction_service
        self.wallet_service = wallet_service
        self.data_dir = data_dir
        
        # Create blockchain data directory
        self.blockchain_dir = os.path.join(data_dir, "blockchain")
        os.makedirs(self.blockchain_dir, exist_ok=True)
        
        # Create wallets directory
        self.wallets_dir = os.path.join(self.blockchain_dir, "wallets")
        os.makedirs(self.wallets_dir, exist_ok=True)
        
        # Create deposits directory
        self.deposits_dir = os.path.join(self.blockchain_dir, "deposits")
        os.makedirs(self.deposits_dir, exist_ok=True)
        
        # Create withdrawals directory
        self.withdrawals_dir = os.path.join(self.blockchain_dir, "withdrawals")
        os.makedirs(self.withdrawals_dir, exist_ok=True)
        
        # Initialize deposit monitoring
        self.deposit_monitor_running = False
        self.deposit_monitor_thread = None
        
        # Initialize withdrawal processing
        self.withdrawal_processor_running = False
        self.withdrawal_processor_thread = None
        
        # Load hot wallet
        self.hot_wallet = self._load_hot_wallet()
    
    def _load_hot_wallet(self) -> Dict[str, str]:
        """
        Load the hot wallet for the exchange.
        If no hot wallet exists, create one.
        
        Returns:
            Dict containing the address and private key of the hot wallet
        """
        hot_wallet_path = os.path.join(self.blockchain_dir, "hot_wallet.json")
        
        if os.path.exists(hot_wallet_path):
            with open(hot_wallet_path, 'r') as f:
                hot_wallet = json.load(f)
        else:
            # Create new hot wallet
            hot_wallet = self.blockchain_connector.create_wallet()
            
            # Save hot wallet
            with open(hot_wallet_path, 'w') as f:
                json.dump(hot_wallet, f, indent=2)
        
        return hot_wallet
    
    def get_deposit_address(self, user_id: str, asset: str) -> str:
        """
        Get a deposit address for a user.
        
        Args:
            user_id: The ID of the user
            asset: The asset to get a deposit address for
            
        Returns:
            The deposit address
        """
        if asset != "GBR":
            raise ValueError(f"Unsupported asset: {asset}")
        
        # Check if user already has a wallet for this asset
        wallet_path = os.path.join(self.wallets_dir, f"{user_id}_{asset}.json")
        
        if os.path.exists(wallet_path):
            with open(wallet_path, 'r') as f:
                wallet = json.load(f)
            
            return wallet["address"]
        
        # Create new wallet
        wallet = self.blockchain_connector.create_wallet()
        
        # Save wallet
        with open(wallet_path, 'w') as f:
            json.dump(wallet, f, indent=2)
        
        return wallet["address"]
    
    def process_deposit(self, user_id: str, asset: str, tx_hash: str) -> Dict[str, Any]:
        """
        Process a deposit transaction.
        
        Args:
            user_id: The ID of the user
            asset: The asset being deposited
            tx_hash: The transaction hash
            
        Returns:
            Dict containing the status of the deposit
        """
        if asset != "GBR":
            raise ValueError(f"Unsupported asset: {asset}")
        
        # Get transaction details
        tx = self.blockchain_connector.get_transaction(tx_hash)
        
        # Verify transaction is a token transfer
        if not tx.get("is_token_transfer", False):
            return {
                "success": False,
                "error": "Transaction is not a token transfer"
            }
        
        # Get user's deposit address
        deposit_address = self.get_deposit_address(user_id, asset)
        
        # Verify recipient is the user's deposit address
        if tx.get("token_to", "").lower() != deposit_address.lower():
            return {
                "success": False,
                "error": "Transaction recipient does not match user's deposit address"
            }
        
        # Verify transaction status
        if tx.get("status") != "success":
            return {
                "success": False,
                "error": "Transaction failed"
            }
        
        # Get amount
        amount = tx.get("token_value", Decimal("0"))
        
        # Create deposit transaction
        transaction = self.transaction_service.create_deposit(
            user_id=user_id,
            asset=asset,
            amount=amount,
            address=deposit_address,
            tx_hash=tx_hash
        )
        
        # Credit user's wallet
        self.wallet_service.deposit(user_id, asset, amount)
        
        # Save deposit record
        deposit_path = os.path.join(self.deposits_dir, f"{tx_hash}.json")
        with open(deposit_path, 'w') as f:
            json.dump({
                "user_id": user_id,
                "asset": asset,
                "amount": str(amount),
                "address": deposit_address,
                "tx_hash": tx_hash,
                "block_number": tx.get("block_number"),
                "timestamp": int(time.time()),
                "status": "completed"
            }, f, indent=2)
        
        return {
            "success": True,
            "transaction_id": transaction.id,
            "amount": str(amount),
            "asset": asset
        }
    
    def create_withdrawal(self, user_id: str, asset: str, amount: Decimal, address: str) -> Dict[str, Any]:
        """
        Create a withdrawal request.
        
        Args:
            user_id: The ID of the user
            asset: The asset to withdraw
            amount: The amount to withdraw
            address: The address to withdraw to
            
        Returns:
            Dict containing the status of the withdrawal request
        """
        if asset != "GBR":
            raise ValueError(f"Unsupported asset: {asset}")
        
        # Validate address
        if not self.blockchain_connector.validate_address(address):
            return {
                "success": False,
                "error": "Invalid withdrawal address"
            }
        
        # Calculate fee (0.1% for this example)
        fee = amount * Decimal('0.001')
        total_amount = amount + fee
        
        # Check balance
        if not self.wallet_service.check_balance(user_id, asset, total_amount):
            return {
                "success": False,
                "error": "Insufficient balance"
            }
        
        # Create withdrawal transaction
        transaction = self.transaction_service.create_withdrawal(
            user_id=user_id,
            asset=asset,
            amount=amount,
            fee=fee,
            address=address
        )
        
        # Deduct from wallet
        self.wallet_service.withdraw(user_id, asset, total_amount)
        
        # Save withdrawal request
        withdrawal_path = os.path.join(self.withdrawals_dir, f"{transaction.id}.json")
        with open(withdrawal_path, 'w') as f:
            json.dump({
                "id": transaction.id,
                "user_id": user_id,
                "asset": asset,
                "amount": str(amount),
                "fee": str(fee),
                "address": address,
                "status": "pending",
                "created_at": int(time.time())
            }, f, indent=2)
        
        return {
            "success": True,
            "transaction_id": transaction.id,
            "amount": str(amount),
            "fee": str(fee),
            "asset": asset
        }
    
    def process_withdrawal(self, transaction_id: str) -> Dict[str, Any]:
        """
        Process a withdrawal request.
        
        Args:
            transaction_id: The ID of the withdrawal transaction
            
        Returns:
            Dict containing the status of the withdrawal
        """
        # Get withdrawal request
        withdrawal_path = os.path.join(self.withdrawals_dir, f"{transaction_id}.json")
        
        if not os.path.exists(withdrawal_path):
            return {
                "success": False,
                "error": "Withdrawal request not found"
            }
        
        with open(withdrawal_path, 'r') as f:
            withdrawal = json.load(f)
        
        # Check if already processed
        if withdrawal.get("status") != "pending":
            return {
                "success": False,
                "error": f"Withdrawal already {withdrawal.get('status')}"
            }
        
        # Get transaction
        transaction = self.transaction_service.get_transaction(transaction_id)
        
        if not transaction:
            return {
                "success": False,
                "error": "Transaction not found"
            }
        
        # Verify transaction is a withdrawal
        if transaction.type != TransactionType.WITHDRAWAL:
            return {
                "success": False,
                "error": "Transaction is not a withdrawal"
            }
        
        # Verify transaction status
        if transaction.status != TransactionStatus.PENDING:
            return {
                "success": False,
                "error": f"Transaction status is {transaction.status.value}, not pending"
            }
        
        try:
            # Send tokens from hot wallet
            tx_result = self.blockchain_connector.transfer(
                from_private_key=self.hot_wallet["private_key"],
                to_address=withdrawal["address"],
                amount=Decimal(withdrawal["amount"])
            )
            
            # Update withdrawal status
            withdrawal["status"] = "completed"
            withdrawal["tx_hash"] = tx_result["tx_hash"]
            withdrawal["completed_at"] = int(time.time())
            
            with open(withdrawal_path, 'w') as f:
                json.dump(withdrawal, f, indent=2)
            
            # Update transaction status
            self.transaction_service.update_transaction_status(
                transaction_id=transaction_id,
                status=TransactionStatus.COMPLETED,
                tx_hash=tx_result["tx_hash"]
            )
            
            return {
                "success": True,
                "transaction_id": transaction_id,
                "tx_hash": tx_result["tx_hash"]
            }
        except Exception as e:
            # Update withdrawal status
            withdrawal["status"] = "failed"
            withdrawal["error"] = str(e)
            withdrawal["failed_at"] = int(time.time())
            
            with open(withdrawal_path, 'w') as f:
                json.dump(withdrawal, f, indent=2)
            
            # Update transaction status
            self.transaction_service.update_transaction_status(
                transaction_id=transaction_id,
                status=TransactionStatus.FAILED,
                error=str(e)
            )
            
            return {
                "success": False,
                "error": str(e)
            }
    
    def start_deposit_monitor(self) -> None:
        """
        Start monitoring for deposits.
        """
        if self.deposit_monitor_running:
            return
        
        self.deposit_monitor_running = True
        self.deposit_monitor_thread = threading.Thread(target=self._deposit_monitor_loop)
        self.deposit_monitor_thread.daemon = True
        self.deposit_monitor_thread.start()
        
        print("Deposit monitor started")
    
    def stop_deposit_monitor(self) -> None:
        """
        Stop monitoring for deposits.
        """
        self.deposit_monitor_running = False
        
        if self.deposit_monitor_thread:
            self.deposit_monitor_thread.join()
            self.deposit_monitor_thread = None
        
        print("Deposit monitor stopped")
    
    def _deposit_monitor_loop(self) -> None:
        """
        Main loop for monitoring deposits.
        """
        # Keep track of last processed block
        last_processed_block_path = os.path.join(self.blockchain_dir, "last_processed_block.txt")
        
        if os.path.exists(last_processed_block_path):
            with open(last_processed_block_path, 'r') as f:
                last_processed_block = int(f.read().strip())
        else:
            # Start from current block
            last_processed_block = self.blockchain_connector.get_latest_block_number()
            with open(last_processed_block_path, 'w') as f:
                f.write(str(last_processed_block))
        
        while self.deposit_monitor_running:
            try:
                # Get latest block
                latest_block = self.blockchain_connector.get_latest_block_number()
                
                # Process new blocks
                for block_number in range(last_processed_block + 1, latest_block + 1):
                    self._process_block_for_deposits(block_number)
                    last_processed_block = block_number
                    
                    # Update last processed block
                    with open(last_processed_block_path, 'w') as f:
                        f.write(str(last_processed_block))
                
                # Sleep to avoid high CPU usage
                time.sleep(15)  # Check for new blocks every 15 seconds
            except Exception as e:
                print(f"Error in deposit monitor: {e}")
                time.sleep(30)  # Wait longer after an error
    
    def _process_block_for_deposits(self, block_number: int) -> None:
        """
        Process a block for deposits.
        
        Args:
            block_number: The block number to process
        """
        # Get block
        block = self.blockchain_connector.get_block(block_number)
        
        # Process each transaction
        for tx_hash in block["transactions"]:
            try:
                # Get transaction
                tx = self.blockchain_connector.get_transaction(tx_hash)
                
                # Check if this is a token transfer to one of our deposit addresses
                if tx.get("is_token_transfer", False):
                    recipient = tx.get("token_to")
                    
                    if recipient:
                        # Check if this is a deposit address
                        user_id = self._find_user_for_deposit_address(recipient)
                        
                        if user_id:
                            # Process deposit
                            self.process_deposit(user_id, "GBR", tx_hash)
            except Exception as e:
                print(f"Error processing transaction {tx_hash}: {e}")
    
    def _find_user_for_deposit_address(self, address: str) -> Optional[str]:
        """
        Find the user ID for a deposit address.
        
        Args:
            address: The deposit address to find the user for
            
        Returns:
            The user ID if found, None otherwise
        """
        # Check all wallet files
        for filename in os.listdir(self.wallets_dir):
            if filename.endswith(".json"):
                wallet_path = os.path.join(self.wallets_dir, filename)
                
                try:
                    with open(wallet_path, 'r') as f:
                        wallet = json.load(f)
                    
                    if wallet.get("address", "").lower() == address.lower():
                        # Extract user ID from filename (format: user_id_asset.json)
                        parts = filename.split('_')
                        if len(parts) >= 2:
                            return parts[0]
                except Exception as e:
                    print(f"Error reading wallet file {filename}: {e}")
        
        return None
    
    def start_withdrawal_processor(self) -> None:
        """
        Start processing withdrawals.
        """
        if self.withdrawal_processor_running:
            return
        
        self.withdrawal_processor_running = True
        self.withdrawal_processor_thread = threading.Thread(target=self._withdrawal_processor_loop)
        self.withdrawal_processor_thread.daemon = True
        self.withdrawal_processor_thread.start()
        
        print("Withdrawal processor started")
    
    def stop_withdrawal_processor(self) -> None:
        """
        Stop processing withdrawals.
        """
        self.withdrawal_processor_running = False
        
        if self.withdrawal_processor_thread:
            self.withdrawal_processor_thread.join()
            self.withdrawal_processor_thread = None
        
        print("Withdrawal processor stopped")
    
    def _withdrawal_processor_loop(self) -> None:
        """
        Main loop for processing withdrawals.
        """
        while self.withdrawal_processor_running:
            try:
                # Get pending withdrawals
                pending_withdrawals = self._get_pending_withdrawals()
                
                # Process each withdrawal
                for withdrawal_id in pending_withdrawals:
                    self.process_withdrawal(withdrawal_id)
                
                # Sleep to avoid high CPU usage
                time.sleep(30)  # Process withdrawals every 30 seconds
            except Exception as e:
                print(f"Error in withdrawal processor: {e}")
                time.sleep(60)  # Wait longer after an error
    
    def _get_pending_withdrawals(self) -> List[str]:
        """
        Get a list of pending withdrawal IDs.
        
        Returns:
            List of pending withdrawal IDs
        """
        pending_withdrawals = []
        
        # Check all withdrawal files
        for filename in os.listdir(self.withdrawals_dir):
            if filename.endswith(".json"):
                withdrawal_path = os.path.join(self.withdrawals_dir, filename)
                
                try:
                    with open(withdrawal_path, 'r') as f:
                        withdrawal = json.load(f)
                    
                    if withdrawal.get("status") == "pending":
                        # Extract withdrawal ID from filename (format: id.json)
                        withdrawal_id = filename.split('.')[0]
                        pending_withdrawals.append(withdrawal_id)
                except Exception as e:
                    print(f"Error reading withdrawal file {filename}: {e}")
        
        return pending_withdrawals
    
    def get_hot_wallet_balance(self) -> Dict[str, Any]:
        """
        Get the balance of the hot wallet.
        
        Returns:
            Dict containing the balance of the hot wallet
        """
        address = self.hot_wallet["address"]
        
        # Get GBR balance
        gbr_balance = self.blockchain_connector.get_balance(address)
        
        # Get ETH balance
        eth_balance = self.blockchain_connector.get_eth_balance(address)
        
        return {
            "address": address,
            "GBR": str(gbr_balance),
            "ETH": str(eth_balance)
        }
    
    def verify_blockchain_transaction(self, tx_hash: str) -> Dict[str, Any]:
        """
        Verify a blockchain transaction.
        
        Args:
            tx_hash: The transaction hash to verify
            
        Returns:
            Dict containing information about the transaction
        """
        try:
            # Get transaction
            tx = self.blockchain_connector.get_transaction(tx_hash)
            
            return {
                "success": True,
                "transaction": tx
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
