from typing import Dict, List, Optional
import uuid
from decimal import Decimal
from datetime import datetime
import json
import os

from src.models.transaction import Transaction, TransactionType, TransactionStatus

class TransactionService:
    def __init__(self, data_dir: str = "/home/ubuntu/ghalbir-exchange/data"):
        self.data_dir = data_dir
        self.transactions_dir = os.path.join(data_dir, "transactions")
        
        # Ensure directories exist
        os.makedirs(self.transactions_dir, exist_ok=True)
    
    def _get_transaction_path(self, transaction_id: str) -> str:
        """Get path to transaction file"""
        return os.path.join(self.transactions_dir, f"{transaction_id}.json")
    
    def _save_transaction(self, transaction: Transaction) -> None:
        """Save transaction to disk"""
        transaction_path = self._get_transaction_path(transaction.id)
        
        with open(transaction_path, 'w') as f:
            json.dump(transaction.to_dict(), f, indent=2)
    
    def create_deposit(self, user_id: str, asset: str, amount: Decimal, 
                      fee: Decimal, address: str) -> Transaction:
        """Create a new deposit transaction"""
        transaction_id = str(uuid.uuid4())
        
        transaction = Transaction(
            id=transaction_id,
            user_id=user_id,
            type=TransactionType.DEPOSIT,
            asset=asset,
            amount=amount,
            fee=fee,
            address=address,
            status=TransactionStatus.PENDING
        )
        
        self._save_transaction(transaction)
        
        return transaction
    
    def create_withdrawal(self, user_id: str, asset: str, amount: Decimal, 
                         fee: Decimal, address: str) -> Transaction:
        """Create a new withdrawal transaction"""
        transaction_id = str(uuid.uuid4())
        
        transaction = Transaction(
            id=transaction_id,
            user_id=user_id,
            type=TransactionType.WITHDRAWAL,
            asset=asset,
            amount=amount,
            fee=fee,
            address=address,
            status=TransactionStatus.PENDING
        )
        
        self._save_transaction(transaction)
        
        return transaction
    
    def get_transaction(self, transaction_id: str) -> Optional[Transaction]:
        """Get transaction by ID"""
        transaction_path = self._get_transaction_path(transaction_id)
        
        if not os.path.exists(transaction_path):
            return None
        
        try:
            with open(transaction_path, 'r') as f:
                transaction_data = json.load(f)
                return Transaction.from_dict(transaction_data)
        except Exception as e:
            print(f"Error loading transaction {transaction_id}: {e}")
            return None
    
    def get_user_transactions(self, user_id: str) -> List[Transaction]:
        """Get all transactions for a user"""
        user_transactions = []
        
        if not os.path.exists(self.transactions_dir):
            return user_transactions
        
        for filename in os.listdir(self.transactions_dir):
            if filename.endswith(".json"):
                transaction_path = os.path.join(self.transactions_dir, filename)
                
                try:
                    with open(transaction_path, 'r') as f:
                        transaction_data = json.load(f)
                        if transaction_data["user_id"] == user_id:
                            user_transactions.append(Transaction.from_dict(transaction_data))
                except Exception as e:
                    print(f"Error loading transaction {filename}: {e}")
        
        # Sort by created_at (newest first)
        user_transactions.sort(key=lambda x: x.created_at, reverse=True)
        
        return user_transactions
    
    def get_pending_transactions(self, transaction_type: Optional[TransactionType] = None) -> List[Transaction]:
        """Get all pending transactions"""
        pending_transactions = []
        
        if not os.path.exists(self.transactions_dir):
            return pending_transactions
        
        for filename in os.listdir(self.transactions_dir):
            if filename.endswith(".json"):
                transaction_path = os.path.join(self.transactions_dir, filename)
                
                try:
                    with open(transaction_path, 'r') as f:
                        transaction_data = json.load(f)
                        if transaction_data["status"] == TransactionStatus.PENDING.value:
                            if transaction_type is None or transaction_data["type"] == transaction_type.value:
                                pending_transactions.append(Transaction.from_dict(transaction_data))
                except Exception as e:
                    print(f"Error loading transaction {filename}: {e}")
        
        return pending_transactions
    
    def complete_transaction(self, transaction_id: str, tx_hash: str) -> Optional[Transaction]:
        """Mark a transaction as completed"""
        transaction = self.get_transaction(transaction_id)
        
        if not transaction:
            return None
        
        transaction.complete(tx_hash)
        self._save_transaction(transaction)
        
        return transaction
    
    def fail_transaction(self, transaction_id: str, reason: str = None) -> Optional[Transaction]:
        """Mark a transaction as failed"""
        transaction = self.get_transaction(transaction_id)
        
        if not transaction:
            return None
        
        transaction.fail(reason)
        self._save_transaction(transaction)
        
        return transaction
