from typing import Dict, List, Optional, Any
import uuid
import json
import os
import hashlib
import secrets
import time
import base64
import hmac
import pyotp
from datetime import datetime, timedelta
import jwt

from src.models.user import User, UserStatus, KYCStatus

class UserService:
    def __init__(self, data_dir: str = "/home/ubuntu/ghalbir-exchange/data"):
        self.data_dir = data_dir
        self.users_dir = os.path.join(data_dir, "users")
        self.sessions_dir = os.path.join(data_dir, "sessions")
        self.kyc_dir = os.path.join(data_dir, "kyc")
        
        # JWT secret key
        self.jwt_secret = os.environ.get("JWT_SECRET", secrets.token_hex(32))
        
        # Ensure directories exist
        os.makedirs(self.users_dir, exist_ok=True)
        os.makedirs(self.sessions_dir, exist_ok=True)
        os.makedirs(self.kyc_dir, exist_ok=True)
        
        # In-memory cache of active users
        self.users_cache: Dict[str, User] = {}
    
    def _get_user_path(self, user_id: str) -> str:
        """Get path to user file"""
        return os.path.join(self.users_dir, f"{user_id}.json")
    
    def _get_session_path(self, session_id: str) -> str:
        """Get path to session file"""
        return os.path.join(self.sessions_dir, f"{session_id}.json")
    
    def _get_kyc_path(self, user_id: str) -> str:
        """Get path to KYC directory for a user"""
        return os.path.join(self.kyc_dir, user_id)
    
    def _save_user(self, user: User) -> None:
        """Save user to disk"""
        user_path = self._get_user_path(user.id)
        
        with open(user_path, 'w') as f:
            json.dump(user.to_dict(), f, indent=2)
        
        # Update in-memory cache
        self.users_cache[user.id] = user
    
    def _hash_password(self, password: str, salt: Optional[str] = None) -> tuple:
        """Hash password using PBKDF2 with SHA-256"""
        if salt is None:
            salt = secrets.token_hex(16)
        
        # Use PBKDF2 with 100,000 iterations
        key = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000
        ).hex()
        
        return f"{salt}${key}", salt
    
    def _verify_password(self, password: str, password_hash: str) -> bool:
        """Verify password against hash"""
        if not password_hash or '$' not in password_hash:
            return False
        
        salt, key = password_hash.split('$', 1)
        
        # Hash the provided password with the same salt
        calculated_hash, _ = self._hash_password(password, salt)
        _, calculated_key = calculated_hash.split('$', 1)
        
        # Compare the keys
        return key == calculated_key
    
    def create_user(self, email: str, password: str, full_name: str) -> User:
        """Create a new user"""
        # Check if email already exists
        existing_user = self.get_user_by_email(email)
        if existing_user:
            raise ValueError(f"Email already exists: {email}")
        
        user_id = str(uuid.uuid4())
        
        # Hash password
        password_hash, _ = self._hash_password(password)
        
        user = User(
            id=user_id,
            email=email,
            password_hash=password_hash,
            full_name=full_name,
            kyc_status=KYCStatus.PENDING,
            two_factor_enabled=False,
            status=UserStatus.ACTIVE
        )
        
        self._save_user(user)
        
        return user
    
    def get_user(self, user_id: str) -> Optional[User]:
        """Get user by ID"""
        # Check in-memory cache first
        if user_id in self.users_cache:
            return self.users_cache[user_id]
        
        # Try to load from disk
        user_path = self._get_user_path(user_id)
        if os.path.exists(user_path):
            try:
                with open(user_path, 'r') as f:
                    user_data = json.load(f)
                    user = User.from_dict(user_data)
                    
                    # Update in-memory cache
                    self.users_cache[user_id] = user
                    
                    return user
            except Exception as e:
                print(f"Error loading user {user_id}: {e}")
        
        return None
    
    def get_user_by_email(self, email: str) -> Optional[User]:
        """Get user by email"""
        # Check in-memory cache first
        for user in self.users_cache.values():
            if user.email == email:
                return user
        
        # Try to load from disk
        if not os.path.exists(self.users_dir):
            return None
        
        for filename in os.listdir(self.users_dir):
            if filename.endswith(".json"):
                user_path = os.path.join(self.users_dir, filename)
                
                try:
                    with open(user_path, 'r') as f:
                        user_data = json.load(f)
                        if user_data["email"] == email:
                            user = User.from_dict(user_data)
                            
                            # Update in-memory cache
                            self.users_cache[user.id] = user
                            
                            return user
                except Exception as e:
                    print(f"Error loading user {filename}: {e}")
        
        return None
    
    def update_user(self, user: User) -> None:
        """Update an existing user"""
        self._save_user(user)
    
    def authenticate(self, email: str, password: str) -> Optional[User]:
        """Authenticate user with email and password"""
        user = self.get_user_by_email(email)
        
        if not user:
            return None
        
        if not user.is_active():
            return None
        
        if not self._verify_password(password, user.password_hash):
            return None
        
        return user
    
    def change_password(self, user_id: str, current_password: str, new_password: str) -> bool:
        """Change user password"""
        user = self.get_user(user_id)
        
        if not user:
            return False
        
        if not self._verify_password(current_password, user.password_hash):
            return False
        
        # Hash new password
        password_hash, _ = self._hash_password(new_password)
        
        user.password_hash = password_hash
        user.updated_at = datetime.now()
        
        self._save_user(user)
        
        return True
    
    def reset_password(self, user_id: str, new_password: str) -> bool:
        """Reset user password (admin function)"""
        user = self.get_user(user_id)
        
        if not user:
            return False
        
        # Hash new password
        password_hash, _ = self._hash_password(new_password)
        
        user.password_hash = password_hash
        user.updated_at = datetime.now()
        
        self._save_user(user)
        
        return True
    
    def create_session(self, user_id: str, device_info: str = "") -> Dict[str, Any]:
        """Create a new session for a user"""
        user = self.get_user(user_id)
        
        if not user:
            raise ValueError(f"User not found: {user_id}")
        
        if not user.is_active():
            raise ValueError(f"User is not active: {user_id}")
        
        session_id = str(uuid.uuid4())
        
        # Create JWT token
        expiration = datetime.now() + timedelta(days=7)
        token = jwt.encode(
            {
                "sub": user_id,
                "exp": int(expiration.timestamp()),
                "iat": int(datetime.now().timestamp()),
                "jti": session_id
            },
            self.jwt_secret,
            algorithm="HS256"
        )
        
        # Save session
        session_data = {
            "id": session_id,
            "user_id": user_id,
            "device_info": device_info,
            "created_at": datetime.now().isoformat(),
            "expires_at": expiration.isoformat()
        }
        
        session_path = self._get_session_path(session_id)
        with open(session_path, 'w') as f:
            json.dump(session_data, f, indent=2)
        
        return {
            "token": token,
            "expires_at": expiration.isoformat(),
            "user": {
                "id": user.id,
                "email": user.email,
                "full_name": user.full_name,
                "kyc_status": user.kyc_status.value,
                "two_factor_enabled": user.two_factor_enabled
            }
        }
    
    def validate_token(self, token: str) -> Optional[Dict[str, Any]]:
        """Validate JWT token and return user info"""
        try:
            # Decode and verify token
            payload = jwt.decode(token, self.jwt_secret, algorithms=["HS256"])
            
            # Check if session exists
            session_id = payload.get("jti")
            session_path = self._get_session_path(session_id)
            
            if not os.path.exists(session_path):
                return None
            
            # Get user
            user_id = payload.get("sub")
            user = self.get_user(user_id)
            
            if not user or not user.is_active():
                return None
            
            return {
                "user_id": user_id,
                "session_id": session_id,
                "user": user
            }
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None
        except Exception as e:
            print(f"Error validating token: {e}")
            return None
    
    def invalidate_session(self, session_id: str) -> bool:
        """Invalidate a session"""
        session_path = self._get_session_path(session_id)
        
        if os.path.exists(session_path):
            try:
                os.remove(session_path)
                return True
            except Exception as e:
                print(f"Error removing session {session_id}: {e}")
        
        return False
    
    def invalidate_all_sessions(self, user_id: str) -> int:
        """Invalidate all sessions for a user"""
        count = 0
        
        if not os.path.exists(self.sessions_dir):
            return count
        
        for filename in os.listdir(self.sessions_dir):
            if filename.endswith(".json"):
                session_path = os.path.join(self.sessions_dir, filename)
                
                try:
                    with open(session_path, 'r') as f:
                        session_data = json.load(f)
                        if session_data["user_id"] == user_id:
                            os.remove(session_path)
                            count += 1
                except Exception as e:
                    print(f"Error processing session {filename}: {e}")
        
        return count
    
    def generate_2fa_secret(self, user_id: str) -> Dict[str, str]:
        """Generate 2FA secret for a user"""
        user = self.get_user(user_id)
        
        if not user:
            raise ValueError(f"User not found: {user_id}")
        
        # Generate a new secret
        secret = pyotp.random_base32()
        
        # Create a provisioning URI
        totp = pyotp.TOTP(secret)
        provisioning_uri = totp.provisioning_uri(user.email, issuer_name="Ghalbir Exchange")
        
        return {
            "secret": secret,
            "uri": provisioning_uri
        }
    
    def enable_2fa(self, user_id: str, secret: str, code: str) -> bool:
        """Enable 2FA for a user"""
        user = self.get_user(user_id)
        
        if not user:
            return False
        
        # Verify the code
        totp = pyotp.TOTP(secret)
        if not totp.verify(code):
            return False
        
        # Store the secret securely (in a real system, this would be encrypted)
        user_data = user.to_dict()
        user_data["2fa_secret"] = secret
        
        # Update user
        user.enable_two_factor()
        self._save_user(user)
        
        # Save 2FA secret separately
        user_path = self._get_user_path(user_id)
        with open(user_path, 'w') as f:
            json.dump(user_data, f, indent=2)
        
        return True
    
    def verify_2fa(self, user_id: str, code: str) -> bool:
        """Verify 2FA code for a user"""
        user = self.get_user(user_id)
        
        if not user or not user.two_factor_enabled:
            return False
        
        # Get the secret
        user_path = self._get_user_path(user_id)
        try:
            with open(user_path, 'r') as f:
                user_data = json.load(f)
                secret = user_data.get("2fa_secret")
                
                if not secret:
                    return False
                
                # Verify the code
                totp = pyotp.TOTP(secret)
                return totp.verify(code)
        except Exception as e:
            print(f"Error verifying 2FA: {e}")
            return False
    
    def disable_2fa(self, user_id: str, code: str) -> bool:
        """Disable 2FA for a user"""
        if not self.verify_2fa(user_id, code):
            return False
        
        user = self.get_user(user_id)
        
        if not user:
            return False
        
        # Update user
        user.disable_two_factor()
        self._save_user(user)
        
        # Remove 2FA secret
        user_path = self._get_user_path(user_id)
        try:
            with open(user_path, 'r') as f:
                user_data = json.load(f)
                if "2fa_secret" in user_data:
                    del user_data["2fa_secret"]
            
            with open(user_path, 'w') as f:
                json.dump(user_data, f, indent=2)
        except Exception as e:
            print(f"Error disabling 2FA: {e}")
            return False
        
        return True
    
    def submit_kyc(self, user_id: str, document_type: str, document_data: Dict[str, Any]) -> bool:
        """Submit KYC documents for a user"""
        user = self.get_user(user_id)
        
        if not user:
            return False
        
        # Create KYC directory for user
        kyc_dir = self._get_kyc_path(user_id)
        os.makedirs(kyc_dir, exist_ok=True)
        
        # Save document data
        document_path = os.path.join(kyc_dir, f"{document_type}.json")
        with open(document_path, 'w') as f:
            json.dump({
                "type": document_type,
                "data": document_data,
                "submitted_at": datetime.now().isoformat()
            }, f, indent=2)
        
        # Update user KYC status
        user.update_kyc_status(KYCStatus.PENDING)
        self._save_user(user)
        
        return True
    
    def update_kyc_status(self, user_id: str, status: KYCStatus) -> bool:
        """Update KYC status for a user (admin function)"""
        user = self.get_user(user_id)
        
        if not user:
            return False
        
        user.update_kyc_status(status)
        self._save_user(user)
        
        return True
    
    def get_kyc_documents(self, user_id: str) -> List[Dict[str, Any]]:
        """Get KYC documents for a user (admin function)"""
        kyc_dir = self._get_kyc_path(user_id)
        
        if not os.path.exists(kyc_dir):
            return []
        
        documents = []
        
        for filename in os.listdir(kyc_dir):
            if filename.endswith(".json"):
                document_path = os.path.join(kyc_dir, filename)
                
                try:
                    with open(document_path, 'r') as f:
                        document_data = json.load(f)
                        documents.append(document_data)
                except Exception as e:
                    print(f"Error loading document {filename}: {e}")
        
        return documents
