from typing import Dict, List, Optional, Any
import os
import json
import time
import hashlib
import hmac
import base64
import secrets
import re
import bcrypt
import jwt
from datetime import datetime, timedelta
import pyotp
import qrcode
from io import BytesIO

class SecurityService:
    """
    Service for handling security-related functionality for the Ghalbir Exchange.
    This service provides methods for authentication, authorization, and security features.
    """
    
    def __init__(self, 
                 secret_key: str = None,
                 jwt_secret: str = None,
                 data_dir: str = "/home/ubuntu/ghalbir-exchange/data"):
        """
        Initialize the security service.
        
        Args:
            secret_key: The secret key for HMAC operations
            jwt_secret: The secret key for JWT operations
            data_dir: The data directory to use
        """
        self.data_dir = data_dir
        
        # Create security data directory
        self.security_dir = os.path.join(data_dir, "security")
        os.makedirs(self.security_dir, exist_ok=True)
        
        # Initialize secret keys
        self.secret_key = secret_key or self._load_or_create_secret_key()
        self.jwt_secret = jwt_secret or self._load_or_create_jwt_secret()
        
        # Create 2FA directory
        self.twofa_dir = os.path.join(self.security_dir, "2fa")
        os.makedirs(self.twofa_dir, exist_ok=True)
        
        # Create API keys directory
        self.api_keys_dir = os.path.join(self.security_dir, "api_keys")
        os.makedirs(self.api_keys_dir, exist_ok=True)
        
        # Create session directory
        self.session_dir = os.path.join(self.security_dir, "sessions")
        os.makedirs(self.session_dir, exist_ok=True)
        
        # Create rate limit directory
        self.rate_limit_dir = os.path.join(self.security_dir, "rate_limit")
        os.makedirs(self.rate_limit_dir, exist_ok=True)
        
        # Password policy
        self.password_min_length = 8
        self.password_require_uppercase = True
        self.password_require_lowercase = True
        self.password_require_digit = True
        self.password_require_special = True
        
        # JWT settings
        self.jwt_expiry = 24 * 60 * 60  # 24 hours in seconds
        self.jwt_refresh_expiry = 7 * 24 * 60 * 60  # 7 days in seconds
        
        # Rate limiting settings
        self.rate_limit_login_attempts = 5
        self.rate_limit_login_window = 15 * 60  # 15 minutes in seconds
        
        # API key settings
        self.api_key_length = 32
        self.api_secret_length = 64
    
    def _load_or_create_secret_key(self) -> str:
        """
        Load the secret key from file or create a new one if it doesn't exist.
        
        Returns:
            The secret key
        """
        secret_key_path = os.path.join(self.security_dir, "secret_key.txt")
        
        if os.path.exists(secret_key_path):
            with open(secret_key_path, 'r') as f:
                secret_key = f.read().strip()
        else:
            # Generate a new secret key
            secret_key = secrets.token_hex(32)
            
            # Save secret key
            with open(secret_key_path, 'w') as f:
                f.write(secret_key)
        
        return secret_key
    
    def _load_or_create_jwt_secret(self) -> str:
        """
        Load the JWT secret from file or create a new one if it doesn't exist.
        
        Returns:
            The JWT secret
        """
        jwt_secret_path = os.path.join(self.security_dir, "jwt_secret.txt")
        
        if os.path.exists(jwt_secret_path):
            with open(jwt_secret_path, 'r') as f:
                jwt_secret = f.read().strip()
        else:
            # Generate a new JWT secret
            jwt_secret = secrets.token_hex(32)
            
            # Save JWT secret
            with open(jwt_secret_path, 'w') as f:
                f.write(jwt_secret)
        
        return jwt_secret
    
    def hash_password(self, password: str) -> str:
        """
        Hash a password using bcrypt.
        
        Args:
            password: The password to hash
            
        Returns:
            The hashed password
        """
        # Generate a salt and hash the password
        password_bytes = password.encode('utf-8')
        salt = bcrypt.gensalt()
        hashed = bcrypt.hashpw(password_bytes, salt)
        
        return hashed.decode('utf-8')
    
    def verify_password(self, password: str, hashed_password: str) -> bool:
        """
        Verify a password against a hash.
        
        Args:
            password: The password to verify
            hashed_password: The hash to verify against
            
        Returns:
            True if the password matches the hash, False otherwise
        """
        password_bytes = password.encode('utf-8')
        hashed_bytes = hashed_password.encode('utf-8')
        
        return bcrypt.checkpw(password_bytes, hashed_bytes)
    
    def validate_password_strength(self, password: str) -> Dict[str, Any]:
        """
        Validate the strength of a password.
        
        Args:
            password: The password to validate
            
        Returns:
            Dict containing validation results
        """
        # Check length
        length_valid = len(password) >= self.password_min_length
        
        # Check for uppercase letters
        uppercase_valid = not self.password_require_uppercase or bool(re.search(r'[A-Z]', password))
        
        # Check for lowercase letters
        lowercase_valid = not self.password_require_lowercase or bool(re.search(r'[a-z]', password))
        
        # Check for digits
        digit_valid = not self.password_require_digit or bool(re.search(r'\d', password))
        
        # Check for special characters
        special_valid = not self.password_require_special or bool(re.search(r'[!@#$%^&*(),.?":{}|<>]', password))
        
        # Calculate strength score (0-4)
        strength_score = sum([
            length_valid,
            uppercase_valid,
            lowercase_valid,
            digit_valid,
            special_valid
        ])
        
        # Determine strength level
        if strength_score <= 2:
            strength_level = "weak"
        elif strength_score <= 4:
            strength_level = "medium"
        else:
            strength_level = "strong"
        
        return {
            "valid": length_valid and uppercase_valid and lowercase_valid and digit_valid and special_valid,
            "length_valid": length_valid,
            "uppercase_valid": uppercase_valid,
            "lowercase_valid": lowercase_valid,
            "digit_valid": digit_valid,
            "special_valid": special_valid,
            "strength_score": strength_score,
            "strength_level": strength_level
        }
    
    def generate_jwt_token(self, user_id: str, additional_claims: Dict[str, Any] = None) -> Dict[str, str]:
        """
        Generate a JWT token for a user.
        
        Args:
            user_id: The ID of the user
            additional_claims: Additional claims to include in the token
            
        Returns:
            Dict containing the access token and refresh token
        """
        now = datetime.utcnow()
        
        # Create access token payload
        access_payload = {
            "sub": user_id,
            "iat": now,
            "exp": now + timedelta(seconds=self.jwt_expiry),
            "type": "access"
        }
        
        # Add additional claims
        if additional_claims:
            access_payload.update(additional_claims)
        
        # Create refresh token payload
        refresh_payload = {
            "sub": user_id,
            "iat": now,
            "exp": now + timedelta(seconds=self.jwt_refresh_expiry),
            "type": "refresh"
        }
        
        # Generate tokens
        access_token = jwt.encode(access_payload, self.jwt_secret, algorithm="HS256")
        refresh_token = jwt.encode(refresh_payload, self.jwt_secret, algorithm="HS256")
        
        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "expires_in": self.jwt_expiry
        }
    
    def verify_jwt_token(self, token: str) -> Dict[str, Any]:
        """
        Verify a JWT token.
        
        Args:
            token: The token to verify
            
        Returns:
            Dict containing the token payload if valid
        """
        try:
            # Decode and verify token
            payload = jwt.decode(token, self.jwt_secret, algorithms=["HS256"])
            
            return {
                "valid": True,
                "payload": payload
            }
        except jwt.ExpiredSignatureError:
            return {
                "valid": False,
                "error": "Token has expired"
            }
        except jwt.InvalidTokenError:
            return {
                "valid": False,
                "error": "Invalid token"
            }
    
    def refresh_jwt_token(self, refresh_token: str) -> Dict[str, Any]:
        """
        Refresh a JWT token.
        
        Args:
            refresh_token: The refresh token
            
        Returns:
            Dict containing the new access token if valid
        """
        # Verify refresh token
        verification = self.verify_jwt_token(refresh_token)
        
        if not verification["valid"]:
            return {
                "success": False,
                "error": verification["error"]
            }
        
        payload = verification["payload"]
        
        # Check token type
        if payload.get("type") != "refresh":
            return {
                "success": False,
                "error": "Invalid token type"
            }
        
        # Generate new access token
        user_id = payload["sub"]
        tokens = self.generate_jwt_token(user_id)
        
        return {
            "success": True,
            "access_token": tokens["access_token"],
            "refresh_token": tokens["refresh_token"],
            "expires_in": self.jwt_expiry
        }
    
    def setup_2fa(self, user_id: str) -> Dict[str, Any]:
        """
        Set up two-factor authentication for a user.
        
        Args:
            user_id: The ID of the user
            
        Returns:
            Dict containing 2FA setup information
        """
        # Generate a secret key
        secret = pyotp.random_base32()
        
        # Create a TOTP object
        totp = pyotp.TOTP(secret)
        
        # Generate a provisioning URI
        provisioning_uri = totp.provisioning_uri(name=user_id, issuer_name="Ghalbir Exchange")
        
        # Generate QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(provisioning_uri)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Save to BytesIO
        buffer = BytesIO()
        img.save(buffer)
        qr_code_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
        
        # Save 2FA secret
        twofa_path = os.path.join(self.twofa_dir, f"{user_id}.json")
        with open(twofa_path, 'w') as f:
            json.dump({
                "secret": secret,
                "enabled": False,
                "created_at": int(time.time())
            }, f, indent=2)
        
        return {
            "secret": secret,
            "qr_code_base64": qr_code_base64,
            "provisioning_uri": provisioning_uri
        }
    
    def verify_2fa(self, user_id: str, code: str) -> bool:
        """
        Verify a 2FA code.
        
        Args:
            user_id: The ID of the user
            code: The 2FA code to verify
            
        Returns:
            True if the code is valid, False otherwise
        """
        # Get 2FA secret
        twofa_path = os.path.join(self.twofa_dir, f"{user_id}.json")
        
        if not os.path.exists(twofa_path):
            return False
        
        with open(twofa_path, 'r') as f:
            twofa_data = json.load(f)
        
        secret = twofa_data["secret"]
        
        # Create a TOTP object
        totp = pyotp.TOTP(secret)
        
        # Verify code
        return totp.verify(code)
    
    def enable_2fa(self, user_id: str, code: str) -> Dict[str, Any]:
        """
        Enable 2FA for a user.
        
        Args:
            user_id: The ID of the user
            code: The 2FA code to verify
            
        Returns:
            Dict containing the result of the operation
        """
        # Verify code
        if not self.verify_2fa(user_id, code):
            return {
                "success": False,
                "error": "Invalid 2FA code"
            }
        
        # Get 2FA data
        twofa_path = os.path.join(self.twofa_dir, f"{user_id}.json")
        
        with open(twofa_path, 'r') as f:
            twofa_data = json.load(f)
        
        # Enable 2FA
        twofa_data["enabled"] = True
        twofa_data["enabled_at"] = int(time.time())
        
        with open(twofa_path, 'w') as f:
            json.dump(twofa_data, f, indent=2)
        
        return {
            "success": True
        }
    
    def disable_2fa(self, user_id: str, code: str) -> Dict[str, Any]:
        """
        Disable 2FA for a user.
        
        Args:
            user_id: The ID of the user
            code: The 2FA code to verify
            
        Returns:
            Dict containing the result of the operation
        """
        # Verify code
        if not self.verify_2fa(user_id, code):
            return {
                "success": False,
                "error": "Invalid 2FA code"
            }
        
        # Get 2FA data
        twofa_path = os.path.join(self.twofa_dir, f"{user_id}.json")
        
        with open(twofa_path, 'r') as f:
            twofa_data = json.load(f)
        
        # Disable 2FA
        twofa_data["enabled"] = False
        twofa_data["disabled_at"] = int(time.time())
        
        with open(twofa_path, 'w') as f:
            json.dump(twofa_data, f, indent=2)
        
        return {
            "success": True
        }
    
    def is_2fa_enabled(self, user_id: str) -> bool:
        """
        Check if 2FA is enabled for a user.
        
        Args:
            user_id: The ID of the user
            
        Returns:
            True if 2FA is enabled, False otherwise
        """
        # Get 2FA data
        twofa_path = os.path.join(self.twofa_dir, f"{user_id}.json")
        
        if not os.path.exists(twofa_path):
            return False
        
        with open(twofa_path, 'r') as f:
            twofa_data = json.load(f)
        
        return twofa_data.get("enabled", False)
    
    def generate_api_key(self, user_id: str, label: str, permissions: List[str]) -> Dict[str, Any]:
        """
        Generate an API key for a user.
        
        Args:
            user_id: The ID of the user
            label: A label for the API key
            permissions: A list of permissions for the API key
            
        Returns:
            Dict containing the API key and secret
        """
        # Generate API key and secret
        api_key = secrets.token_hex(self.api_key_length)
        api_secret = secrets.token_hex(self.api_secret_length)
        
        # Hash API secret for storage
        hashed_secret = hashlib.sha256(api_secret.encode()).hexdigest()
        
        # Create API key data
        api_key_data = {
            "user_id": user_id,
            "label": label,
            "permissions": permissions,
            "hashed_secret": hashed_secret,
            "created_at": int(time.time()),
            "last_used_at": None,
            "enabled": True
        }
        
        # Save API key data
        api_key_path = os.path.join(self.api_keys_dir, f"{api_key}.json")
        with open(api_key_path, 'w') as f:
            json.dump(api_key_data, f, indent=2)
        
        # Add to user's API keys
        user_api_keys_path = os.path.join(self.api_keys_dir, f"user_{user_id}.json")
        
        if os.path.exists(user_api_keys_path):
            with open(user_api_keys_path, 'r') as f:
                user_api_keys = json.load(f)
        else:
            user_api_keys = {"api_keys": []}
        
        user_api_keys["api_keys"].append({
            "api_key": api_key,
            "label": label,
            "permissions": permissions,
            "created_at": api_key_data["created_at"],
            "last_used_at": api_key_data["last_used_at"],
            "enabled": api_key_data["enabled"]
        })
        
        with open(user_api_keys_path, 'w') as f:
            json.dump(user_api_keys, f, indent=2)
        
        return {
            "api_key": api_key,
            "api_secret": api_secret,
            "permissions": permissions,
            "label": label
        }
    
    def verify_api_key(self, api_key: str, api_secret: str) -> Dict[str, Any]:
        """
        Verify an API key and secret.
        
        Args:
            api_key: The API key
            api_secret: The API secret
            
        Returns:
            Dict containing verification results
        """
        # Get API key data
        api_key_path = os.path.join(self.api_keys_dir, f"{api_key}.json")
        
        if not os.path.exists(api_key_path):
            return {
                "valid": False,
                "error": "Invalid API key"
            }
        
        with open(api_key_path, 'r') as f:
            api_key_data = json.load(f)
        
        # Check if API key is enabled
        if not api_key_data.get("enabled", False):
            return {
                "valid": False,
                "error": "API key is disabled"
            }
        
        # Hash API secret and compare
        hashed_secret = hashlib.sha256(api_secret.encode()).hexdigest()
        
        if hashed_secret != api_key_data["hashed_secret"]:
            return {
                "valid": False,
                "error": "Invalid API secret"
            }
        
        # Update last used timestamp
        api_key_data["last_used_at"] = int(time.time())
        
        with open(api_key_path, 'w') as f:
            json.dump(api_key_data, f, indent=2)
        
        # Update user's API keys
        user_id = api_key_data["user_id"]
        user_api_keys_path = os.path.join(self.api_keys_dir, f"user_{user_id}.json")
        
        if os.path.exists(user_api_keys_path):
            with open(user_api_keys_path, 'r') as f:
                user_api_keys = json.load(f)
            
            for key in user_api_keys["api_keys"]:
                if key["api_key"] == api_key:
                    key["last_used_at"] = api_key_data["last_used_at"]
                    break
            
            with open(user_api_keys_path, 'w') as f:
                json.dump(user_api_keys, f, indent=2)
        
        return {
            "valid": True,
            "user_id": user_id,
            "permissions": api_key_data["permissions"]
        }
    
    def disable_api_key(self, user_id: str, api_key: str) -> Dict[str, Any]:
        """
        Disable an API key.
        
        Args:
            user_id: The ID of the user
            api_key: The API key to disable
            
        Returns:
            Dict containing the result of the operation
        """
        # Get API key data
        api_key_path = os.path.join(self.api_keys_dir, f"{api_key}.json")
        
        if not os.path.exists(api_key_path):
            return {
                "success": False,
                "error": "Invalid API key"
            }
        
        with open(api_key_path, 'r') as f:
            api_key_data = json.load(f)
        
        # Check if API key belongs to user
        if api_key_data["user_id"] != user_id:
            return {
                "success": False,
                "error": "API key does not belong to user"
            }
        
        # Disable API key
        api_key_data["enabled"] = False
        api_key_data["disabled_at"] = int(time.time())
        
        with open(api_key_path, 'w') as f:
            json.dump(api_key_data, f, indent=2)
        
        # Update user's API keys
        user_api_keys_path = os.path.join(self.api_keys_dir, f"user_{user_id}.json")
        
        if os.path.exists(user_api_keys_path):
            with open(user_api_keys_path, 'r') as f:
                user_api_keys = json.load(f)
            
            for key in user_api_keys["api_keys"]:
                if key["api_key"] == api_key:
                    key["enabled"] = False
                    key["disabled_at"] = api_key_data["disabled_at"]
                    break
            
            with open(user_api_keys_path, 'w') as f:
                json.dump(user_api_keys, f, indent=2)
        
        return {
            "success": True
        }
    
    def get_user_api_keys(self, user_id: str) -> List[Dict[str, Any]]:
        """
        Get a list of API keys for a user.
        
        Args:
            user_id: The ID of the user
            
        Returns:
            List of API keys
        """
        # Get user's API keys
        user_api_keys_path = os.path.join(self.api_keys_dir, f"user_{user_id}.json")
        
        if not os.path.exists(user_api_keys_path):
            return []
        
        with open(user_api_keys_path, 'r') as f:
            user_api_keys = json.load(f)
        
        return user_api_keys["api_keys"]
    
    def create_session(self, user_id: str, ip_address: str, user_agent: str) -> str:
        """
        Create a session for a user.
        
        Args:
            user_id: The ID of the user
            ip_address: The IP address of the user
            user_agent: The user agent of the user
            
        Returns:
            The session ID
        """
        # Generate session ID
        session_id = secrets.token_hex(16)
        
        # Create session data
        session_data = {
            "user_id": user_id,
            "ip_address": ip_address,
            "user_agent": user_agent,
            "created_at": int(time.time()),
            "last_active_at": int(time.time()),
            "active": True
        }
        
        # Save session data
        session_path = os.path.join(self.session_dir, f"{session_id}.json")
        with open(session_path, 'w') as f:
            json.dump(session_data, f, indent=2)
        
        return session_id
    
    def get_session(self, session_id: str) -> Dict[str, Any]:
        """
        Get session data.
        
        Args:
            session_id: The ID of the session
            
        Returns:
            Dict containing session data
        """
        # Get session data
        session_path = os.path.join(self.session_dir, f"{session_id}.json")
        
        if not os.path.exists(session_path):
            return None
        
        with open(session_path, 'r') as f:
            session_data = json.load(f)
        
        return session_data
    
    def update_session_activity(self, session_id: str) -> bool:
        """
        Update the last activity timestamp of a session.
        
        Args:
            session_id: The ID of the session
            
        Returns:
            True if successful, False otherwise
        """
        # Get session data
        session_path = os.path.join(self.session_dir, f"{session_id}.json")
        
        if not os.path.exists(session_path):
            return False
        
        with open(session_path, 'r') as f:
            session_data = json.load(f)
        
        # Update last activity timestamp
        session_data["last_active_at"] = int(time.time())
        
        with open(session_path, 'w') as f:
            json.dump(session_data, f, indent=2)
        
        return True
    
    def end_session(self, session_id: str) -> bool:
        """
        End a session.
        
        Args:
            session_id: The ID of the session
            
        Returns:
            True if successful, False otherwise
        """
        # Get session data
        session_path = os.path.join(self.session_dir, f"{session_id}.json")
        
        if not os.path.exists(session_path):
            return False
        
        with open(session_path, 'r') as f:
            session_data = json.load(f)
        
        # Mark session as inactive
        session_data["active"] = False
        session_data["ended_at"] = int(time.time())
        
        with open(session_path, 'w') as f:
            json.dump(session_data, f, indent=2)
        
        return True
    
    def end_all_user_sessions(self, user_id: str, except_session_id: str = None) -> int:
        """
        End all sessions for a user.
        
        Args:
            user_id: The ID of the user
            except_session_id: A session ID to exclude
            
        Returns:
            The number of sessions ended
        """
        ended_count = 0
        
        # Iterate through all session files
        for filename in os.listdir(self.session_dir):
            if filename.endswith(".json"):
                session_path = os.path.join(self.session_dir, filename)
                
                try:
                    with open(session_path, 'r') as f:
                        session_data = json.load(f)
                    
                    # Check if session belongs to user and is active
                    if (session_data.get("user_id") == user_id and 
                        session_data.get("active", False) and 
                        (except_session_id is None or filename != f"{except_session_id}.json")):
                        
                        # Mark session as inactive
                        session_data["active"] = False
                        session_data["ended_at"] = int(time.time())
                        
                        with open(session_path, 'w') as f:
                            json.dump(session_data, f, indent=2)
                        
                        ended_count += 1
                except Exception as e:
                    print(f"Error processing session file {filename}: {e}")
        
        return ended_count
    
    def check_rate_limit(self, key: str, limit: int, window: int) -> Dict[str, Any]:
        """
        Check if a rate limit has been exceeded.
        
        Args:
            key: The rate limit key
            limit: The maximum number of attempts
            window: The time window in seconds
            
        Returns:
            Dict containing rate limit information
        """
        # Create rate limit file path
        rate_limit_path = os.path.join(self.rate_limit_dir, f"{key}.json")
        
        # Get current time
        now = int(time.time())
        
        # Initialize rate limit data
        if os.path.exists(rate_limit_path):
            with open(rate_limit_path, 'r') as f:
                rate_limit_data = json.load(f)
        else:
            rate_limit_data = {
                "attempts": [],
                "blocked_until": None
            }
        
        # Check if blocked
        if rate_limit_data.get("blocked_until") and rate_limit_data["blocked_until"] > now:
            return {
                "allowed": False,
                "remaining": 0,
                "reset_at": rate_limit_data["blocked_until"],
                "blocked": True
            }
        
        # Clear block if expired
        if rate_limit_data.get("blocked_until"):
            rate_limit_data["blocked_until"] = None
        
        # Filter attempts within window
        rate_limit_data["attempts"] = [attempt for attempt in rate_limit_data["attempts"] if attempt > now - window]
        
        # Check if limit exceeded
        if len(rate_limit_data["attempts"]) >= limit:
            # Block for window duration
            rate_limit_data["blocked_until"] = now + window
            
            with open(rate_limit_path, 'w') as f:
                json.dump(rate_limit_data, f, indent=2)
            
            return {
                "allowed": False,
                "remaining": 0,
                "reset_at": rate_limit_data["blocked_until"],
                "blocked": True
            }
        
        # Add attempt
        rate_limit_data["attempts"].append(now)
        
        with open(rate_limit_path, 'w') as f:
            json.dump(rate_limit_data, f, indent=2)
        
        return {
            "allowed": True,
            "remaining": limit - len(rate_limit_data["attempts"]),
            "reset_at": now + window,
            "blocked": False
        }
    
    def reset_rate_limit(self, key: str) -> bool:
        """
        Reset a rate limit.
        
        Args:
            key: The rate limit key
            
        Returns:
            True if successful, False otherwise
        """
        # Create rate limit file path
        rate_limit_path = os.path.join(self.rate_limit_dir, f"{key}.json")
        
        if not os.path.exists(rate_limit_path):
            return False
        
        # Reset rate limit data
        rate_limit_data = {
            "attempts": [],
            "blocked_until": None
        }
        
        with open(rate_limit_path, 'w') as f:
            json.dump(rate_limit_data, f, indent=2)
        
        return True
    
    def check_login_rate_limit(self, identifier: str) -> Dict[str, Any]:
        """
        Check login rate limit.
        
        Args:
            identifier: The identifier to check (e.g., username, IP address)
            
        Returns:
            Dict containing rate limit information
        """
        return self.check_rate_limit(
            key=f"login_{identifier}",
            limit=self.rate_limit_login_attempts,
            window=self.rate_limit_login_window
        )
    
    def reset_login_rate_limit(self, identifier: str) -> bool:
        """
        Reset login rate limit.
        
        Args:
            identifier: The identifier to reset
            
        Returns:
            True if successful, False otherwise
        """
        return self.reset_rate_limit(f"login_{identifier}")
    
    def generate_signature(self, data: str, secret: str) -> str:
        """
        Generate an HMAC signature.
        
        Args:
            data: The data to sign
            secret: The secret key
            
        Returns:
            The signature
        """
        h = hmac.new(secret.encode(), data.encode(), hashlib.sha256)
        return h.hexdigest()
    
    def verify_signature(self, data: str, signature: str, secret: str) -> bool:
        """
        Verify an HMAC signature.
        
        Args:
            data: The data that was signed
            signature: The signature to verify
            secret: The secret key
            
        Returns:
            True if the signature is valid, False otherwise
        """
        expected_signature = self.generate_signature(data, secret)
        return hmac.compare_digest(signature, expected_signature)
