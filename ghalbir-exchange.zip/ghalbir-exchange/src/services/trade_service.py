from typing import Dict, List, Optional
import uuid
from decimal import Decimal
from datetime import datetime
import json
import os

from src.models.trade import Trade
from src.models.order import Order, OrderSide

class TradeService:
    def __init__(self, data_dir: str = "/home/ubuntu/ghalbir-exchange/data"):
        self.data_dir = data_dir
        self.trades_dir = os.path.join(data_dir, "trades")
        
        # Ensure directories exist
        os.makedirs(self.trades_dir, exist_ok=True)
    
    def _get_trade_path(self, trade_id: str) -> str:
        """Get path to trade file"""
        return os.path.join(self.trades_dir, f"{trade_id}.json")
    
    def _save_trade(self, trade: Trade) -> None:
        """Save trade to disk"""
        trade_path = self._get_trade_path(trade.id)
        
        with open(trade_path, 'w') as f:
            json.dump(trade.to_dict(), f, indent=2)
    
    def create_trade(self, buyer_order: Order, seller_order: Order, 
                    amount: Decimal, price: Decimal, fee_rate: Decimal = Decimal('0.001')) -> Trade:
        """Create a new trade between buyer and seller orders"""
        if buyer_order.side != OrderSide.BUY:
            raise ValueError("Buyer order must be a buy order")
        
        if seller_order.side != OrderSide.SELL:
            raise ValueError("Seller order must be a sell order")
        
        trade_id = str(uuid.uuid4())
        fee = amount * price * fee_rate
        
        trade = Trade(
            id=trade_id,
            buyer_order_id=buyer_order.id,
            seller_order_id=seller_order.id,
            trading_pair=buyer_order.trading_pair,
            amount=amount,
            price=price,
            fee=fee,
            buyer_id=buyer_order.user_id,
            seller_id=seller_order.user_id
        )
        
        self._save_trade(trade)
        
        return trade
    
    def get_trade(self, trade_id: str) -> Optional[Trade]:
        """Get trade by ID"""
        trade_path = self._get_trade_path(trade_id)
        
        if not os.path.exists(trade_path):
            return None
        
        try:
            with open(trade_path, 'r') as f:
                trade_data = json.load(f)
                return Trade.from_dict(trade_data)
        except Exception as e:
            print(f"Error loading trade {trade_id}: {e}")
            return None
    
    def get_user_trades(self, user_id: str) -> List[Trade]:
        """Get all trades for a user"""
        user_trades = []
        
        if not os.path.exists(self.trades_dir):
            return user_trades
        
        for filename in os.listdir(self.trades_dir):
            if filename.endswith(".json"):
                trade_path = os.path.join(self.trades_dir, filename)
                
                try:
                    with open(trade_path, 'r') as f:
                        trade_data = json.load(f)
                        if trade_data["buyer_id"] == user_id or trade_data["seller_id"] == user_id:
                            user_trades.append(Trade.from_dict(trade_data))
                except Exception as e:
                    print(f"Error loading trade {filename}: {e}")
        
        # Sort by created_at (newest first)
        user_trades.sort(key=lambda x: x.created_at, reverse=True)
        
        return user_trades
    
    def get_market_trades(self, trading_pair: str, limit: int = 100) -> List[Trade]:
        """Get recent trades for a market"""
        market_trades = []
        
        if not os.path.exists(self.trades_dir):
            return market_trades
        
        for filename in os.listdir(self.trades_dir):
            if filename.endswith(".json"):
                trade_path = os.path.join(self.trades_dir, filename)
                
                try:
                    with open(trade_path, 'r') as f:
                        trade_data = json.load(f)
                        if trade_data["trading_pair"] == trading_pair:
                            market_trades.append(Trade.from_dict(trade_data))
                except Exception as e:
                    print(f"Error loading trade {filename}: {e}")
        
        # Sort by created_at (newest first)
        market_trades.sort(key=lambda x: x.created_at, reverse=True)
        
        # Limit the number of trades
        return market_trades[:limit]
    
    def get_market_statistics(self, trading_pair: str) -> Dict:
        """Get market statistics for a trading pair"""
        trades = self.get_market_trades(trading_pair, limit=1000)
        
        if not trades:
            return {
                "last_price": "0",
                "24h_high": "0",
                "24h_low": "0",
                "24h_volume": "0",
                "24h_change": "0"
            }
        
        # Calculate 24h statistics
        now = datetime.now()
        trades_24h = [t for t in trades if (now - t.created_at).total_seconds() <= 86400]
        
        if not trades_24h:
            return {
                "last_price": str(trades[0].price),
                "24h_high": "0",
                "24h_low": "0",
                "24h_volume": "0",
                "24h_change": "0"
            }
        
        prices_24h = [t.price for t in trades_24h]
        volumes_24h = [t.amount * t.price for t in trades_24h]
        
        last_price = trades_24h[0].price
        high_24h = max(prices_24h)
        low_24h = min(prices_24h)
        volume_24h = sum(volumes_24h)
        
        # Calculate 24h price change
        first_price = trades_24h[-1].price
        price_change = (last_price - first_price) / first_price if first_price > 0 else Decimal('0')
        
        return {
            "last_price": str(last_price),
            "24h_high": str(high_24h),
            "24h_low": str(low_24h),
            "24h_volume": str(volume_24h),
            "24h_change": str(price_change)
        }
