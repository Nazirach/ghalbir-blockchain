from typing import Dict, List, Optional
import uuid
from decimal import Decimal
from datetime import datetime
import json
import os

from src.models.wallet import Wallet

class WalletService:
    def __init__(self, data_dir: str = "/home/ubuntu/ghalbir-exchange/data"):
        self.data_dir = data_dir
        self.wallets_dir = os.path.join(data_dir, "wallets")
        
        # Ensure directories exist
        os.makedirs(self.wallets_dir, exist_ok=True)
        
        # In-memory cache of wallets
        self.wallets: Dict[str, Dict[str, Wallet]] = {}  # user_id -> asset -> wallet
    
    def _get_wallet_path(self, wallet_id: str) -> str:
        """Get path to wallet file"""
        return os.path.join(self.wallets_dir, f"{wallet_id}.json")
    
    def _save_wallet(self, wallet: Wallet) -> None:
        """Save wallet to disk"""
        wallet_path = self._get_wallet_path(wallet.id)
        
        with open(wallet_path, 'w') as f:
            json.dump(wallet.to_dict(), f, indent=2)
        
        # Update in-memory cache
        if wallet.user_id not in self.wallets:
            self.wallets[wallet.user_id] = {}
        
        self.wallets[wallet.user_id][wallet.asset] = wallet
    
    def create_wallet(self, user_id: str, asset: str, address: str) -> Wallet:
        """Create a new wallet for a user and asset"""
        # Check if wallet already exists
        existing_wallet = self.get_wallet(user_id, asset)
        if existing_wallet:
            return existing_wallet
        
        wallet_id = str(uuid.uuid4())
        
        wallet = Wallet(
            id=wallet_id,
            user_id=user_id,
            asset=asset,
            balance=Decimal('0'),
            address=address
        )
        
        self._save_wallet(wallet)
        
        return wallet
    
    def get_wallet(self, user_id: str, asset: str) -> Optional[Wallet]:
        """Get wallet for a user and asset"""
        # Check in-memory cache first
        if user_id in self.wallets and asset in self.wallets[user_id]:
            return self.wallets[user_id][asset]
        
        # Try to load from disk
        if not os.path.exists(self.wallets_dir):
            return None
        
        for filename in os.listdir(self.wallets_dir):
            if filename.endswith(".json"):
                wallet_path = os.path.join(self.wallets_dir, filename)
                
                try:
                    with open(wallet_path, 'r') as f:
                        wallet_data = json.load(f)
                        if wallet_data["user_id"] == user_id and wallet_data["asset"] == asset:
                            wallet = Wallet.from_dict(wallet_data)
                            
                            # Update in-memory cache
                            if user_id not in self.wallets:
                                self.wallets[user_id] = {}
                            
                            self.wallets[user_id][asset] = wallet
                            
                            return wallet
                except Exception as e:
                    print(f"Error loading wallet {filename}: {e}")
        
        return None
    
    def get_user_wallets(self, user_id: str) -> List[Wallet]:
        """Get all wallets for a user"""
        user_wallets = []
        
        if not os.path.exists(self.wallets_dir):
            return user_wallets
        
        for filename in os.listdir(self.wallets_dir):
            if filename.endswith(".json"):
                wallet_path = os.path.join(self.wallets_dir, filename)
                
                try:
                    with open(wallet_path, 'r') as f:
                        wallet_data = json.load(f)
                        if wallet_data["user_id"] == user_id:
                            wallet = Wallet.from_dict(wallet_data)
                            user_wallets.append(wallet)
                            
                            # Update in-memory cache
                            if user_id not in self.wallets:
                                self.wallets[user_id] = {}
                            
                            self.wallets[user_id][wallet.asset] = wallet
                except Exception as e:
                    print(f"Error loading wallet {filename}: {e}")
        
        return user_wallets
    
    def deposit(self, user_id: str, asset: str, amount: Decimal) -> Wallet:
        """Deposit funds to a wallet"""
        wallet = self.get_wallet(user_id, asset)
        
        if not wallet:
            raise ValueError(f"Wallet not found for user {user_id} and asset {asset}")
        
        wallet.deposit(amount)
        self._save_wallet(wallet)
        
        return wallet
    
    def withdraw(self, user_id: str, asset: str, amount: Decimal) -> Wallet:
        """Withdraw funds from a wallet"""
        wallet = self.get_wallet(user_id, asset)
        
        if not wallet:
            raise ValueError(f"Wallet not found for user {user_id} and asset {asset}")
        
        wallet.withdraw(amount)
        self._save_wallet(wallet)
        
        return wallet
    
    def check_balance(self, user_id: str, asset: str, amount: Decimal) -> bool:
        """Check if user has sufficient balance"""
        wallet = self.get_wallet(user_id, asset)
        
        if not wallet:
            return False
        
        return wallet.has_sufficient_balance(amount)
    
    def transfer(self, from_user_id: str, to_user_id: str, asset: str, amount: Decimal) -> None:
        """Transfer funds between users"""
        from_wallet = self.get_wallet(from_user_id, asset)
        to_wallet = self.get_wallet(to_user_id, asset)
        
        if not from_wallet:
            raise ValueError(f"Wallet not found for user {from_user_id} and asset {asset}")
        
        if not to_wallet:
            raise ValueError(f"Wallet not found for user {to_user_id} and asset {asset}")
        
        from_wallet.withdraw(amount)
        to_wallet.deposit(amount)
        
        self._save_wallet(from_wallet)
        self._save_wallet(to_wallet)
