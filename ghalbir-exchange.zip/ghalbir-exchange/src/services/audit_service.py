from typing import Dict, List, Optional, Any
import os
import json
import time
import logging
import ipaddress
from datetime import datetime

class AuditService:
    """
    Service for handling audit logging and security monitoring for the Ghalbir Exchange.
    This service provides methods for logging security events, monitoring for suspicious activity,
    and generating audit reports.
    """
    
    def __init__(self, data_dir: str = "/home/ubuntu/ghalbir-exchange/data"):
        """
        Initialize the audit service.
        
        Args:
            data_dir: The data directory to use
        """
        self.data_dir = data_dir
        
        # Create audit data directory
        self.audit_dir = os.path.join(data_dir, "audit")
        os.makedirs(self.audit_dir, exist_ok=True)
        
        # Create logs directory
        self.logs_dir = os.path.join(self.audit_dir, "logs")
        os.makedirs(self.logs_dir, exist_ok=True)
        
        # Create alerts directory
        self.alerts_dir = os.path.join(self.audit_dir, "alerts")
        os.makedirs(self.alerts_dir, exist_ok=True)
        
        # Create reports directory
        self.reports_dir = os.path.join(self.audit_dir, "reports")
        os.makedirs(self.reports_dir, exist_ok=True)
        
        # Initialize logger
        self._setup_logger()
        
        # Suspicious IP ranges (example: private networks)
        self.suspicious_ip_ranges = [
            "10.0.0.0/8",
            "172.16.0.0/12",
            "192.168.0.0/16",
            "127.0.0.0/8"
        ]
        
        # Suspicious countries (example)
        self.suspicious_countries = []
        
        # Suspicious user agents (example)
        self.suspicious_user_agents = [
            "sqlmap",
            "nikto",
            "nmap",
            "masscan",
            "zgrab",
            "gobuster",
            "dirbuster"
        ]
    
    def _setup_logger(self):
        """
        Set up the logger.
        """
        # Create logger
        self.logger = logging.getLogger("ghalbir_audit")
        self.logger.setLevel(logging.INFO)
        
        # Create file handler
        log_file = os.path.join(self.logs_dir, f"audit_{datetime.now().strftime('%Y%m%d')}.log")
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)
        
        # Create formatter
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        
        # Add handler to logger
        self.logger.addHandler(file_handler)
    
    def log_event(self, event_type: str, user_id: Optional[str], ip_address: Optional[str], 
                  details: Dict[str, Any], severity: str = "info") -> None:
        """
        Log an audit event.
        
        Args:
            event_type: The type of event
            user_id: The ID of the user (if applicable)
            ip_address: The IP address (if applicable)
            details: Additional details about the event
            severity: The severity of the event (info, warning, error, critical)
        """
        # Create event data
        event_data = {
            "timestamp": int(time.time()),
            "datetime": datetime.now().isoformat(),
            "event_type": event_type,
            "user_id": user_id,
            "ip_address": ip_address,
            "details": details,
            "severity": severity
        }
        
        # Log to file
        log_message = f"{event_type} - User: {user_id} - IP: {ip_address} - {json.dumps(details)}"
        
        if severity == "info":
            self.logger.info(log_message)
        elif severity == "warning":
            self.logger.warning(log_message)
        elif severity == "error":
            self.logger.error(log_message)
        elif severity == "critical":
            self.logger.critical(log_message)
        
        # Save detailed event data
        event_id = f"{int(time.time())}_{event_type.replace(' ', '_')}"
        event_path = os.path.join(self.logs_dir, f"event_{event_id}.json")
        
        with open(event_path, 'w') as f:
            json.dump(event_data, f, indent=2)
        
        # Check if event should trigger an alert
        if severity in ["warning", "error", "critical"]:
            self._create_alert(event_data)
        
        # Check for suspicious activity
        if ip_address:
            self._check_suspicious_ip(ip_address, event_data)
    
    def log_login_attempt(self, user_id: str, ip_address: str, user_agent: str, 
                          success: bool, details: Dict[str, Any]) -> None:
        """
        Log a login attempt.
        
        Args:
            user_id: The ID of the user
            ip_address: The IP address
            user_agent: The user agent
            success: Whether the login was successful
            details: Additional details about the login attempt
        """
        event_type = "login_success" if success else "login_failure"
        severity = "info" if success else "warning"
        
        details["user_agent"] = user_agent
        
        self.log_event(
            event_type=event_type,
            user_id=user_id,
            ip_address=ip_address,
            details=details,
            severity=severity
        )
        
        # Check for suspicious user agent
        self._check_suspicious_user_agent(user_agent, {
            "event_type": event_type,
            "user_id": user_id,
            "ip_address": ip_address,
            "details": details
        })
    
    def log_api_request(self, api_key: str, endpoint: str, ip_address: str, 
                        user_agent: str, success: bool, details: Dict[str, Any]) -> None:
        """
        Log an API request.
        
        Args:
            api_key: The API key used
            endpoint: The API endpoint
            ip_address: The IP address
            user_agent: The user agent
            success: Whether the request was successful
            details: Additional details about the request
        """
        event_type = "api_request"
        severity = "info" if success else "warning"
        
        details.update({
            "api_key": api_key,
            "endpoint": endpoint,
            "user_agent": user_agent,
            "success": success
        })
        
        self.log_event(
            event_type=event_type,
            user_id=None,  # API key is used instead
            ip_address=ip_address,
            details=details,
            severity=severity
        )
    
    def log_transaction(self, transaction_id: str, user_id: str, transaction_type: str, 
                        amount: str, asset: str, details: Dict[str, Any]) -> None:
        """
        Log a transaction.
        
        Args:
            transaction_id: The ID of the transaction
            user_id: The ID of the user
            transaction_type: The type of transaction (deposit, withdrawal, trade)
            amount: The amount of the transaction
            asset: The asset involved in the transaction
            details: Additional details about the transaction
        """
        event_type = f"{transaction_type}_transaction"
        
        details.update({
            "transaction_id": transaction_id,
            "amount": amount,
            "asset": asset
        })
        
        self.log_event(
            event_type=event_type,
            user_id=user_id,
            ip_address=None,
            details=details,
            severity="info"
        )
    
    def log_order(self, order_id: str, user_id: str, order_type: str, 
                  side: str, amount: str, price: str, details: Dict[str, Any]) -> None:
        """
        Log an order.
        
        Args:
            order_id: The ID of the order
            user_id: The ID of the user
            order_type: The type of order (limit, market)
            side: The side of the order (buy, sell)
            amount: The amount of the order
            price: The price of the order
            details: Additional details about the order
        """
        event_type = f"{order_type}_{side}_order"
        
        details.update({
            "order_id": order_id,
            "amount": amount,
            "price": price
        })
        
        self.log_event(
            event_type=event_type,
            user_id=user_id,
            ip_address=None,
            details=details,
            severity="info"
        )
    
    def log_security_event(self, event_type: str, user_id: Optional[str], ip_address: Optional[str], 
                           details: Dict[str, Any], severity: str = "warning") -> None:
        """
        Log a security event.
        
        Args:
            event_type: The type of event
            user_id: The ID of the user (if applicable)
            ip_address: The IP address (if applicable)
            details: Additional details about the event
            severity: The severity of the event (warning, error, critical)
        """
        event_type = f"security_{event_type}"
        
        self.log_event(
            event_type=event_type,
            user_id=user_id,
            ip_address=ip_address,
            details=details,
            severity=severity
        )
    
    def _create_alert(self, event_data: Dict[str, Any]) -> None:
        """
        Create an alert for an event.
        
        Args:
            event_data: The event data
        """
        alert_id = f"{int(time.time())}_{event_data['event_type'].replace(' ', '_')}"
        alert_path = os.path.join(self.alerts_dir, f"alert_{alert_id}.json")
        
        with open(alert_path, 'w') as f:
            json.dump(event_data, f, indent=2)
    
    def _check_suspicious_ip(self, ip_address: str, event_data: Dict[str, Any]) -> None:
        """
        Check if an IP address is suspicious.
        
        Args:
            ip_address: The IP address to check
            event_data: The event data
        """
        try:
            ip = ipaddress.ip_address(ip_address)
            
            # Check if IP is in suspicious ranges
            for ip_range in self.suspicious_ip_ranges:
                if ip in ipaddress.ip_network(ip_range):
                    self.log_security_event(
                        event_type="suspicious_ip",
                        user_id=event_data.get("user_id"),
                        ip_address=ip_address,
                        details={
                            "reason": f"IP in suspicious range: {ip_range}",
                            "original_event": event_data
                        },
                        severity="warning"
                    )
                    break
        except ValueError:
            # Invalid IP address
            pass
    
    def _check_suspicious_user_agent(self, user_agent: str, event_data: Dict[str, Any]) -> None:
        """
        Check if a user agent is suspicious.
        
        Args:
            user_agent: The user agent to check
            event_data: The event data
        """
        if user_agent:
            for suspicious_ua in self.suspicious_user_agents:
                if suspicious_ua.lower() in user_agent.lower():
                    self.log_security_event(
                        event_type="suspicious_user_agent",
                        user_id=event_data.get("user_id"),
                        ip_address=event_data.get("ip_address"),
                        details={
                            "user_agent": user_agent,
                            "reason": f"User agent contains suspicious string: {suspicious_ua}",
                            "original_event": event_data
                        },
                        severity="warning"
                    )
                    break
    
    def generate_daily_report(self, date: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate a daily audit report.
        
        Args:
            date: The date to generate the report for (YYYYMMDD format)
                 If None, generates report for the current day
        
        Returns:
            Dict containing the report data
        """
        if date is None:
            date = datetime.now().strftime('%Y%m%d')
        
        # Get log file for the specified date
        log_file = os.path.join(self.logs_dir, f"audit_{date}.log")
        
        if not os.path.exists(log_file):
            return {
                "date": date,
                "error": "No log file found for the specified date"
            }
        
        # Initialize report data
        report_data = {
            "date": date,
            "generated_at": datetime.now().isoformat(),
            "events": {
                "total": 0,
                "by_type": {},
                "by_severity": {
                    "info": 0,
                    "warning": 0,
                    "error": 0,
                    "critical": 0
                }
            },
            "logins": {
                "total": 0,
                "successful": 0,
                "failed": 0
            },
            "transactions": {
                "total": 0,
                "by_type": {}
            },
            "orders": {
                "total": 0,
                "by_type": {}
            },
            "security_events": {
                "total": 0,
                "by_type": {}
            },
            "alerts": {
                "total": 0,
                "by_severity": {
                    "warning": 0,
                    "error": 0,
                    "critical": 0
                }
            }
        }
        
        # Process event files for the specified date
        for filename in os.listdir(self.logs_dir):
            if filename.startswith("event_") and filename.endswith(".json"):
                event_path = os.path.join(self.logs_dir, filename)
                
                try:
                    with open(event_path, 'r') as f:
                        event_data = json.load(f)
                    
                    # Check if event is from the specified date
                    event_date = datetime.fromtimestamp(event_data["timestamp"]).strftime('%Y%m%d')
                    
                    if event_date == date:
                        # Increment total events
                        report_data["events"]["total"] += 1
                        
                        # Increment events by type
                        event_type = event_data["event_type"]
                        report_data["events"]["by_type"][event_type] = report_data["events"]["by_type"].get(event_type, 0) + 1
                        
                        # Increment events by severity
                        severity = event_data["severity"]
                        report_data["events"]["by_severity"][severity] = report_data["events"]["by_severity"].get(severity, 0) + 1
                        
                        # Process specific event types
                        if event_type == "login_success":
                            report_data["logins"]["total"] += 1
                            report_data["logins"]["successful"] += 1
                        elif event_type == "login_failure":
                            report_data["logins"]["total"] += 1
                            report_data["logins"]["failed"] += 1
                        elif "transaction" in event_type:
                            report_data["transactions"]["total"] += 1
                            report_data["transactions"]["by_type"][event_type] = report_data["transactions"]["by_type"].get(event_type, 0) + 1
                        elif "order" in event_type:
                            report_data["orders"]["total"] += 1
                            report_data["orders"]["by_type"][event_type] = report_data["orders"]["by_type"].get(event_type, 0) + 1
                        elif "security" in event_type:
                            report_data["security_events"]["total"] += 1
                            report_data["security_events"]["by_type"][event_type] = report_data["security_events"]["by_type"].get(event_type, 0) + 1
                except Exception as e:
                    print(f"Error processing event file {filename}: {e}")
        
        # Process alert files for the specified date
        for filename in os.listdir(self.alerts_dir):
            if filename.startswith("alert_") and filename.endswith(".json"):
                alert_path = os.path.join(self.alerts_dir, filename)
                
                try:
                    with open(alert_path, 'r') as f:
                        alert_data = json.load(f)
                    
                    # Check if alert is from the specified date
                    alert_date = datetime.fromtimestamp(alert_data["timestamp"]).strftime('%Y%m%d')
                    
                    if alert_date == date:
                        # Increment total alerts
                        report_data["alerts"]["total"] += 1
                        
                        # Increment alerts by severity
                        severity = alert_data["severity"]
                        report_data["alerts"]["by_severity"][severity] = report_data["alerts"]["by_severity"].get(severity, 0) + 1
                except Exception as e:
                    print(f"Error processing alert file {filename}: {e}")
        
        # Save report
        report_path = os.path.join(self.reports_dir, f"report_{date}.json")
        with open(report_path, 'w') as f:
            json.dump(report_data, f, indent=2)
        
        return report_data
    
    def get_recent_alerts(self, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get recent alerts.
        
        Args:
            limit: The maximum number of alerts to return
            
        Returns:
            List of recent alerts
        """
        alerts = []
        
        # Get all alert files
        alert_files = []
        for filename in os.listdir(self.alerts_dir):
            if filename.startswith("alert_") and filename.endswith(".json"):
                alert_path = os.path.join(self.alerts_dir, filename)
                alert_files.append((filename, os.path.getmtime(alert_path)))
        
        # Sort by modification time (newest first)
        alert_files.sort(key=lambda x: x[1], reverse=True)
        
        # Get the most recent alerts
        for i, (filename, _) in enumerate(alert_files):
            if i >= limit:
                break
            
            alert_path = os.path.join(self.alerts_dir, filename)
            
            try:
                with open(alert_path, 'r') as f:
                    alert_data = json.load(f)
                
                alerts.append(alert_data)
            except Exception as e:
                print(f"Error reading alert file {filename}: {e}")
        
        return alerts
    
    def get_user_activity(self, user_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get recent activity for a user.
        
        Args:
            user_id: The ID of the user
            limit: The maximum number of events to return
            
        Returns:
            List of recent events for the user
        """
        events = []
        
        # Get all event files
        event_files = []
        for filename in os.listdir(self.logs_dir):
            if filename.startswith("event_") and filename.endswith(".json"):
                event_path = os.path.join(self.logs_dir, filename)
                event_files.append((filename, os.path.getmtime(event_path)))
        
        # Sort by modification time (newest first)
        event_files.sort(key=lambda x: x[1], reverse=True)
        
        # Get events for the user
        for filename, _ in event_files:
            if len(events) >= limit:
                break
            
            event_path = os.path.join(self.logs_dir, filename)
            
            try:
                with open(event_path, 'r') as f:
                    event_data = json.load(f)
                
                if event_data.get("user_id") == user_id:
                    events.append(event_data)
            except Exception as e:
                print(f"Error reading event file {filename}: {e}")
        
        return events
    
    def get_ip_activity(self, ip_address: str, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get recent activity for an IP address.
        
        Args:
            ip_address: The IP address
            limit: The maximum number of events to return
            
        Returns:
            List of recent events for the IP address
        """
        events = []
        
        # Get all event files
        event_files = []
        for filename in os.listdir(self.logs_dir):
            if filename.startswith("event_") and filename.endswith(".json"):
                event_path = os.path.join(self.logs_dir, filename)
                event_files.append((filename, os.path.getmtime(event_path)))
        
        # Sort by modification time (newest first)
        event_files.sort(key=lambda x: x[1], reverse=True)
        
        # Get events for the IP address
        for filename, _ in event_files:
            if len(events) >= limit:
                break
            
            event_path = os.path.join(self.logs_dir, filename)
            
            try:
                with open(event_path, 'r') as f:
                    event_data = json.load(f)
                
                if event_data.get("ip_address") == ip_address:
                    events.append(event_data)
            except Exception as e:
                print(f"Error reading event file {filename}: {e}")
        
        return events
