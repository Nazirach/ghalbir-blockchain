from typing import Dict, List, Optional
import uuid
from decimal import Decimal
from datetime import datetime
import json
import os

from src.models.order import Order, OrderStatus, OrderSide, OrderType

class OrderService:
    def __init__(self, data_dir: str = "/home/ubuntu/ghalbir-exchange/data"):
        self.data_dir = data_dir
        self.orders_dir = os.path.join(data_dir, "orders")
        
        # Ensure directories exist
        os.makedirs(self.orders_dir, exist_ok=True)
        
        # In-memory cache of active orders
        self.active_orders: Dict[str, Order] = {}
        
        # Load existing orders
        self._load_orders()
    
    def _load_orders(self) -> None:
        """Load existing orders from disk"""
        if not os.path.exists(self.orders_dir):
            return
        
        for filename in os.listdir(self.orders_dir):
            if filename.endswith(".json"):
                order_id = filename[:-5]  # Remove .json extension
                order_path = os.path.join(self.orders_dir, filename)
                
                try:
                    with open(order_path, 'r') as f:
                        order_data = json.load(f)
                        order = Order.from_dict(order_data)
                        
                        # Only cache active orders
                        if order.is_active():
                            self.active_orders[order.id] = order
                except Exception as e:
                    print(f"Error loading order {order_id}: {e}")
    
    def _save_order(self, order: Order) -> None:
        """Save order to disk"""
        order_path = os.path.join(self.orders_dir, f"{order.id}.json")
        
        with open(order_path, 'w') as f:
            json.dump(order.to_dict(), f, indent=2)
    
    def create_order(self, user_id: str, side: OrderSide, order_type: OrderType, 
                    trading_pair: str, amount: Decimal, price: Decimal) -> Order:
        """Create a new order"""
        order_id = str(uuid.uuid4())
        
        order = Order(
            id=order_id,
            user_id=user_id,
            side=side,
            order_type=order_type,
            trading_pair=trading_pair,
            amount=amount,
            price=price,
            status=OrderStatus.PENDING
        )
        
        # Save to disk
        self._save_order(order)
        
        # Add to active orders
        self.active_orders[order.id] = order
        
        return order
    
    def get_order(self, order_id: str) -> Optional[Order]:
        """Get order by ID"""
        # Check in-memory cache first
        if order_id in self.active_orders:
            return self.active_orders[order_id]
        
        # Try to load from disk
        order_path = os.path.join(self.orders_dir, f"{order_id}.json")
        if os.path.exists(order_path):
            try:
                with open(order_path, 'r') as f:
                    order_data = json.load(f)
                    return Order.from_dict(order_data)
            except Exception as e:
                print(f"Error loading order {order_id}: {e}")
        
        return None
    
    def get_user_orders(self, user_id: str) -> List[Order]:
        """Get all orders for a user"""
        user_orders = []
        
        if not os.path.exists(self.orders_dir):
            return user_orders
        
        for filename in os.listdir(self.orders_dir):
            if filename.endswith(".json"):
                order_path = os.path.join(self.orders_dir, filename)
                
                try:
                    with open(order_path, 'r') as f:
                        order_data = json.load(f)
                        if order_data["user_id"] == user_id:
                            user_orders.append(Order.from_dict(order_data))
                except Exception as e:
                    print(f"Error loading order {filename}: {e}")
        
        return user_orders
    
    def get_active_orders_for_trading_pair(self, trading_pair: str) -> List[Order]:
        """Get all active orders for a trading pair"""
        return [
            order for order in self.active_orders.values()
            if order.trading_pair == trading_pair and order.is_active()
        ]
    
    def update_order(self, order: Order) -> None:
        """Update an existing order"""
        # Save to disk
        self._save_order(order)
        
        # Update in-memory cache if active
        if order.is_active():
            self.active_orders[order.id] = order
        elif order.id in self.active_orders:
            del self.active_orders[order.id]
    
    def cancel_order(self, order_id: str) -> Optional[Order]:
        """Cancel an order"""
        order = self.get_order(order_id)
        if not order:
            return None
        
        if not order.is_active():
            return order  # Already cancelled or filled
        
        order.cancel()
        self.update_order(order)
        
        return order
    
    def get_order_book(self, trading_pair: str) -> Dict[str, List[Dict]]:
        """Get order book for a trading pair"""
        active_orders = self.get_active_orders_for_trading_pair(trading_pair)
        
        bids = []
        asks = []
        
        for order in active_orders:
            order_entry = {
                "id": order.id,
                "price": str(order.price),
                "amount": str(order.remaining_amount)
            }
            
            if order.side == OrderSide.BUY:
                bids.append(order_entry)
            else:
                asks.append(order_entry)
        
        # Sort bids by price (descending)
        bids.sort(key=lambda x: Decimal(x["price"]), reverse=True)
        
        # Sort asks by price (ascending)
        asks.sort(key=lambda x: Decimal(x["price"]))
        
        return {
            "bids": bids,
            "asks": asks
        }
