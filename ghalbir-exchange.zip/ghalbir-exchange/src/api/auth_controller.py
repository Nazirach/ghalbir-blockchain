from typing import Dict, List, Optional, Any
import uuid
import json
import os
from datetime import datetime
import secrets
import re
import jwt

from src.models.user import User, UserStatus, KYCStatus
from src.services.user_service import UserService

class AuthController:
    def __init__(self, user_service: UserService):
        self.user_service = user_service
    
    def register(self, email: str, password: str, full_name: str) -> Dict[str, Any]:
        """Register a new user"""
        # Validate email
        if not self._validate_email(email):
            return {
                "success": False,
                "error": "Invalid email format"
            }
        
        # Validate password
        if not self._validate_password(password):
            return {
                "success": False,
                "error": "Password must be at least 8 characters and include letters, numbers, and special characters"
            }
        
        # Validate full name
        if not full_name or len(full_name.strip()) < 3:
            return {
                "success": False,
                "error": "Full name is required and must be at least 3 characters"
            }
        
        try:
            # Create user
            user = self.user_service.create_user(email, password, full_name)
            
            # Create session
            session = self.user_service.create_session(user.id)
            
            return {
                "success": True,
                "user": {
                    "id": user.id,
                    "email": user.email,
                    "full_name": user.full_name
                },
                "token": session["token"]
            }
        except ValueError as e:
            return {
                "success": False,
                "error": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred during registration"
            }
    
    def login(self, email: str, password: str, device_info: str = "") -> Dict[str, Any]:
        """Login a user"""
        try:
            # Authenticate user
            user = self.user_service.authenticate(email, password)
            
            if not user:
                return {
                    "success": False,
                    "error": "Invalid email or password"
                }
            
            # Check if 2FA is enabled
            if user.two_factor_enabled:
                return {
                    "success": True,
                    "requires_2fa": True,
                    "user_id": user.id
                }
            
            # Create session
            session = self.user_service.create_session(user.id, device_info)
            
            return {
                "success": True,
                "user": {
                    "id": user.id,
                    "email": user.email,
                    "full_name": user.full_name,
                    "kyc_status": user.kyc_status.value,
                    "two_factor_enabled": user.two_factor_enabled
                },
                "token": session["token"]
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred during login"
            }
    
    def verify_2fa(self, user_id: str, code: str, device_info: str = "") -> Dict[str, Any]:
        """Verify 2FA code and complete login"""
        try:
            # Verify 2FA code
            if not self.user_service.verify_2fa(user_id, code):
                return {
                    "success": False,
                    "error": "Invalid 2FA code"
                }
            
            # Create session
            session = self.user_service.create_session(user_id, device_info)
            
            # Get user
            user = self.user_service.get_user(user_id)
            
            return {
                "success": True,
                "user": {
                    "id": user.id,
                    "email": user.email,
                    "full_name": user.full_name,
                    "kyc_status": user.kyc_status.value,
                    "two_factor_enabled": user.two_factor_enabled
                },
                "token": session["token"]
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred during 2FA verification"
            }
    
    def logout(self, token: str) -> Dict[str, bool]:
        """Logout a user"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {"success": False}
            
            # Invalidate session
            session_id = token_data["session_id"]
            success = self.user_service.invalidate_session(session_id)
            
            return {"success": success}
        except Exception as e:
            return {"success": False}
    
    def get_user_profile(self, token: str) -> Dict[str, Any]:
        """Get user profile"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user = token_data["user"]
            
            return {
                "success": True,
                "user": {
                    "id": user.id,
                    "email": user.email,
                    "full_name": user.full_name,
                    "kyc_status": user.kyc_status.value,
                    "two_factor_enabled": user.two_factor_enabled,
                    "created_at": user.created_at.isoformat()
                }
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving user profile"
            }
    
    def change_password(self, token: str, current_password: str, new_password: str) -> Dict[str, Any]:
        """Change user password"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            # Validate new password
            if not self._validate_password(new_password):
                return {
                    "success": False,
                    "error": "New password must be at least 8 characters and include letters, numbers, and special characters"
                }
            
            user_id = token_data["user_id"]
            
            # Change password
            success = self.user_service.change_password(user_id, current_password, new_password)
            
            if not success:
                return {
                    "success": False,
                    "error": "Current password is incorrect"
                }
            
            # Invalidate all sessions except current one
            current_session_id = token_data["session_id"]
            self.user_service.invalidate_all_sessions(user_id)
            
            # Create new session
            session = self.user_service.create_session(user_id)
            
            return {
                "success": True,
                "message": "Password changed successfully",
                "token": session["token"]
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while changing password"
            }
    
    def setup_2fa(self, token: str) -> Dict[str, Any]:
        """Setup 2FA for a user"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Generate 2FA secret
            secret_data = self.user_service.generate_2fa_secret(user_id)
            
            return {
                "success": True,
                "secret": secret_data["secret"],
                "qr_code_uri": secret_data["uri"]
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while setting up 2FA"
            }
    
    def enable_2fa(self, token: str, secret: str, code: str) -> Dict[str, Any]:
        """Enable 2FA for a user"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Enable 2FA
            success = self.user_service.enable_2fa(user_id, secret, code)
            
            if not success:
                return {
                    "success": False,
                    "error": "Invalid verification code"
                }
            
            return {
                "success": True,
                "message": "Two-factor authentication enabled successfully"
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while enabling 2FA"
            }
    
    def disable_2fa(self, token: str, code: str) -> Dict[str, Any]:
        """Disable 2FA for a user"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Disable 2FA
            success = self.user_service.disable_2fa(user_id, code)
            
            if not success:
                return {
                    "success": False,
                    "error": "Invalid verification code"
                }
            
            return {
                "success": True,
                "message": "Two-factor authentication disabled successfully"
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while disabling 2FA"
            }
    
    def submit_kyc(self, token: str, document_type: str, document_data: Dict[str, Any]) -> Dict[str, Any]:
        """Submit KYC documents"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Validate document type
            valid_document_types = ["passport", "id_card", "drivers_license", "utility_bill", "bank_statement"]
            if document_type not in valid_document_types:
                return {
                    "success": False,
                    "error": "Invalid document type"
                }
            
            # Submit KYC
            success = self.user_service.submit_kyc(user_id, document_type, document_data)
            
            if not success:
                return {
                    "success": False,
                    "error": "Failed to submit KYC documents"
                }
            
            return {
                "success": True,
                "message": "KYC documents submitted successfully"
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while submitting KYC documents"
            }
    
    def _validate_email(self, email: str) -> bool:
        """Validate email format"""
        email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(email_regex, email))
    
    def _validate_password(self, password: str) -> bool:
        """Validate password strength"""
        # At least 8 characters, with letters, numbers, and special characters
        if len(password) < 8:
            return False
        
        has_letter = bool(re.search(r'[a-zA-Z]', password))
        has_number = bool(re.search(r'\d', password))
        has_special = bool(re.search(r'[!@#$%^&*(),.?":{}|<>]', password))
        
        return has_letter and has_number and has_special
