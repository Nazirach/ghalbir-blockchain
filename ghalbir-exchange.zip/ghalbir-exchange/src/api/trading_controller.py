from typing import Dict, List, Optional, Any
import uuid
import json
import os
from datetime import datetime
from decimal import Decimal

from src.services.user_service import UserService
from src.services.order_service import OrderService
from src.services.trade_service import TradeService
from src.core.matching_engine import MatchingEngine
from src.models.order import OrderSide, OrderType, OrderStatus

class TradingController:
    def __init__(self, user_service: UserService, order_service: OrderService, 
                trade_service: TradeService, matching_engine: MatchingEngine):
        self.user_service = user_service
        self.order_service = order_service
        self.trade_service = trade_service
        self.matching_engine = matching_engine
    
    def get_trading_pairs(self) -> Dict[str, Any]:
        """Get all available trading pairs"""
        try:
            trading_pairs = self.matching_engine.get_trading_pairs()
            
            return {
                "success": True,
                "trading_pairs": trading_pairs
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving trading pairs"
            }
    
    def get_order_book(self, trading_pair: str, depth: int = 20) -> Dict[str, Any]:
        """Get order book for a trading pair"""
        try:
            order_book = self.matching_engine.get_order_book(trading_pair, depth)
            
            return {
                "success": True,
                "order_book": order_book
            }
        except ValueError as e:
            return {
                "success": False,
                "error": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving order book"
            }
    
    def get_ticker(self, trading_pair: str) -> Dict[str, Any]:
        """Get ticker for a trading pair"""
        try:
            ticker = self.matching_engine.get_ticker(trading_pair)
            
            return {
                "success": True,
                "ticker": ticker
            }
        except ValueError as e:
            return {
                "success": False,
                "error": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving ticker"
            }
    
    def get_recent_trades(self, trading_pair: str, limit: int = 50) -> Dict[str, Any]:
        """Get recent trades for a trading pair"""
        try:
            trades = self.trade_service.get_market_trades(trading_pair, limit)
            
            trade_data = []
            for trade in trades:
                trade_data.append({
                    "id": trade.id,
                    "price": str(trade.price),
                    "amount": str(trade.amount),
                    "side": "buy" if trade.buyer_id else "sell",
                    "created_at": trade.created_at.isoformat()
                })
            
            return {
                "success": True,
                "trades": trade_data
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving recent trades"
            }
    
    def place_order(self, token: str, trading_pair: str, side: str, 
                   type: str, amount: str, price: str = None) -> Dict[str, Any]:
        """Place a new order"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Validate side
            try:
                order_side = OrderSide(side)
            except ValueError:
                return {
                    "success": False,
                    "error": "Invalid order side. Must be 'buy' or 'sell'."
                }
            
            # Validate type
            try:
                order_type = OrderType(type)
            except ValueError:
                return {
                    "success": False,
                    "error": "Invalid order type. Must be 'limit', 'market', or 'stop_limit'."
                }
            
            # Validate amount
            try:
                amount_decimal = Decimal(amount)
                if amount_decimal <= Decimal('0'):
                    return {
                        "success": False,
                        "error": "Amount must be positive"
                    }
            except:
                return {
                    "success": False,
                    "error": "Invalid amount format"
                }
            
            # Validate price for limit orders
            price_decimal = None
            if order_type == OrderType.LIMIT or order_type == OrderType.STOP_LIMIT:
                if not price:
                    return {
                        "success": False,
                        "error": "Price is required for limit orders"
                    }
                
                try:
                    price_decimal = Decimal(price)
                    if price_decimal <= Decimal('0'):
                        return {
                            "success": False,
                            "error": "Price must be positive"
                        }
                except:
                    return {
                        "success": False,
                        "error": "Invalid price format"
                    }
            
            # For market orders, use a placeholder price
            if order_type == OrderType.MARKET:
                price_decimal = Decimal('0')
            
            # Place order
            order = self.matching_engine.place_order(
                user_id=user_id,
                side=order_side,
                order_type=order_type,
                trading_pair=trading_pair,
                amount=amount_decimal,
                price=price_decimal
            )
            
            return {
                "success": True,
                "order": {
                    "id": order.id,
                    "user_id": order.user_id,
                    "side": order.side.value,
                    "type": order.order_type.value,
                    "trading_pair": order.trading_pair,
                    "amount": str(order.amount),
                    "price": str(order.price),
                    "status": order.status.value,
                    "filled_amount": str(order.filled_amount),
                    "remaining_amount": str(order.remaining_amount),
                    "created_at": order.created_at.isoformat()
                }
            }
        except ValueError as e:
            return {
                "success": False,
                "error": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while placing order"
            }
    
    def cancel_order(self, token: str, order_id: str) -> Dict[str, Any]:
        """Cancel an order"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Cancel order
            order = self.matching_engine.cancel_order(user_id, order_id)
            
            if not order:
                return {
                    "success": False,
                    "error": "Order not found or already cancelled"
                }
            
            return {
                "success": True,
                "order": {
                    "id": order.id,
                    "status": order.status.value
                }
            }
        except ValueError as e:
            return {
                "success": False,
                "error": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while cancelling order"
            }
    
    def get_orders(self, token: str, status: str = None) -> Dict[str, Any]:
        """Get all orders for a user"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Get orders
            orders = self.order_service.get_user_orders(user_id)
            
            # Filter by status if provided
            if status:
                try:
                    order_status = OrderStatus(status)
                    orders = [o for o in orders if o.status == order_status]
                except ValueError:
                    return {
                        "success": False,
                        "error": "Invalid order status"
                    }
            
            order_data = []
            for order in orders:
                order_data.append({
                    "id": order.id,
                    "side": order.side.value,
                    "type": order.order_type.value,
                    "trading_pair": order.trading_pair,
                    "amount": str(order.amount),
                    "price": str(order.price),
                    "status": order.status.value,
                    "filled_amount": str(order.filled_amount),
                    "remaining_amount": str(order.remaining_amount),
                    "created_at": order.created_at.isoformat(),
                    "updated_at": order.updated_at.isoformat()
                })
            
            return {
                "success": True,
                "orders": order_data
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving orders"
            }
    
    def get_order(self, token: str, order_id: str) -> Dict[str, Any]:
        """Get a specific order"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Get order
            order = self.order_service.get_order(order_id)
            
            if not order:
                return {
                    "success": False,
                    "error": "Order not found"
                }
            
            # Check if order belongs to user
            if order.user_id != user_id:
                return {
                    "success": False,
                    "error": "Order not found"
                }
            
            return {
                "success": True,
                "order": {
                    "id": order.id,
                    "side": order.side.value,
                    "type": order.order_type.value,
                    "trading_pair": order.trading_pair,
                    "amount": str(order.amount),
                    "price": str(order.price),
                    "status": order.status.value,
                    "filled_amount": str(order.filled_amount),
                    "remaining_amount": str(order.remaining_amount),
                    "created_at": order.created_at.isoformat(),
                    "updated_at": order.updated_at.isoformat()
                }
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving order"
            }
    
    def get_user_trades(self, token: str) -> Dict[str, Any]:
        """Get all trades for a user"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Get trades
            trades = self.trade_service.get_user_trades(user_id)
            
            trade_data = []
            for trade in trades:
                is_buyer = trade.buyer_id == user_id
                
                trade_data.append({
                    "id": trade.id,
                    "trading_pair": trade.trading_pair,
                    "side": "buy" if is_buyer else "sell",
                    "price": str(trade.price),
                    "amount": str(trade.amount),
                    "fee": str(trade.fee),
                    "total": str(trade.amount * trade.price),
                    "order_id": trade.buyer_order_id if is_buyer else trade.seller_order_id,
                    "created_at": trade.created_at.isoformat()
                })
            
            return {
                "success": True,
                "trades": trade_data
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving trades"
            }
    }
