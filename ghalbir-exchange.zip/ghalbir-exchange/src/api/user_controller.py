from typing import Dict, List, Optional, Any
import uuid
import json
import os
from datetime import datetime
from decimal import Decimal

from src.models.user import User, UserStatus, KYCStatus
from src.services.user_service import UserService
from src.services.wallet_service import WalletService
from src.services.transaction_service import TransactionService

class UserController:
    def __init__(self, user_service: UserService, wallet_service: WalletService, 
                transaction_service: TransactionService):
        self.user_service = user_service
        self.wallet_service = wallet_service
        self.transaction_service = transaction_service
    
    def get_user_wallets(self, token: str) -> Dict[str, Any]:
        """Get all wallets for a user"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Get wallets
            wallets = self.wallet_service.get_user_wallets(user_id)
            
            wallet_data = []
            for wallet in wallets:
                wallet_data.append({
                    "id": wallet.id,
                    "asset": wallet.asset,
                    "balance": str(wallet.balance),
                    "address": wallet.address,
                    "created_at": wallet.created_at.isoformat()
                })
            
            return {
                "success": True,
                "wallets": wallet_data
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving wallets"
            }
    
    def get_wallet(self, token: str, asset: str) -> Dict[str, Any]:
        """Get wallet for a specific asset"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Get wallet
            wallet = self.wallet_service.get_wallet(user_id, asset)
            
            if not wallet:
                return {
                    "success": False,
                    "error": f"Wallet not found for asset {asset}"
                }
            
            return {
                "success": True,
                "wallet": {
                    "id": wallet.id,
                    "asset": wallet.asset,
                    "balance": str(wallet.balance),
                    "address": wallet.address,
                    "created_at": wallet.created_at.isoformat()
                }
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving wallet"
            }
    
    def create_wallet(self, token: str, asset: str, address: str) -> Dict[str, Any]:
        """Create a new wallet for a user"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Check if wallet already exists
            existing_wallet = self.wallet_service.get_wallet(user_id, asset)
            if existing_wallet:
                return {
                    "success": False,
                    "error": f"Wallet already exists for asset {asset}"
                }
            
            # Create wallet
            wallet = self.wallet_service.create_wallet(user_id, asset, address)
            
            return {
                "success": True,
                "wallet": {
                    "id": wallet.id,
                    "asset": wallet.asset,
                    "balance": str(wallet.balance),
                    "address": wallet.address,
                    "created_at": wallet.created_at.isoformat()
                }
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while creating wallet"
            }
    
    def get_deposit_address(self, token: str, asset: str) -> Dict[str, Any]:
        """Get deposit address for a wallet"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Get wallet
            wallet = self.wallet_service.get_wallet(user_id, asset)
            
            if not wallet:
                return {
                    "success": False,
                    "error": f"Wallet not found for asset {asset}"
                }
            
            return {
                "success": True,
                "address": wallet.address
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving deposit address"
            }
    
    def withdraw(self, token: str, asset: str, amount: str, address: str) -> Dict[str, Any]:
        """Create a withdrawal request"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            user = token_data["user"]
            
            # Check KYC status
            if user.kyc_status != KYCStatus.APPROVED:
                return {
                    "success": False,
                    "error": "KYC approval required for withdrawals"
                }
            
            # Validate amount
            try:
                amount_decimal = Decimal(amount)
                if amount_decimal <= Decimal('0'):
                    return {
                        "success": False,
                        "error": "Amount must be positive"
                    }
            except:
                return {
                    "success": False,
                    "error": "Invalid amount format"
                }
            
            # Calculate fee (0.1% for this example)
            fee = amount_decimal * Decimal('0.001')
            total_amount = amount_decimal + fee
            
            # Check balance
            if not self.wallet_service.check_balance(user_id, asset, total_amount):
                return {
                    "success": False,
                    "error": "Insufficient balance"
                }
            
            # Create withdrawal transaction
            transaction = self.transaction_service.create_withdrawal(
                user_id=user_id,
                asset=asset,
                amount=amount_decimal,
                fee=fee,
                address=address
            )
            
            # Deduct from wallet
            self.wallet_service.withdraw(user_id, asset, total_amount)
            
            return {
                "success": True,
                "transaction": {
                    "id": transaction.id,
                    "type": transaction.type.value,
                    "asset": transaction.asset,
                    "amount": str(transaction.amount),
                    "fee": str(transaction.fee),
                    "address": transaction.address,
                    "status": transaction.status.value,
                    "created_at": transaction.created_at.isoformat()
                }
            }
        except ValueError as e:
            return {
                "success": False,
                "error": str(e)
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while processing withdrawal"
            }
    
    def get_transactions(self, token: str) -> Dict[str, Any]:
        """Get all transactions for a user"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Get transactions
            transactions = self.transaction_service.get_user_transactions(user_id)
            
            transaction_data = []
            for transaction in transactions:
                transaction_data.append({
                    "id": transaction.id,
                    "type": transaction.type.value,
                    "asset": transaction.asset,
                    "amount": str(transaction.amount),
                    "fee": str(transaction.fee),
                    "address": transaction.address,
                    "tx_hash": transaction.tx_hash,
                    "status": transaction.status.value,
                    "created_at": transaction.created_at.isoformat()
                })
            
            return {
                "success": True,
                "transactions": transaction_data
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving transactions"
            }
    
    def get_transaction(self, token: str, transaction_id: str) -> Dict[str, Any]:
        """Get a specific transaction"""
        try:
            # Validate token
            token_data = self.user_service.validate_token(token)
            
            if not token_data:
                return {
                    "success": False,
                    "error": "Invalid or expired token"
                }
            
            user_id = token_data["user_id"]
            
            # Get transaction
            transaction = self.transaction_service.get_transaction(transaction_id)
            
            if not transaction:
                return {
                    "success": False,
                    "error": "Transaction not found"
                }
            
            # Check if transaction belongs to user
            if transaction.user_id != user_id:
                return {
                    "success": False,
                    "error": "Transaction not found"
                }
            
            return {
                "success": True,
                "transaction": {
                    "id": transaction.id,
                    "type": transaction.type.value,
                    "asset": transaction.asset,
                    "amount": str(transaction.amount),
                    "fee": str(transaction.fee),
                    "address": transaction.address,
                    "tx_hash": transaction.tx_hash,
                    "status": transaction.status.value,
                    "created_at": transaction.created_at.isoformat(),
                    "updated_at": transaction.updated_at.isoformat()
                }
            }
        except Exception as e:
            return {
                "success": False,
                "error": "An error occurred while retrieving transaction"
            }
