from typing import Dict, List, Optional, Tuple
from decimal import Decimal
import uuid
import threading
import time
import json
import os

from src.models.order import Order, OrderSide, OrderStatus, OrderType
from src.services.order_service import OrderService
from src.services.trade_service import TradeService
from src.services.wallet_service import WalletService

class MatchingEngine:
    def __init__(self, 
                 order_service: OrderService,
                 trade_service: TradeService,
                 wallet_service: WalletService,
                 data_dir: str = "/home/ubuntu/ghalbir-exchange/data"):
        self.order_service = order_service
        self.trade_service = trade_service
        self.wallet_service = wallet_service
        self.data_dir = data_dir
        
        # Trading pairs and their fee rates
        self.trading_pairs = {}
        self.fee_rates = {}
        
        # Lock for thread safety
        self.lock = threading.Lock()
        
        # Flag to control the matching thread
        self.running = False
        self.matching_thread = None
        
        # Load configuration
        self._load_config()
    
    def _load_config(self) -> None:
        """Load configuration from disk"""
        config_path = os.path.join(self.data_dir, "config.json")
        
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
                    
                    if "trading_pairs" in config:
                        self.trading_pairs = config["trading_pairs"]
                    
                    if "fee_rates" in config:
                        self.fee_rates = {k: Decimal(v) for k, v in config["fee_rates"].items()}
            except Exception as e:
                print(f"Error loading config: {e}")
                # Use default configuration
                self._create_default_config()
        else:
            # Create default configuration
            self._create_default_config()
    
    def _create_default_config(self) -> None:
        """Create default configuration"""
        self.trading_pairs = {
            "GBR/USDT": {
                "base_asset": "GBR",
                "quote_asset": "USDT",
                "min_order_size": "0.01",
                "price_precision": 4,
                "amount_precision": 4
            }
        }
        
        self.fee_rates = {
            "maker": Decimal('0.001'),  # 0.1%
            "taker": Decimal('0.002')   # 0.2%
        }
        
        # Save configuration
        config_path = os.path.join(self.data_dir, "config.json")
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        
        with open(config_path, 'w') as f:
            json.dump({
                "trading_pairs": self.trading_pairs,
                "fee_rates": {k: str(v) for k, v in self.fee_rates.items()}
            }, f, indent=2)
    
    def start(self) -> None:
        """Start the matching engine"""
        if self.running:
            return
        
        self.running = True
        self.matching_thread = threading.Thread(target=self._matching_loop)
        self.matching_thread.daemon = True
        self.matching_thread.start()
        
        print("Matching engine started")
    
    def stop(self) -> None:
        """Stop the matching engine"""
        self.running = False
        
        if self.matching_thread:
            self.matching_thread.join()
            self.matching_thread = None
        
        print("Matching engine stopped")
    
    def _matching_loop(self) -> None:
        """Main matching loop"""
        while self.running:
            # Process each trading pair
            for trading_pair in self.trading_pairs:
                try:
                    self._match_orders(trading_pair)
                except Exception as e:
                    print(f"Error matching orders for {trading_pair}: {e}")
            
            # Sleep to avoid high CPU usage
            time.sleep(0.1)
    
    def _match_orders(self, trading_pair: str) -> None:
        """Match orders for a trading pair"""
        with self.lock:
            # Get active orders for the trading pair
            active_orders = self.order_service.get_active_orders_for_trading_pair(trading_pair)
            
            # Separate buy and sell orders
            buy_orders = [o for o in active_orders if o.side == OrderSide.BUY]
            sell_orders = [o for o in active_orders if o.side == OrderSide.SELL]
            
            # Sort buy orders by price (highest first) and time (oldest first)
            buy_orders.sort(key=lambda o: (-o.price, o.created_at))
            
            # Sort sell orders by price (lowest first) and time (oldest first)
            sell_orders.sort(key=lambda o: (o.price, o.created_at))
            
            # Match orders
            for buy_order in buy_orders:
                if not buy_order.is_active():
                    continue
                
                for sell_order in sell_orders:
                    if not sell_order.is_active():
                        continue
                    
                    # Check if orders can be matched
                    if buy_order.price >= sell_order.price:
                        # Determine execution price (usually the price of the maker order)
                        # For simplicity, we use the sell order price
                        execution_price = sell_order.price
                        
                        # Determine execution amount
                        execution_amount = min(buy_order.remaining_amount, sell_order.remaining_amount)
                        
                        # Execute the trade
                        self._execute_trade(buy_order, sell_order, execution_amount, execution_price)
                        
                        # If buy order is filled, move to next buy order
                        if buy_order.status == OrderStatus.FILLED:
                            break
    
    def _execute_trade(self, buy_order: Order, sell_order: Order, 
                      amount: Decimal, price: Decimal) -> None:
        """Execute a trade between two orders"""
        # Calculate trade value
        trade_value = amount * price
        
        # Determine maker and taker
        # The maker is the order that was placed first
        if buy_order.created_at < sell_order.created_at:
            maker_order = buy_order
            taker_order = sell_order
        else:
            maker_order = sell_order
            taker_order = buy_order
        
        # Calculate fees
        maker_fee_rate = self.fee_rates.get("maker", Decimal('0.001'))
        taker_fee_rate = self.fee_rates.get("taker", Decimal('0.002'))
        
        maker_fee = trade_value * maker_fee_rate
        taker_fee = trade_value * taker_fee_rate
        
        # Update order status
        buy_order.fill(amount, price)
        sell_order.fill(amount, price)
        
        # Update orders in database
        self.order_service.update_order(buy_order)
        self.order_service.update_order(sell_order)
        
        # Create trade record
        trade = self.trade_service.create_trade(
            buyer_order=buy_order,
            seller_order=sell_order,
            amount=amount,
            price=price,
            fee_rate=taker_fee_rate  # Use taker fee for the trade record
        )
        
        # Update wallets
        # For buy order: deduct quote asset, add base asset
        # For sell order: add quote asset, deduct base asset
        trading_pair_info = self.trading_pairs.get(buy_order.trading_pair, {})
        base_asset = trading_pair_info.get("base_asset", "GBR")
        quote_asset = trading_pair_info.get("quote_asset", "USDT")
        
        # Buyer pays quote asset and receives base asset
        self.wallet_service.withdraw(buy_order.user_id, quote_asset, trade_value + (maker_fee if buy_order == maker_order else taker_fee))
        self.wallet_service.deposit(buy_order.user_id, base_asset, amount)
        
        # Seller receives quote asset and pays base asset
        self.wallet_service.deposit(sell_order.user_id, quote_asset, trade_value - (maker_fee if sell_order == maker_order else taker_fee))
        self.wallet_service.withdraw(sell_order.user_id, base_asset, amount)
        
        print(f"Trade executed: {amount} {base_asset} at {price} {quote_asset}")
    
    def place_order(self, user_id: str, side: OrderSide, order_type: OrderType,
                   trading_pair: str, amount: Decimal, price: Decimal) -> Order:
        """Place a new order"""
        # Validate trading pair
        if trading_pair not in self.trading_pairs:
            raise ValueError(f"Invalid trading pair: {trading_pair}")
        
        # Validate order size
        trading_pair_info = self.trading_pairs[trading_pair]
        min_order_size = Decimal(trading_pair_info.get("min_order_size", "0.01"))
        
        if amount < min_order_size:
            raise ValueError(f"Order size too small. Minimum: {min_order_size}")
        
        # Check user balance
        base_asset = trading_pair_info["base_asset"]
        quote_asset = trading_pair_info["quote_asset"]
        
        if side == OrderSide.BUY:
            # For buy orders, check quote asset balance
            required_balance = amount * price
            if not self.wallet_service.check_balance(user_id, quote_asset, required_balance):
                raise ValueError(f"Insufficient {quote_asset} balance")
        else:
            # For sell orders, check base asset balance
            if not self.wallet_service.check_balance(user_id, base_asset, amount):
                raise ValueError(f"Insufficient {base_asset} balance")
        
        # Create order
        order = self.order_service.create_order(
            user_id=user_id,
            side=side,
            order_type=order_type,
            trading_pair=trading_pair,
            amount=amount,
            price=price
        )
        
        return order
    
    def cancel_order(self, user_id: str, order_id: str) -> Optional[Order]:
        """Cancel an order"""
        order = self.order_service.get_order(order_id)
        
        if not order:
            return None
        
        # Check if user owns the order
        if order.user_id != user_id:
            raise ValueError("Order does not belong to user")
        
        # Cancel the order
        return self.order_service.cancel_order(order_id)
    
    def get_order_book(self, trading_pair: str, depth: int = 20) -> Dict[str, List[Dict]]:
        """Get order book for a trading pair"""
        # Validate trading pair
        if trading_pair not in self.trading_pairs:
            raise ValueError(f"Invalid trading pair: {trading_pair}")
        
        order_book = self.order_service.get_order_book(trading_pair)
        
        # Limit the depth
        order_book["bids"] = order_book["bids"][:depth]
        order_book["asks"] = order_book["asks"][:depth]
        
        return order_book
    
    def get_ticker(self, trading_pair: str) -> Dict:
        """Get ticker for a trading pair"""
        # Validate trading pair
        if trading_pair not in self.trading_pairs:
            raise ValueError(f"Invalid trading pair: {trading_pair}")
        
        return self.trade_service.get_market_statistics(trading_pair)
    
    def get_trading_pairs(self) -> List[Dict]:
        """Get all trading pairs"""
        return [
            {
                "symbol": symbol,
                "base_asset": info["base_asset"],
                "quote_asset": info["quote_asset"],
                "min_order_size": info["min_order_size"],
                "price_precision": info["price_precision"],
                "amount_precision": info["amount_precision"]
            }
            for symbol, info in self.trading_pairs.items()
        ]
