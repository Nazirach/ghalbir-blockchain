import unittest
import sys
import os
import json
from decimal import Decimal
import time

# Add project root to path
sys.path.append('/home/ubuntu/ghalbir-exchange')

from src.models.user import User
from src.models.wallet import Wallet
from src.models.order import Order, OrderType, OrderSide, OrderStatus
from src.models.transaction import Transaction, TransactionType, TransactionStatus
from src.services.user_service import UserService
from src.services.wallet_service import WalletService
from src.services.order_service import OrderService
from src.services.transaction_service import TransactionService
from src.services.trade_service import TradeService
from src.core.matching_engine import MatchingEngine
from src.services.security_service import SecurityService
from src.services.audit_service import AuditService

class TestGhalbirExchange(unittest.TestCase):
    """Test suite for the Ghalbir Exchange platform."""
    
    def setUp(self):
        """Set up test environment."""
        # Create test data directory
        self.test_data_dir = "/home/ubuntu/ghalbir-exchange/test_data"
        os.makedirs(self.test_data_dir, exist_ok=True)
        
        # Initialize services
        self.security_service = SecurityService(data_dir=self.test_data_dir)
        self.audit_service = AuditService(data_dir=self.test_data_dir)
        self.user_service = UserService(
            security_service=self.security_service,
            audit_service=self.audit_service,
            data_dir=self.test_data_dir
        )
        self.wallet_service = WalletService(data_dir=self.test_data_dir)
        self.transaction_service = TransactionService(data_dir=self.test_data_dir)
        self.order_service = OrderService(data_dir=self.test_data_dir)
        self.trade_service = TradeService(
            order_service=self.order_service,
            wallet_service=self.wallet_service,
            data_dir=self.test_data_dir
        )
        self.matching_engine = MatchingEngine(
            order_service=self.order_service,
            trade_service=self.trade_service
        )
        
        # Create test users
        self.test_users = self._create_test_users()
        
        # Initialize wallets for test users
        self._initialize_test_wallets()
    
    def tearDown(self):
        """Clean up after tests."""
        # In a real implementation, we would clean up the test data directory
        # For this example, we'll leave it for inspection
        pass
    
    def _create_test_users(self):
        """Create test users."""
        test_users = {}
        
        # Create buyer
        buyer_data = self.user_service.create_user(
            email="buyer@example.com",
            password="StrongPassword123!",
            full_name="Test Buyer"
        )
        test_users["buyer"] = buyer_data
        
        # Create seller
        seller_data = self.user_service.create_user(
            email="seller@example.com",
            password="StrongPassword456!",
            full_name="Test Seller"
        )
        test_users["seller"] = seller_data
        
        return test_users
    
    def _initialize_test_wallets(self):
        """Initialize wallets for test users."""
        # Initialize buyer wallet with USDT
        self.wallet_service.deposit(
            user_id=self.test_users["buyer"]["id"],
            asset="USDT",
            amount=Decimal("10000.0")
        )
        
        # Initialize seller wallet with GBR
        self.wallet_service.deposit(
            user_id=self.test_users["seller"]["id"],
            asset="GBR",
            amount=Decimal("100.0")
        )
    
    def test_user_registration_and_login(self):
        """Test user registration and login."""
        # Test user registration
        user_data = self.user_service.create_user(
            email="testuser@example.com",
            password="SecurePassword789!",
            full_name="Test User"
        )
        
        self.assertIsNotNone(user_data)
        self.assertEqual(user_data["email"], "testuser@example.com")
        self.assertEqual(user_data["full_name"], "Test User")
        
        # Test user login
        login_result = self.user_service.login_user(
            email="testuser@example.com",
            password="SecurePassword789!",
            ip_address="127.0.0.1",
            user_agent="Test User Agent"
        )
        
        self.assertTrue(login_result["success"])
        self.assertIn("access_token", login_result)
        self.assertIn("refresh_token", login_result)
        
        # Test invalid login
        invalid_login = self.user_service.login_user(
            email="testuser@example.com",
            password="WrongPassword",
            ip_address="127.0.0.1",
            user_agent="Test User Agent"
        )
        
        self.assertFalse(invalid_login["success"])
    
    def test_wallet_operations(self):
        """Test wallet operations."""
        user_id = self.test_users["buyer"]["id"]
        
        # Test get wallet
        wallet = self.wallet_service.get_wallet(user_id, "USDT")
        self.assertIsNotNone(wallet)
        self.assertEqual(wallet.user_id, user_id)
        self.assertEqual(wallet.asset, "USDT")
        self.assertEqual(wallet.balance, Decimal("10000.0"))
        
        # Test deposit
        deposit_result = self.wallet_service.deposit(user_id, "USDT", Decimal("1000.0"))
        self.assertTrue(deposit_result)
        
        # Verify balance after deposit
        wallet = self.wallet_service.get_wallet(user_id, "USDT")
        self.assertEqual(wallet.balance, Decimal("11000.0"))
        
        # Test withdraw
        withdraw_result = self.wallet_service.withdraw(user_id, "USDT", Decimal("500.0"))
        self.assertTrue(withdraw_result)
        
        # Verify balance after withdrawal
        wallet = self.wallet_service.get_wallet(user_id, "USDT")
        self.assertEqual(wallet.balance, Decimal("10500.0"))
        
        # Test insufficient balance
        withdraw_result = self.wallet_service.withdraw(user_id, "USDT", Decimal("20000.0"))
        self.assertFalse(withdraw_result)
        
        # Verify balance unchanged
        wallet = self.wallet_service.get_wallet(user_id, "USDT")
        self.assertEqual(wallet.balance, Decimal("10500.0"))
    
    def test_order_creation_and_cancellation(self):
        """Test order creation and cancellation."""
        buyer_id = self.test_users["buyer"]["id"]
        
        # Create buy order
        order_data = self.order_service.create_order(
            user_id=buyer_id,
            order_type=OrderType.LIMIT,
            side=OrderSide.BUY,
            symbol="GBR/USDT",
            price=Decimal("100.0"),
            amount=Decimal("1.0")
        )
        
        self.assertIsNotNone(order_data)
        self.assertEqual(order_data.user_id, buyer_id)
        self.assertEqual(order_data.order_type, OrderType.LIMIT)
        self.assertEqual(order_data.side, OrderSide.BUY)
        self.assertEqual(order_data.symbol, "GBR/USDT")
        self.assertEqual(order_data.price, Decimal("100.0"))
        self.assertEqual(order_data.amount, Decimal("1.0"))
        self.assertEqual(order_data.status, OrderStatus.OPEN)
        
        # Cancel order
        cancel_result = self.order_service.cancel_order(order_data.id, buyer_id)
        self.assertTrue(cancel_result)
        
        # Verify order status
        order = self.order_service.get_order(order_data.id)
        self.assertEqual(order.status, OrderStatus.CANCELLED)
    
    def test_order_matching_and_execution(self):
        """Test order matching and execution."""
        buyer_id = self.test_users["buyer"]["id"]
        seller_id = self.test_users["seller"]["id"]
        
        # Get initial balances
        buyer_usdt_wallet = self.wallet_service.get_wallet(buyer_id, "USDT")
        buyer_gbr_wallet = self.wallet_service.get_wallet(buyer_id, "GBR")
        if buyer_gbr_wallet is None:
            # Create GBR wallet for buyer if it doesn't exist
            self.wallet_service.deposit(buyer_id, "GBR", Decimal("0.0"))
            buyer_gbr_wallet = self.wallet_service.get_wallet(buyer_id, "GBR")
        
        seller_usdt_wallet = self.wallet_service.get_wallet(seller_id, "USDT")
        if seller_usdt_wallet is None:
            # Create USDT wallet for seller if it doesn't exist
            self.wallet_service.deposit(seller_id, "USDT", Decimal("0.0"))
            seller_usdt_wallet = self.wallet_service.get_wallet(seller_id, "USDT")
        
        seller_gbr_wallet = self.wallet_service.get_wallet(seller_id, "GBR")
        
        initial_buyer_usdt = buyer_usdt_wallet.balance
        initial_buyer_gbr = buyer_gbr_wallet.balance
        initial_seller_usdt = seller_usdt_wallet.balance
        initial_seller_gbr = seller_gbr_wallet.balance
        
        # Create buy order
        buy_order = self.order_service.create_order(
            user_id=buyer_id,
            order_type=OrderType.LIMIT,
            side=OrderSide.BUY,
            symbol="GBR/USDT",
            price=Decimal("100.0"),
            amount=Decimal("2.0")
        )
        
        # Create sell order
        sell_order = self.order_service.create_order(
            user_id=seller_id,
            order_type=OrderType.LIMIT,
            side=OrderSide.SELL,
            symbol="GBR/USDT",
            price=Decimal("100.0"),
            amount=Decimal("1.0")
        )
        
        # Process orders through matching engine
        self.matching_engine.process_order(sell_order.id)
        
        # Verify order statuses
        updated_buy_order = self.order_service.get_order(buy_order.id)
        updated_sell_order = self.order_service.get_order(sell_order.id)
        
        self.assertEqual(updated_buy_order.status, OrderStatus.PARTIALLY_FILLED)
        self.assertEqual(updated_buy_order.filled_amount, Decimal("1.0"))
        self.assertEqual(updated_sell_order.status, OrderStatus.FILLED)
        self.assertEqual(updated_sell_order.filled_amount, Decimal("1.0"))
        
        # Verify wallet balances
        buyer_usdt_wallet = self.wallet_service.get_wallet(buyer_id, "USDT")
        buyer_gbr_wallet = self.wallet_service.get_wallet(buyer_id, "GBR")
        seller_usdt_wallet = self.wallet_service.get_wallet(seller_id, "USDT")
        seller_gbr_wallet = self.wallet_service.get_wallet(seller_id, "GBR")
        
        # Expected changes:
        # Buyer: -100 USDT, +1 GBR
        # Seller: +100 USDT, -1 GBR
        self.assertEqual(buyer_usdt_wallet.balance, initial_buyer_usdt - Decimal("100.0"))
        self.assertEqual(buyer_gbr_wallet.balance, initial_buyer_gbr + Decimal("1.0"))
        self.assertEqual(seller_usdt_wallet.balance, initial_seller_usdt + Decimal("100.0"))
        self.assertEqual(seller_gbr_wallet.balance, initial_seller_gbr - Decimal("1.0"))
        
        # Verify trade was created
        trades = self.trade_service.get_trades_by_order(buy_order.id)
        self.assertEqual(len(trades), 1)
        self.assertEqual(trades[0].buy_order_id, buy_order.id)
        self.assertEqual(trades[0].sell_order_id, sell_order.id)
        self.assertEqual(trades[0].price, Decimal("100.0"))
        self.assertEqual(trades[0].amount, Decimal("1.0"))
    
    def test_security_features(self):
        """Test security features."""
        # Test password hashing and verification
        password = "SecureTestPassword123!"
        hashed_password = self.security_service.hash_password(password)
        
        self.assertTrue(self.security_service.verify_password(password, hashed_password))
        self.assertFalse(self.security_service.verify_password("WrongPassword", hashed_password))
        
        # Test password strength validation
        weak_password = "password"
        strong_password = "StrongP@ssw0rd123"
        
        weak_validation = self.security_service.validate_password_strength(weak_password)
        strong_validation = self.security_service.validate_password_strength(strong_password)
        
        self.assertFalse(weak_validation["valid"])
        self.assertTrue(strong_validation["valid"])
        
        # Test JWT token generation and verification
        user_id = self.test_users["buyer"]["id"]
        token_data = self.security_service.generate_jwt_token(user_id)
        
        self.assertIn("access_token", token_data)
        self.assertIn("refresh_token", token_data)
        
        # Verify access token
        verification = self.security_service.verify_jwt_token(token_data["access_token"])
        self.assertTrue(verification["valid"])
        self.assertEqual(verification["payload"]["sub"], user_id)
        
        # Test API key generation and verification
        api_key_data = self.security_service.generate_api_key(
            user_id=user_id,
            label="Test API Key",
            permissions=["read", "trade"]
        )
        
        self.assertIn("api_key", api_key_data)
        self.assertIn("api_secret", api_key_data)
        
        # Verify API key
        verification = self.security_service.verify_api_key(
            api_key=api_key_data["api_key"],
            api_secret=api_key_data["api_secret"]
        )
        
        self.assertTrue(verification["valid"])
        self.assertEqual(verification["user_id"], user_id)
        self.assertEqual(verification["permissions"], ["read", "trade"])
    
    def test_audit_logging(self):
        """Test audit logging."""
        user_id = self.test_users["buyer"]["id"]
        ip_address = "192.168.1.1"
        
        # Log login event
        self.audit_service.log_login_attempt(
            user_id=user_id,
            ip_address=ip_address,
            user_agent="Test Browser",
            success=True,
            details={"method": "password"}
        )
        
        # Log transaction
        self.audit_service.log_transaction(
            transaction_id="test_tx_123",
            user_id=user_id,
            transaction_type="deposit",
            amount="100.0",
            asset="USDT",
            details={"source": "test"}
        )
        
        # Get user activity
        user_activity = self.audit_service.get_user_activity(user_id, limit=10)
        
        self.assertGreaterEqual(len(user_activity), 2)  # At least the two events we logged
        
        # Verify login event was logged
        login_events = [e for e in user_activity if e["event_type"] == "login_success"]
        self.assertGreaterEqual(len(login_events), 1)
        
        # Verify transaction was logged
        tx_events = [e for e in user_activity if e["event_type"] == "deposit_transaction"]
        self.assertGreaterEqual(len(tx_events), 1)
        
        # Get IP activity
        ip_activity = self.audit_service.get_ip_activity(ip_address, limit=10)
        self.assertGreaterEqual(len(ip_activity), 1)
    
    def test_transaction_service(self):
        """Test transaction service."""
        user_id = self.test_users["buyer"]["id"]
        
        # Create deposit transaction
        deposit = self.transaction_service.create_deposit(
            user_id=user_id,
            asset="USDT",
            amount=Decimal("500.0"),
            address="0x1234567890abcdef",
            tx_hash="0xabcdef1234567890"
        )
        
        self.assertIsNotNone(deposit)
        self.assertEqual(deposit.user_id, user_id)
        self.assertEqual(deposit.asset, "USDT")
        self.assertEqual(deposit.amount, Decimal("500.0"))
        self.assertEqual(deposit.type, TransactionType.DEPOSIT)
        self.assertEqual(deposit.status, TransactionStatus.COMPLETED)
        
        # Create withdrawal transaction
        withdrawal = self.transaction_service.create_withdrawal(
            user_id=user_id,
            asset="USDT",
            amount=Decimal("200.0"),
            fee=Decimal("1.0"),
            address="0x0987654321fedcba"
        )
        
        self.assertIsNotNone(withdrawal)
        self.assertEqual(withdrawal.user_id, user_id)
        self.assertEqual(withdrawal.asset, "USDT")
        self.assertEqual(withdrawal.amount, Decimal("200.0"))
        self.assertEqual(withdrawal.fee, Decimal("1.0"))
        self.assertEqual(withdrawal.type, TransactionType.WITHDRAWAL)
        self.assertEqual(withdrawal.status, TransactionStatus.PENDING)
        
        # Update transaction status
        update_result = self.transaction_service.update_transaction_status(
            transaction_id=withdrawal.id,
            status=TransactionStatus.COMPLETED,
            tx_hash="0xfedcba0987654321"
        )
        
        self.assertTrue(update_result)
        
        # Verify updated status
        updated_tx = self.transaction_service.get_transaction(withdrawal.id)
        self.assertEqual(updated_tx.status, TransactionStatus.COMPLETED)
        self.assertEqual(updated_tx.tx_hash, "0xfedcba0987654321")
        
        # Get user transactions
        user_txs = self.transaction_service.get_user_transactions(user_id)
        self.assertGreaterEqual(len(user_txs), 2)  # At least the two transactions we created

if __name__ == '__main__':
    unittest.main()
