import unittest
import sys
import os
import json
from decimal import Decimal
import time

# Add project root to path
sys.path.append('/home/ubuntu/ghalbir-exchange')

from src.blockchain.blockchain_connector import GhalbirBlockchainConnector
from src.blockchain.blockchain_service import BlockchainService
from src.services.transaction_service import TransactionService
from src.services.wallet_service import WalletService

class TestBlockchainIntegration(unittest.TestCase):
    """Test suite for the Ghalbir Exchange blockchain integration."""
    
    def setUp(self):
        """Set up test environment."""
        # Create test data directory
        self.test_data_dir = "/home/ubuntu/ghalbir-exchange/test_data_blockchain"
        os.makedirs(self.test_data_dir, exist_ok=True)
        
        # Initialize mock blockchain connector
        self.blockchain_connector = MockGhalbirBlockchainConnector()
        
        # Initialize services
        self.transaction_service = TransactionService(data_dir=self.test_data_dir)
        self.wallet_service = WalletService(data_dir=self.test_data_dir)
        
        # Initialize blockchain service
        self.blockchain_service = BlockchainService(
            blockchain_connector=self.blockchain_connector,
            transaction_service=self.transaction_service,
            wallet_service=self.wallet_service,
            data_dir=self.test_data_dir
        )
        
        # Create test user
        self.test_user_id = "test_user_123"
        
        # Initialize wallet for test user
        self.wallet_service.deposit(
            user_id=self.test_user_id,
            asset="GBR",
            amount=Decimal("100.0")
        )
    
    def tearDown(self):
        """Clean up after tests."""
        # In a real implementation, we would clean up the test data directory
        # For this example, we'll leave it for inspection
        pass
    
    def test_deposit_address_generation(self):
        """Test deposit address generation."""
        # Get deposit address
        deposit_address = self.blockchain_service.get_deposit_address(
            user_id=self.test_user_id,
            asset="GBR"
        )
        
        self.assertIsNotNone(deposit_address)
        self.assertTrue(len(deposit_address) > 0)
        
        # Get deposit address again (should be the same)
        deposit_address2 = self.blockchain_service.get_deposit_address(
            user_id=self.test_user_id,
            asset="GBR"
        )
        
        self.assertEqual(deposit_address, deposit_address2)
    
    def test_deposit_processing(self):
        """Test deposit processing."""
        # Get deposit address
        deposit_address = self.blockchain_service.get_deposit_address(
            user_id=self.test_user_id,
            asset="GBR"
        )
        
        # Create mock transaction
        tx_hash = "0x1234567890abcdef1234567890abcdef"
        self.blockchain_connector.add_mock_transaction(
            tx_hash=tx_hash,
            from_address="0xsender1234567890",
            to_address=deposit_address,
            amount=Decimal("10.0"),
            asset="GBR"
        )
        
        # Process deposit
        result = self.blockchain_service.process_deposit(
            user_id=self.test_user_id,
            asset="GBR",
            tx_hash=tx_hash
        )
        
        self.assertTrue(result["success"])
        self.assertEqual(result["amount"], "10.0")
        self.assertEqual(result["asset"], "GBR")
        
        # Verify wallet balance
        wallet = self.wallet_service.get_wallet(self.test_user_id, "GBR")
        self.assertEqual(wallet.balance, Decimal("110.0"))  # 100 initial + 10 deposit
    
    def test_withdrawal_creation(self):
        """Test withdrawal creation."""
        # Create withdrawal
        result = self.blockchain_service.create_withdrawal(
            user_id=self.test_user_id,
            asset="GBR",
            amount=Decimal("5.0"),
            address="0xrecipient1234567890"
        )
        
        self.assertTrue(result["success"])
        self.assertEqual(result["amount"], "5.0")
        self.assertEqual(result["asset"], "GBR")
        
        # Verify wallet balance (amount + fee deducted)
        wallet = self.wallet_service.get_wallet(self.test_user_id, "GBR")
        expected_balance = Decimal("100.0") - Decimal("5.0") - (Decimal("5.0") * Decimal("0.001"))
        self.assertEqual(wallet.balance, expected_balance)
        
        # Verify transaction created
        transaction = self.transaction_service.get_transaction(result["transaction_id"])
        self.assertIsNotNone(transaction)
        self.assertEqual(transaction.user_id, self.test_user_id)
        self.assertEqual(transaction.asset, "GBR")
        self.assertEqual(transaction.amount, Decimal("5.0"))
    
    def test_withdrawal_processing(self):
        """Test withdrawal processing."""
        # Create withdrawal
        withdrawal_result = self.blockchain_service.create_withdrawal(
            user_id=self.test_user_id,
            asset="GBR",
            amount=Decimal("5.0"),
            address="0xrecipient1234567890"
        )
        
        transaction_id = withdrawal_result["transaction_id"]
        
        # Process withdrawal
        process_result = self.blockchain_service.process_withdrawal(transaction_id)
        
        self.assertTrue(process_result["success"])
        self.assertIn("tx_hash", process_result)
        
        # Verify transaction status updated
        transaction = self.transaction_service.get_transaction(transaction_id)
        self.assertEqual(transaction.status.value, "completed")
        self.assertEqual(transaction.tx_hash, process_result["tx_hash"])
    
    def test_hot_wallet_balance(self):
        """Test hot wallet balance retrieval."""
        # Get hot wallet balance
        balance = self.blockchain_service.get_hot_wallet_balance()
        
        self.assertIsNotNone(balance)
        self.assertIn("address", balance)
        self.assertIn("GBR", balance)
        self.assertIn("ETH", balance)
    
    def test_transaction_verification(self):
        """Test blockchain transaction verification."""
        # Create mock transaction
        tx_hash = "0xabcdef1234567890abcdef1234567890"
        self.blockchain_connector.add_mock_transaction(
            tx_hash=tx_hash,
            from_address="0xsender0987654321",
            to_address="0xrecipient0987654321",
            amount=Decimal("15.0"),
            asset="GBR"
        )
        
        # Verify transaction
        result = self.blockchain_service.verify_blockchain_transaction(tx_hash)
        
        self.assertTrue(result["success"])
        self.assertIn("transaction", result)
        self.assertEqual(result["transaction"]["tx_hash"], tx_hash)
        self.assertEqual(result["transaction"]["token_value"], Decimal("15.0"))


class MockGhalbirBlockchainConnector:
    """Mock implementation of the GhalbirBlockchainConnector for testing."""
    
    def __init__(self):
        """Initialize the mock connector."""
        self.wallets = {}
        self.transactions = {}
        self.blocks = {}
        self.current_block = 1000
        
        # Initialize hot wallet
        self.hot_wallet = self.create_wallet()
        
        # Add some mock data
        self.add_mock_block(self.current_block)
    
    def create_wallet(self):
        """Create a new wallet."""
        wallet_id = f"wallet_{len(self.wallets) + 1}"
        address = f"0x{wallet_id}{'0' * 32}"
        private_key = f"0x{wallet_id}{'1' * 64}"
        
        wallet = {
            "address": address,
            "private_key": private_key
        }
        
        self.wallets[address] = {
            "private_key": private_key,
            "balance": Decimal("1000.0"),
            "eth_balance": Decimal("10.0")
        }
        
        return wallet
    
    def import_wallet(self, private_key):
        """Import a wallet using a private key."""
        # For mock purposes, just create a new wallet
        return self.create_wallet()
    
    def get_balance(self, address):
        """Get the GBR token balance of an address."""
        if address in self.wallets:
            return self.wallets[address]["balance"]
        return Decimal("0.0")
    
    def get_eth_balance(self, address):
        """Get the ETH balance of an address."""
        if address in self.wallets:
            return self.wallets[address]["eth_balance"]
        return Decimal("0.0")
    
    def transfer(self, from_private_key, to_address, amount):
        """Transfer GBR tokens from one address to another."""
        # Find sender address from private key
        sender_address = None
        for addr, wallet in self.wallets.items():
            if wallet["private_key"] == from_private_key:
                sender_address = addr
                break
        
        if not sender_address:
            raise ValueError("Invalid private key")
        
        # Check balance
        if self.wallets[sender_address]["balance"] < amount:
            raise ValueError("Insufficient balance")
        
        # Create transaction
        tx_hash = f"0x{len(self.transactions) + 1}{'a' * 60}"
        
        # Update balances
        self.wallets[sender_address]["balance"] -= amount
        
        if to_address not in self.wallets:
            self.wallets[to_address] = {
                "private_key": f"0x{'b' * 64}",
                "balance": Decimal("0.0"),
                "eth_balance": Decimal("0.0")
            }
        
        self.wallets[to_address]["balance"] += amount
        
        # Add transaction
        self.transactions[tx_hash] = {
            "tx_hash": tx_hash,
            "from": sender_address,
            "to": to_address,
            "value": Decimal("0.0"),
            "gas": 100000,
            "gas_price": Decimal("20.0"),
            "nonce": 1,
            "block_number": self.current_block,
            "status": "success",
            "gas_used": 21000,
            "is_token_transfer": True,
            "token_to": to_address,
            "token_value": amount
        }
        
        # Add to current block
        self.blocks[self.current_block]["transactions"].append(tx_hash)
        
        return {
            "tx_hash": tx_hash,
            "status": "success",
            "block_number": self.current_block,
            "gas_used": 21000
        }
    
    def get_transaction(self, tx_hash):
        """Get information about a transaction."""
        if tx_hash in self.transactions:
            return self.transactions[tx_hash]
        raise ValueError(f"Transaction {tx_hash} not found")
    
    def get_block(self, block_number):
        """Get information about a block."""
        if block_number in self.blocks:
            return self.blocks[block_number]
        raise ValueError(f"Block {block_number} not found")
    
    def get_latest_block_number(self):
        """Get the latest block number."""
        return self.current_block
    
    def validate_address(self, address):
        """Validate a Ghalbir address."""
        return address.startswith("0x") and len(address) == 42
    
    def add_mock_transaction(self, tx_hash, from_address, to_address, amount, asset="GBR"):
        """Add a mock transaction for testing."""
        self.transactions[tx_hash] = {
            "tx_hash": tx_hash,
            "from": from_address,
            "to": "0xGhalbirTokenContract",  # Token contract address
            "value": Decimal("0.0"),
            "gas": 100000,
            "gas_price": Decimal("20.0"),
            "nonce": 1,
            "block_number": self.current_block,
            "status": "success",
            "gas_used": 21000,
            "is_token_transfer": True,
            "token_to": to_address,
            "token_value": amount
        }
        
        # Add to current block
        self.blocks[self.current_block]["transactions"].append(tx_hash)
    
    def add_mock_block(self, block_number):
        """Add a mock block for testing."""
        self.blocks[block_number] = {
            "block_number": block_number,
            "hash": f"0x{block_number}{'c' * 60}",
            "parent_hash": f"0x{block_number - 1}{'c' * 60}",
            "timestamp": int(time.time()),
            "transactions": [],
            "gas_used": 0,
            "gas_limit": 8000000,
            "miner": "0xMiner1234567890"
        }


if __name__ == '__main__':
    unittest.main()
