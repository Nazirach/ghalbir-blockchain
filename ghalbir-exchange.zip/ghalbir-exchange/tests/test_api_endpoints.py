import unittest
import sys
import os
import json
import requests
from decimal import Decimal
import time
from unittest.mock import patch, MagicMock

# Add project root to path
sys.path.append('/home/ubuntu/ghalbir-exchange')

from src.api.auth_controller import AuthController
from src.api.user_controller import UserController
from src.api.trading_controller import TradingController
from src.services.user_service import UserService
from src.services.security_service import SecurityService
from src.services.audit_service import AuditService

class TestAPIEndpoints(unittest.TestCase):
    """Test suite for the Ghalbir Exchange API endpoints."""
    
    def setUp(self):
        """Set up test environment."""
        # Create test data directory
        self.test_data_dir = "/home/ubuntu/ghalbir-exchange/test_data_api"
        os.makedirs(self.test_data_dir, exist_ok=True)
        
        # Initialize services
        self.security_service = SecurityService(data_dir=self.test_data_dir)
        self.audit_service = AuditService(data_dir=self.test_data_dir)
        self.user_service = UserService(
            security_service=self.security_service,
            audit_service=self.audit_service,
            data_dir=self.test_data_dir
        )
        
        # Initialize controllers
        self.auth_controller = AuthController(
            user_service=self.user_service,
            security_service=self.security_service,
            audit_service=self.audit_service
        )
        
        self.user_controller = UserController(
            user_service=self.user_service,
            security_service=self.security_service,
            audit_service=self.audit_service
        )
        
        self.trading_controller = TradingController(
            order_service=MagicMock(),
            wallet_service=MagicMock(),
            trade_service=MagicMock(),
            security_service=self.security_service,
            audit_service=self.audit_service
        )
        
        # Create test user
        self.test_user = self.user_service.create_user(
            email="api_test@example.com",
            password="ApiTestPassword123!",
            full_name="API Test User"
        )
        
        # Login to get tokens
        self.login_response = self.user_service.login_user(
            email="api_test@example.com",
            password="ApiTestPassword123!",
            ip_address="127.0.0.1",
            user_agent="Test User Agent"
        )
        
        self.access_token = self.login_response["access_token"]
    
    def tearDown(self):
        """Clean up after tests."""
        # In a real implementation, we would clean up the test data directory
        # For this example, we'll leave it for inspection
        pass
    
    def test_register_endpoint(self):
        """Test user registration endpoint."""
        # Mock request data
        request_data = {
            "email": "new_user@example.com",
            "password": "NewUserPassword123!",
            "confirm_password": "NewUserPassword123!",
            "full_name": "New Test User"
        }
        
        # Mock request object
        request = MagicMock()
        request.json = request_data
        request.remote_addr = "127.0.0.1"
        request.headers = {"User-Agent": "Test Browser"}
        
        # Call register endpoint
        response = self.auth_controller.register(request)
        
        # Verify response
        self.assertEqual(response["status"], "success")
        self.assertIn("user", response)
        self.assertEqual(response["user"]["email"], "new_user@example.com")
        self.assertEqual(response["user"]["full_name"], "New Test User")
    
    def test_login_endpoint(self):
        """Test login endpoint."""
        # Mock request data
        request_data = {
            "email": "api_test@example.com",
            "password": "ApiTestPassword123!"
        }
        
        # Mock request object
        request = MagicMock()
        request.json = request_data
        request.remote_addr = "127.0.0.1"
        request.headers = {"User-Agent": "Test Browser"}
        
        # Call login endpoint
        response = self.auth_controller.login(request)
        
        # Verify response
        self.assertEqual(response["status"], "success")
        self.assertIn("access_token", response)
        self.assertIn("refresh_token", response)
        self.assertIn("user", response)
        self.assertEqual(response["user"]["email"], "api_test@example.com")
    
    def test_refresh_token_endpoint(self):
        """Test token refresh endpoint."""
        # Mock request data
        request_data = {
            "refresh_token": self.login_response["refresh_token"]
        }
        
        # Mock request object
        request = MagicMock()
        request.json = request_data
        
        # Call refresh token endpoint
        response = self.auth_controller.refresh_token(request)
        
        # Verify response
        self.assertEqual(response["status"], "success")
        self.assertIn("access_token", response)
        self.assertIn("refresh_token", response)
    
    def test_get_user_profile_endpoint(self):
        """Test get user profile endpoint."""
        # Mock request object with authorization
        request = MagicMock()
        request.headers = {"Authorization": f"Bearer {self.access_token}"}
        
        # Call get profile endpoint
        response = self.user_controller.get_profile(request)
        
        # Verify response
        self.assertEqual(response["status"], "success")
        self.assertIn("user", response)
        self.assertEqual(response["user"]["email"], "api_test@example.com")
        self.assertEqual(response["user"]["full_name"], "API Test User")
    
    def test_update_user_profile_endpoint(self):
        """Test update user profile endpoint."""
        # Mock request data
        request_data = {
            "full_name": "Updated API Test User"
        }
        
        # Mock request object with authorization
        request = MagicMock()
        request.json = request_data
        request.headers = {"Authorization": f"Bearer {self.access_token}"}
        
        # Call update profile endpoint
        response = self.user_controller.update_profile(request)
        
        # Verify response
        self.assertEqual(response["status"], "success")
        self.assertIn("user", response)
        self.assertEqual(response["user"]["full_name"], "Updated API Test User")
    
    def test_change_password_endpoint(self):
        """Test change password endpoint."""
        # Mock request data
        request_data = {
            "current_password": "ApiTestPassword123!",
            "new_password": "NewApiTestPassword456!",
            "confirm_password": "NewApiTestPassword456!"
        }
        
        # Mock request object with authorization
        request = MagicMock()
        request.json = request_data
        request.headers = {"Authorization": f"Bearer {self.access_token}"}
        request.remote_addr = "127.0.0.1"
        request.headers["User-Agent"] = "Test Browser"
        
        # Call change password endpoint
        response = self.user_controller.change_password(request)
        
        # Verify response
        self.assertEqual(response["status"], "success")
        
        # Verify password was changed by trying to login with new password
        login_response = self.user_service.login_user(
            email="api_test@example.com",
            password="NewApiTestPassword456!",
            ip_address="127.0.0.1",
            user_agent="Test User Agent"
        )
        
        self.assertTrue(login_response["success"])
    
    @patch('src.api.trading_controller.TradingController.get_market_data')
    def test_get_market_data_endpoint(self, mock_get_market_data):
        """Test get market data endpoint."""
        # Setup mock return value
        mock_get_market_data.return_value = {
            "status": "success",
            "data": {
                "symbol": "GBR/USDT",
                "last_price": "100.25",
                "24h_change": "+2.5%",
                "24h_high": "102.50",
                "24h_low": "98.75",
                "24h_volume": "15432.50"
            }
        }
        
        # Mock request object
        request = MagicMock()
        request.args = {"symbol": "GBR/USDT"}
        
        # Call get market data endpoint
        response = self.trading_controller.get_market_data(request)
        
        # Verify response
        self.assertEqual(response["status"], "success")
        self.assertIn("data", response)
        self.assertEqual(response["data"]["symbol"], "GBR/USDT")
    
    @patch('src.api.trading_controller.TradingController.get_order_book')
    def test_get_order_book_endpoint(self, mock_get_order_book):
        """Test get order book endpoint."""
        # Setup mock return value
        mock_get_order_book.return_value = {
            "status": "success",
            "data": {
                "symbol": "GBR/USDT",
                "bids": [
                    {"price": "100.00", "amount": "1.5000"},
                    {"price": "99.75", "amount": "2.3000"}
                ],
                "asks": [
                    {"price": "100.50", "amount": "1.2000"},
                    {"price": "101.00", "amount": "3.4000"}
                ]
            }
        }
        
        # Mock request object
        request = MagicMock()
        request.args = {"symbol": "GBR/USDT"}
        
        # Call get order book endpoint
        response = self.trading_controller.get_order_book(request)
        
        # Verify response
        self.assertEqual(response["status"], "success")
        self.assertIn("data", response)
        self.assertEqual(response["data"]["symbol"], "GBR/USDT")
        self.assertIn("bids", response["data"])
        self.assertIn("asks", response["data"])
    
    @patch('src.api.trading_controller.TradingController.place_order')
    def test_place_order_endpoint(self, mock_place_order):
        """Test place order endpoint."""
        # Setup mock return value
        mock_place_order.return_value = {
            "status": "success",
            "data": {
                "order_id": "order123",
                "symbol": "GBR/USDT",
                "type": "limit",
                "side": "buy",
                "price": "100.00",
                "amount": "1.0000",
                "status": "open"
            }
        }
        
        # Mock request data
        request_data = {
            "symbol": "GBR/USDT",
            "type": "limit",
            "side": "buy",
            "price": "100.00",
            "amount": "1.0000"
        }
        
        # Mock request object with authorization
        request = MagicMock()
        request.json = request_data
        request.headers = {"Authorization": f"Bearer {self.access_token}"}
        
        # Call place order endpoint
        response = self.trading_controller.place_order(request)
        
        # Verify response
        self.assertEqual(response["status"], "success")
        self.assertIn("data", response)
        self.assertEqual(response["data"]["symbol"], "GBR/USDT")
        self.assertEqual(response["data"]["side"], "buy")
    
    @patch('src.api.trading_controller.TradingController.cancel_order')
    def test_cancel_order_endpoint(self, mock_cancel_order):
        """Test cancel order endpoint."""
        # Setup mock return value
        mock_cancel_order.return_value = {
            "status": "success",
            "data": {
                "order_id": "order123",
                "cancelled": True
            }
        }
        
        # Mock request data
        request_data = {
            "order_id": "order123"
        }
        
        # Mock request object with authorization
        request = MagicMock()
        request.json = request_data
        request.headers = {"Authorization": f"Bearer {self.access_token}"}
        
        # Call cancel order endpoint
        response = self.trading_controller.cancel_order(request)
        
        # Verify response
        self.assertEqual(response["status"], "success")
        self.assertIn("data", response)
        self.assertEqual(response["data"]["order_id"], "order123")
        self.assertTrue(response["data"]["cancelled"])
    
    @patch('src.api.trading_controller.TradingController.get_user_orders')
    def test_get_user_orders_endpoint(self, mock_get_user_orders):
        """Test get user orders endpoint."""
        # Setup mock return value
        mock_get_user_orders.return_value = {
            "status": "success",
            "data": {
                "orders": [
                    {
                        "order_id": "order123",
                        "symbol": "GBR/USDT",
                        "type": "limit",
                        "side": "buy",
                        "price": "100.00",
                        "amount": "1.0000",
                        "filled_amount": "0.0000",
                        "status": "open",
                        "created_at": "2025-04-17T18:10:25Z"
                    }
                ]
            }
        }
        
        # Mock request object with authorization
        request = MagicMock()
        request.args = {"status": "open"}
        request.headers = {"Authorization": f"Bearer {self.access_token}"}
        
        # Call get user orders endpoint
        response = self.trading_controller.get_user_orders(request)
        
        # Verify response
        self.assertEqual(response["status"], "success")
        self.assertIn("data", response)
        self.assertIn("orders", response["data"])
        self.assertEqual(len(response["data"]["orders"]), 1)
        self.assertEqual(response["data"]["orders"][0]["order_id"], "order123")


if __name__ == '__main__':
    unittest.main()
