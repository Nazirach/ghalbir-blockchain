# Ghalbir Exchange Documentation

## Overview

Ghalbir Exchange is a comprehensive cryptocurrency exchange platform built for the Ghalbir blockchain. This platform enables users to trade Ghalbir tokens (GBR) and other cryptocurrencies in a secure, efficient, and user-friendly environment.

The exchange features a complete trading interface, order matching engine, wallet management system, blockchain integration, and robust security measures to ensure a reliable trading experience.

## Architecture

Ghalbir Exchange is built using a microservices architecture, with the following key components:

1. **Core Services**
   - Matching Engine: Processes and matches buy/sell orders
   - Wallet Service: Manages user balances and transactions
   - Order Service: Handles order creation, modification, and cancellation
   - Transaction Service: Processes deposits and withdrawals
   - Trade Service: Records and manages trade history

2. **Blockchain Integration**
   - Blockchain Connector: Interfaces with the Ghalbir blockchain
   - Blockchain Service: Manages deposits, withdrawals, and blockchain monitoring

3. **Security Layer**
   - Security Service: Handles authentication, authorization, and security features
   - Audit Service: Logs and monitors security events

4. **API Layer**
   - Auth Controller: Manages user authentication endpoints
   - User Controller: Handles user profile and settings endpoints
   - Trading Controller: Provides market data and trading endpoints

5. **Frontend Interface**
   - Web Interface: Responsive UI for desktop and mobile devices
   - Trading View: Real-time charts and order book visualization

## Features

### User Management
- User registration and authentication
- Profile management
- Two-factor authentication (2FA)
- Session management
- API key management

### Trading Features
- Market overview with price charts
- Order book visualization
- Limit and market orders
- Order history and trade history
- Real-time price updates

### Wallet Management
- Multiple asset support (GBR, USDT, etc.)
- Deposit and withdrawal functionality
- Transaction history
- Balance management

### Security Features
- Password hashing with bcrypt
- JWT token authentication
- Two-factor authentication
- Rate limiting
- Comprehensive audit logging
- Suspicious activity monitoring

### Blockchain Integration
- Deposit address generation
- Automatic deposit detection
- Secure withdrawal processing
- Transaction verification
- Hot wallet management

## Technical Stack

- **Backend**: Python
- **Database**: File-based storage (JSON)
- **Blockchain Integration**: Web3.py
- **Frontend**: HTML, CSS, JavaScript
- **Security**: JWT, TOTP (for 2FA), bcrypt

## Installation and Setup

### Prerequisites

- Python 3.10+
- Node.js 20+
- Access to Ghalbir blockchain node

### Installation Steps

1. Clone the repository:
   ```
   git clone https://github.com/your-organization/ghalbir-exchange.git
   cd ghalbir-exchange
   ```

2. Install Python dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Configure the application:
   - Edit `config.json` with your specific settings
   - Set up blockchain node connection details
   - Configure security parameters

4. Initialize the database:
   ```
   python scripts/init_db.py
   ```

5. Start the application:
   ```
   python app.py
   ```

## Deployment

### Production Deployment

For production deployment, we recommend using Docker containers for each service component:

1. Build Docker images:
   ```
   docker-compose build
   ```

2. Deploy containers:
   ```
   docker-compose up -d
   ```

### Scaling Considerations

- The matching engine can be scaled horizontally for high-volume trading pairs
- Use a load balancer for API endpoints
- Implement database sharding for large user bases
- Consider using a message queue for asynchronous processing

### Monitoring and Maintenance

- Set up monitoring for all services
- Implement automated backups
- Establish a regular security audit process
- Monitor blockchain integration for transaction confirmations

## API Documentation

### Authentication Endpoints

#### Register User
- **URL**: `/api/auth/register`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "email": "user@example.com",
    "password": "SecurePassword123!",
    "confirm_password": "SecurePassword123!",
    "full_name": "Example User"
  }
  ```
- **Response**:
  ```json
  {
    "status": "success",
    "user": {
      "id": "user123",
      "email": "user@example.com",
      "full_name": "Example User"
    }
  }
  ```

#### Login
- **URL**: `/api/auth/login`
- **Method**: `POST`
- **Request Body**:
  ```json
  {
    "email": "user@example.com",
    "password": "SecurePassword123!"
  }
  ```
- **Response**:
  ```json
  {
    "status": "success",
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expires_in": 86400,
    "user": {
      "id": "user123",
      "email": "user@example.com",
      "full_name": "Example User"
    }
  }
  ```

### Trading Endpoints

#### Get Market Data
- **URL**: `/api/trading/markets?symbol=GBR/USDT`
- **Method**: `GET`
- **Response**:
  ```json
  {
    "status": "success",
    "data": {
      "symbol": "GBR/USDT",
      "last_price": "100.25",
      "24h_change": "+2.5%",
      "24h_high": "102.50",
      "24h_low": "98.75",
      "24h_volume": "15432.50"
    }
  }
  ```

#### Get Order Book
- **URL**: `/api/trading/orderbook?symbol=GBR/USDT`
- **Method**: `GET`
- **Response**:
  ```json
  {
    "status": "success",
    "data": {
      "symbol": "GBR/USDT",
      "bids": [
        {"price": "100.00", "amount": "1.5000"},
        {"price": "99.75", "amount": "2.3000"}
      ],
      "asks": [
        {"price": "100.50", "amount": "1.2000"},
        {"price": "101.00", "amount": "3.4000"}
      ]
    }
  }
  ```

#### Place Order
- **URL**: `/api/trading/orders`
- **Method**: `POST`
- **Headers**: `Authorization: Bearer {access_token}`
- **Request Body**:
  ```json
  {
    "symbol": "GBR/USDT",
    "type": "limit",
    "side": "buy",
    "price": "100.00",
    "amount": "1.0000"
  }
  ```
- **Response**:
  ```json
  {
    "status": "success",
    "data": {
      "order_id": "order123",
      "symbol": "GBR/USDT",
      "type": "limit",
      "side": "buy",
      "price": "100.00",
      "amount": "1.0000",
      "status": "open"
    }
  }
  ```

### Wallet Endpoints

#### Get User Wallets
- **URL**: `/api/wallet/balances`
- **Method**: `GET`
- **Headers**: `Authorization: Bearer {access_token}`
- **Response**:
  ```json
  {
    "status": "success",
    "data": {
      "wallets": [
        {
          "asset": "GBR",
          "balance": "10.0000",
          "locked": "1.0000",
          "available": "9.0000"
        },
        {
          "asset": "USDT",
          "balance": "1000.0000",
          "locked": "100.0000",
          "available": "900.0000"
        }
      ]
    }
  }
  ```

#### Get Deposit Address
- **URL**: `/api/wallet/deposit-address?asset=GBR`
- **Method**: `GET`
- **Headers**: `Authorization: Bearer {access_token}`
- **Response**:
  ```json
  {
    "status": "success",
    "data": {
      "asset": "GBR",
      "address": "0x1234567890abcdef1234567890abcdef"
    }
  }
  ```

## Security Considerations

### User Security
- Implement strong password policies
- Enforce two-factor authentication for sensitive operations
- Limit login attempts to prevent brute force attacks
- Implement session timeouts and device tracking

### API Security
- Use rate limiting to prevent abuse
- Implement IP-based restrictions for suspicious activity
- Validate all input data
- Use HTTPS for all communications

### Wallet Security
- Keep majority of funds in cold storage
- Implement multi-signature wallets for hot wallets
- Regular security audits of wallet infrastructure
- Monitor for unusual withdrawal patterns

### Blockchain Security
- Verify transaction confirmations before crediting deposits
- Implement withdrawal approval workflows
- Monitor blockchain for double-spend attempts
- Keep private keys secure and encrypted

## Testing

The Ghalbir Exchange platform includes comprehensive test suites:

1. **Core Exchange Tests**: Test user management, wallet operations, order matching, and trade execution
2. **Blockchain Integration Tests**: Test deposit address generation, deposit processing, and withdrawals
3. **API Endpoint Tests**: Test all API endpoints for correct functionality

To run the tests:
```
python -m unittest discover tests
```

## Troubleshooting

### Common Issues

1. **Connection to blockchain node fails**
   - Check network connectivity
   - Verify node is running and accessible
   - Check authentication credentials

2. **Order matching not working**
   - Verify matching engine service is running
   - Check for sufficient balance in user wallets
   - Ensure price and amount are valid

3. **Deposits not being detected**
   - Check blockchain monitor service is running
   - Verify deposit address generation is working
   - Check blockchain node synchronization status

### Logs

Log files are stored in the `logs` directory:
- `app.log`: General application logs
- `audit.log`: Security and audit logs
- `blockchain.log`: Blockchain integration logs
- `error.log`: Error logs

## Maintenance

### Backup Procedures
- Database backups should be performed daily
- Wallet private keys should be backed up securely
- Configuration files should be version controlled

### Upgrade Procedures
1. Announce maintenance window to users
2. Create backup of current system
3. Deploy new version to staging environment
4. Test thoroughly
5. Deploy to production during low-traffic period
6. Monitor system after upgrade

## Support

For technical support, please contact:
- Email: support@ghalbir-exchange.com
- Technical documentation: https://docs.ghalbir-exchange.com

## License

Ghalbir Exchange is licensed under the MIT License. See LICENSE file for details.
