# Ghalbir Exchange Deployment Guide

## Overview

This guide provides detailed instructions for deploying the Ghalbir Exchange platform in various environments. Follow these steps to set up a fully functional cryptocurrency exchange for the Ghalbir blockchain.

## Deployment Options

Ghalbir Exchange can be deployed in several ways:

1. **Development Environment**: For local testing and development
2. **Staging Environment**: For pre-production testing
3. **Production Environment**: For live trading

## Prerequisites

Before deploying Ghalbir Exchange, ensure you have the following:

- **Hardware Requirements**:
  - CPU: 4+ cores
  - RAM: 8GB+ (16GB+ recommended for production)
  - Storage: 100GB+ SSD
  - Network: Stable internet connection with 100Mbps+ bandwidth

- **Software Requirements**:
  - Operating System: Ubuntu 20.04 LTS or newer
  - Python 3.10+
  - Node.js 20+
  - Docker and Docker Compose (for containerized deployment)
  - Nginx (for production deployment)
  - SSL certificate (for production deployment)

- **Blockchain Requirements**:
  - Access to Ghalbir blockchain node
  - Wallet with sufficient GBR for hot wallet initialization

## Development Environment Setup

### 1. Clone the Repository

```bash
git clone https://github.com/your-organization/ghalbir-exchange.git
cd ghalbir-exchange
```

### 2. Install Dependencies

```bash
# Install Python dependencies
pip install -r requirements.txt

# Install Node.js dependencies for frontend
cd src/frontend
npm install
cd ../..
```

### 3. Configure the Application

Create a configuration file by copying the template:

```bash
cp config.template.json config.json
```

Edit `config.json` with your specific settings:

```json
{
  "app": {
    "name": "Ghalbir Exchange",
    "environment": "development",
    "debug": true,
    "host": "0.0.0.0",
    "port": 5000,
    "secret_key": "your-secret-key-here"
  },
  "blockchain": {
    "node_url": "http://localhost:8545",
    "chain_id": 1337,
    "contract_address": "0x1234567890abcdef1234567890abcdef",
    "hot_wallet_address": "0xabcdef1234567890abcdef1234567890",
    "hot_wallet_private_key": "your-encrypted-private-key"
  },
  "database": {
    "path": "/home/ubuntu/ghalbir-exchange/data"
  },
  "security": {
    "jwt_expiry": 86400,
    "jwt_refresh_expiry": 604800,
    "password_min_length": 8,
    "rate_limit_login_attempts": 5,
    "rate_limit_login_window": 900
  }
}
```

### 4. Initialize the Database

```bash
python scripts/init_db.py
```

### 5. Start the Development Server

```bash
python app.py
```

The development server will be available at http://localhost:5000.

## Staging Environment Setup

### 1. Prepare the Server

```bash
# Update system packages
sudo apt update
sudo apt upgrade -y

# Install required packages
sudo apt install -y python3 python3-pip nodejs npm docker.io docker-compose nginx

# Create application directory
sudo mkdir -p /opt/ghalbir-exchange
sudo chown $(whoami):$(whoami) /opt/ghalbir-exchange
```

### 2. Clone the Repository

```bash
git clone https://github.com/your-organization/ghalbir-exchange.git /opt/ghalbir-exchange
cd /opt/ghalbir-exchange
```

### 3. Configure the Application

```bash
cp config.template.json config.json
```

Edit `config.json` with staging-specific settings:

```json
{
  "app": {
    "name": "Ghalbir Exchange",
    "environment": "staging",
    "debug": false,
    "host": "0.0.0.0",
    "port": 5000,
    "secret_key": "your-staging-secret-key-here"
  },
  "blockchain": {
    "node_url": "https://staging-node.ghalbir.network",
    "chain_id": 1337,
    "contract_address": "0x1234567890abcdef1234567890abcdef",
    "hot_wallet_address": "0xabcdef1234567890abcdef1234567890",
    "hot_wallet_private_key": "your-encrypted-private-key"
  },
  "database": {
    "path": "/opt/ghalbir-exchange/data"
  },
  "security": {
    "jwt_expiry": 86400,
    "jwt_refresh_expiry": 604800,
    "password_min_length": 8,
    "rate_limit_login_attempts": 5,
    "rate_limit_login_window": 900
  }
}
```

### 4. Build and Start Docker Containers

```bash
docker-compose -f docker-compose.staging.yml build
docker-compose -f docker-compose.staging.yml up -d
```

### 5. Configure Nginx

Create an Nginx configuration file:

```bash
sudo nano /etc/nginx/sites-available/ghalbir-exchange
```

Add the following configuration:

```nginx
server {
    listen 80;
    server_name staging.ghalbir-exchange.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable the site and restart Nginx:

```bash
sudo ln -s /etc/nginx/sites-available/ghalbir-exchange /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## Production Environment Setup

### 1. Prepare the Server

```bash
# Update system packages
sudo apt update
sudo apt upgrade -y

# Install required packages
sudo apt install -y python3 python3-pip nodejs npm docker.io docker-compose nginx certbot python3-certbot-nginx

# Create application directory
sudo mkdir -p /opt/ghalbir-exchange
sudo chown $(whoami):$(whoami) /opt/ghalbir-exchange
```

### 2. Clone the Repository

```bash
git clone https://github.com/your-organization/ghalbir-exchange.git /opt/ghalbir-exchange
cd /opt/ghalbir-exchange
```

### 3. Configure the Application

```bash
cp config.template.json config.json
```

Edit `config.json` with production-specific settings:

```json
{
  "app": {
    "name": "Ghalbir Exchange",
    "environment": "production",
    "debug": false,
    "host": "0.0.0.0",
    "port": 5000,
    "secret_key": "your-production-secret-key-here"
  },
  "blockchain": {
    "node_url": "https://node.ghalbir.network",
    "chain_id": 1,
    "contract_address": "0x1234567890abcdef1234567890abcdef",
    "hot_wallet_address": "0xabcdef1234567890abcdef1234567890",
    "hot_wallet_private_key": "your-encrypted-private-key"
  },
  "database": {
    "path": "/opt/ghalbir-exchange/data"
  },
  "security": {
    "jwt_expiry": 86400,
    "jwt_refresh_expiry": 604800,
    "password_min_length": 8,
    "rate_limit_login_attempts": 5,
    "rate_limit_login_window": 900
  }
}
```

### 4. Build and Start Docker Containers

```bash
docker-compose -f docker-compose.production.yml build
docker-compose -f docker-compose.production.yml up -d
```

### 5. Configure Nginx with SSL

Create an Nginx configuration file:

```bash
sudo nano /etc/nginx/sites-available/ghalbir-exchange
```

Add the following configuration:

```nginx
server {
    listen 80;
    server_name exchange.ghalbir.com;
    
    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name exchange.ghalbir.com;

    ssl_certificate /etc/letsencrypt/live/exchange.ghalbir.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/exchange.ghalbir.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers on;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-SHA384;
    ssl_session_timeout 1d;
    ssl_session_cache shared:SSL:10m;
    ssl_stapling on;
    ssl_stapling_verify on;
    add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload";
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;

    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/ghalbir-exchange /etc/nginx/sites-enabled/
sudo nginx -t
```

### 6. Obtain SSL Certificate

```bash
sudo certbot --nginx -d exchange.ghalbir.com
```

### 7. Restart Nginx

```bash
sudo systemctl restart nginx
```

## Docker Deployment

### Docker Compose Configuration

The repository includes Docker Compose files for different environments:

- `docker-compose.yml`: Default configuration for development
- `docker-compose.staging.yml`: Configuration for staging environment
- `docker-compose.production.yml`: Configuration for production environment

Example `docker-compose.production.yml`:

```yaml
version: '3'

services:
  api:
    build:
      context: .
      dockerfile: Dockerfile
    restart: always
    ports:
      - "5000:5000"
    volumes:
      - ./config.json:/app/config.json
      - ./data:/app/data
    environment:
      - ENVIRONMENT=production
    networks:
      - ghalbir-network

  blockchain-monitor:
    build:
      context: .
      dockerfile: Dockerfile.monitor
    restart: always
    volumes:
      - ./config.json:/app/config.json
      - ./data:/app/data
    environment:
      - ENVIRONMENT=production
    networks:
      - ghalbir-network

  matching-engine:
    build:
      context: .
      dockerfile: Dockerfile.engine
    restart: always
    volumes:
      - ./config.json:/app/config.json
      - ./data:/app/data
    environment:
      - ENVIRONMENT=production
    networks:
      - ghalbir-network

networks:
  ghalbir-network:
    driver: bridge
```

## Scaling the Platform

### Horizontal Scaling

For high-traffic environments, you can scale the platform horizontally:

1. **API Servers**: Deploy multiple API server instances behind a load balancer
2. **Matching Engine**: Shard the matching engine by trading pairs
3. **Blockchain Monitor**: Deploy multiple instances for redundancy

Example load balancer configuration (HAProxy):

```
frontend http_front
   bind *:80
   stats uri /haproxy?stats
   default_backend http_back

backend http_back
   balance roundrobin
   server api1 api1:5000 check
   server api2 api2:5000 check
   server api3 api3:5000 check
```

### Database Scaling

As the platform grows, consider migrating from file-based storage to a distributed database:

1. **MongoDB**: For user data, orders, and transactions
2. **Redis**: For caching and real-time data
3. **TimescaleDB**: For time-series data like market prices

## Monitoring and Maintenance

### Setting Up Monitoring

1. **Prometheus**: For metrics collection
2. **Grafana**: For visualization
3. **Alertmanager**: For alerts

Example Prometheus configuration:

```yaml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'ghalbir-exchange'
    static_configs:
      - targets: ['localhost:5000']
```

### Backup Procedures

1. **Database Backups**:
   ```bash
   # Create a backup script
   mkdir -p /opt/ghalbir-exchange/backups
   
   # Add to crontab
   echo "0 2 * * * tar -czf /opt/ghalbir-exchange/backups/data-\$(date +\%Y\%m\%d).tar.gz /opt/ghalbir-exchange/data" | crontab -
   ```

2. **Configuration Backups**:
   ```bash
   # Backup configuration files
   cp /opt/ghalbir-exchange/config.json /opt/ghalbir-exchange/backups/config-$(date +%Y%m%d).json
   ```

3. **Wallet Backups**:
   - Securely back up wallet private keys
   - Consider using hardware security modules (HSMs) for production

### Upgrade Procedures

1. **Prepare for Upgrade**:
   ```bash
   # Create a backup
   tar -czf /opt/ghalbir-exchange/backups/pre-upgrade-$(date +%Y%m%d).tar.gz /opt/ghalbir-exchange
   ```

2. **Pull Latest Code**:
   ```bash
   cd /opt/ghalbir-exchange
   git pull origin main
   ```

3. **Update Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Restart Services**:
   ```bash
   docker-compose -f docker-compose.production.yml down
   docker-compose -f docker-compose.production.yml build
   docker-compose -f docker-compose.production.yml up -d
   ```

## Security Hardening

### Server Hardening

1. **Firewall Configuration**:
   ```bash
   # Allow only necessary ports
   sudo ufw allow 22
   sudo ufw allow 80
   sudo ufw allow 443
   sudo ufw enable
   ```

2. **SSH Hardening**:
   ```bash
   # Edit SSH configuration
   sudo nano /etc/ssh/sshd_config
   
   # Set the following:
   PermitRootLogin no
   PasswordAuthentication no
   
   # Restart SSH
   sudo systemctl restart sshd
   ```

3. **Fail2Ban Installation**:
   ```bash
   sudo apt install -y fail2ban
   sudo systemctl enable fail2ban
   sudo systemctl start fail2ban
   ```

### Application Security

1. **Regular Security Updates**:
   ```bash
   # Update system packages
   sudo apt update
   sudo apt upgrade -y
   
   # Update application dependencies
   pip install -r requirements.txt --upgrade
   ```

2. **Security Scanning**:
   ```bash
   # Install security scanning tools
   pip install bandit safety
   
   # Scan code for vulnerabilities
   bandit -r /opt/ghalbir-exchange
   safety check -r requirements.txt
   ```

## Troubleshooting

### Common Issues

1. **Application Won't Start**:
   - Check logs: `docker-compose logs api`
   - Verify configuration file is valid
   - Ensure all required services are running

2. **Blockchain Connection Issues**:
   - Verify blockchain node is accessible
   - Check network connectivity
   - Ensure node is fully synced

3. **Performance Issues**:
   - Check server resources (CPU, memory, disk)
   - Monitor database size and performance
   - Consider scaling options if needed

### Log Locations

- **Application Logs**: `/opt/ghalbir-exchange/logs/app.log`
- **Nginx Logs**: `/var/log/nginx/access.log` and `/var/log/nginx/error.log`
- **Docker Logs**: `docker-compose logs`

## Conclusion

Following this deployment guide will help you set up a secure and scalable Ghalbir Exchange platform. For additional support, refer to the documentation or contact the development team.

Remember to regularly update and maintain your deployment to ensure security and performance.
