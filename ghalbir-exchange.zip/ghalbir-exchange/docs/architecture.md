# Ghalbir Exchange - Desain Arsitektur

## Daftar Isi
1. [Pengenalan](#pengenalan)
2. [Arsitektur Sistem](#arsitektur-sistem)
3. [Komponen Utama](#komponen-utama)
4. [Model Data](#model-data)
5. [API](#api)
6. [Integrasi dengan Blockchain Ghalbir](#integrasi-dengan-blockchain-ghalbir)
7. [Keamanan](#keamanan)
8. [Skalabilitas](#skalabilitas)

## Pengenalan

Ghalbir Exchange adalah platform perdagangan kripto yang terintegrasi dengan blockchain Ghalbir. Platform ini memungkinkan pengguna untuk membeli, menjual, dan menukar token Ghalbir (GBR) dan aset kripto lainnya. Dokumen ini menjelaskan arsitektur dan komponen utama dari Ghalbir Exchange.

## Arsitektur Sistem

Ghalbir Exchange menggunakan arsitektur microservices untuk memastikan skalabilitas dan pemeliharaan yang mudah. Berikut adalah diagram arsitektur tingkat tinggi:

```
+------------------+     +------------------+     +------------------+
|                  |     |                  |     |                  |
|  Frontend        |<--->|  API Gateway     |<--->|  Auth Service    |
|  (Web/Mobile)    |     |                  |     |                  |
|                  |     |                  |     |                  |
+------------------+     +------------------+     +------------------+
                               ^                          ^
                               |                          |
                               v                          v
+------------------+     +------------------+     +------------------+
|                  |     |                  |     |                  |
|  Order Service   |<--->|  Matching Engine |<--->|  Wallet Service  |
|                  |     |                  |     |                  |
|                  |     |                  |     |                  |
+------------------+     +------------------+     +------------------+
                               ^                          ^
                               |                          |
                               v                          v
+------------------+     +------------------+     +------------------+
|                  |     |                  |     |                  |
|  Market Data     |<--->|  Blockchain      |<--->|  KYC/AML         |
|  Service         |     |  Integration     |     |  Service         |
|                  |     |                  |     |                  |
+------------------+     +------------------+     +------------------+
```

## Komponen Utama

### 1. Frontend
- **Web Application**: Antarmuka pengguna berbasis web menggunakan React.js
- **Mobile Application**: Aplikasi mobile untuk Android dan iOS menggunakan React Native

### 2. API Gateway
- Titik masuk tunggal untuk semua permintaan API
- Menangani autentikasi, otorisasi, dan rate limiting
- Merutekan permintaan ke layanan yang sesuai

### 3. Auth Service
- Mengelola pendaftaran dan login pengguna
- Menangani autentikasi dua faktor (2FA)
- Mengelola sesi dan token JWT

### 4. Order Service
- Menerima dan memvalidasi pesanan beli/jual
- Menyimpan riwayat pesanan
- Mengelola status pesanan

### 5. Matching Engine
- Mencocokkan pesanan beli dan jual
- Mengimplementasikan algoritma FIFO (First In, First Out)
- Menangani berbagai jenis pesanan (limit, market, stop-loss)

### 6. Wallet Service
- Mengelola dompet pengguna untuk berbagai aset kripto
- Menangani deposit dan penarikan
- Memantau saldo dan transaksi

### 7. Market Data Service
- Mengumpulkan dan menyimpan data pasar (harga, volume, dll.)
- Menyediakan data untuk grafik dan analisis
- Menghitung statistik pasar

### 8. Blockchain Integration
- Terhubung dengan node Ghalbir Blockchain
- Memverifikasi transaksi blockchain
- Mengelola smart contract untuk token dan perdagangan

### 9. KYC/AML Service
- Menangani proses Know Your Customer (KYC)
- Menerapkan pemeriksaan Anti-Money Laundering (AML)
- Menyimpan dokumen identitas pengguna dengan aman

## Model Data

### User
```
{
  "id": "string",
  "email": "string",
  "password_hash": "string",
  "full_name": "string",
  "created_at": "timestamp",
  "updated_at": "timestamp",
  "kyc_status": "enum(pending, approved, rejected)",
  "two_factor_enabled": "boolean",
  "status": "enum(active, suspended, locked)"
}
```

### Wallet
```
{
  "id": "string",
  "user_id": "string",
  "asset": "string",
  "balance": "decimal",
  "address": "string",
  "created_at": "timestamp",
  "updated_at": "timestamp"
}
```

### Order
```
{
  "id": "string",
  "user_id": "string",
  "type": "enum(buy, sell)",
  "order_type": "enum(limit, market, stop_limit)",
  "trading_pair": "string",
  "amount": "decimal",
  "price": "decimal",
  "status": "enum(pending, filled, partially_filled, cancelled)",
  "created_at": "timestamp",
  "updated_at": "timestamp"
}
```

### Trade
```
{
  "id": "string",
  "buyer_order_id": "string",
  "seller_order_id": "string",
  "trading_pair": "string",
  "amount": "decimal",
  "price": "decimal",
  "fee": "decimal",
  "created_at": "timestamp"
}
```

### Transaction
```
{
  "id": "string",
  "user_id": "string",
  "type": "enum(deposit, withdrawal)",
  "asset": "string",
  "amount": "decimal",
  "fee": "decimal",
  "address": "string",
  "tx_hash": "string",
  "status": "enum(pending, completed, failed)",
  "created_at": "timestamp",
  "updated_at": "timestamp"
}
```

## API

### Auth API
- `POST /api/auth/register` - Mendaftarkan pengguna baru
- `POST /api/auth/login` - Login pengguna
- `POST /api/auth/logout` - Logout pengguna
- `POST /api/auth/2fa/enable` - Mengaktifkan 2FA
- `POST /api/auth/2fa/verify` - Memverifikasi kode 2FA

### User API
- `GET /api/users/me` - Mendapatkan profil pengguna
- `PUT /api/users/me` - Memperbarui profil pengguna
- `POST /api/users/kyc` - Mengirimkan dokumen KYC

### Wallet API
- `GET /api/wallets` - Mendapatkan daftar dompet pengguna
- `GET /api/wallets/{asset}` - Mendapatkan dompet untuk aset tertentu
- `POST /api/wallets/{asset}/deposit` - Mendapatkan alamat deposit
- `POST /api/wallets/{asset}/withdraw` - Melakukan penarikan

### Order API
- `GET /api/orders` - Mendapatkan daftar pesanan pengguna
- `POST /api/orders` - Membuat pesanan baru
- `DELETE /api/orders/{id}` - Membatalkan pesanan

### Market API
- `GET /api/markets` - Mendapatkan daftar pasar yang tersedia
- `GET /api/markets/{trading_pair}/orderbook` - Mendapatkan order book
- `GET /api/markets/{trading_pair}/trades` - Mendapatkan riwayat perdagangan
- `GET /api/markets/{trading_pair}/ticker` - Mendapatkan ticker pasar
- `GET /api/markets/{trading_pair}/candles` - Mendapatkan data candlestick

## Integrasi dengan Blockchain Ghalbir

Ghalbir Exchange terintegrasi dengan blockchain Ghalbir melalui komponen Blockchain Integration. Integrasi ini mencakup:

1. **Deposit dan Penarikan**
   - Memantau alamat deposit untuk transaksi masuk
   - Mengirim transaksi keluar untuk penarikan
   - Memverifikasi transaksi di blockchain

2. **Smart Contract**
   - Menggunakan smart contract untuk token ERC-20
   - Mengimplementasikan kontrak escrow untuk perdagangan terdesentralisasi
   - Mengelola token Ghalbir (GBR) sebagai token utilitas platform

3. **Verifikasi Transaksi**
   - Memverifikasi transaksi di blockchain Ghalbir
   - Menunggu konfirmasi yang cukup sebelum mengkreditkan deposit
   - Menangani kasus edge seperti fork blockchain

## Keamanan

Ghalbir Exchange menerapkan beberapa lapisan keamanan:

1. **Keamanan Pengguna**
   - Autentikasi dua faktor (2FA)
   - Enkripsi password dengan bcrypt
   - Deteksi aktivitas mencurigakan

2. **Keamanan Sistem**
   - Enkripsi data sensitif
   - Firewall dan WAF (Web Application Firewall)
   - Pemantauan dan logging

3. **Keamanan Dompet**
   - Dompet dingin (cold wallet) untuk penyimpanan mayoritas dana
   - Dompet panas (hot wallet) dengan dana terbatas untuk operasi harian
   - Multi-signature untuk penarikan besar

4. **Keamanan API**
   - Rate limiting
   - Validasi input
   - HTTPS dan TLS 1.3

## Skalabilitas

Ghalbir Exchange dirancang untuk skalabilitas:

1. **Horizontal Scaling**
   - Microservices dapat diskalakan secara independen
   - Menggunakan Kubernetes untuk orkestrasi kontainer

2. **Database Sharding**
   - Sharding berdasarkan user_id untuk data pengguna
   - Sharding berdasarkan trading_pair untuk data pasar

3. **Caching**
   - Redis untuk caching data yang sering diakses
   - Memcached untuk caching sesi

4. **Asynchronous Processing**
   - Menggunakan message queue (RabbitMQ/Kafka) untuk komunikasi antar layanan
   - Background workers untuk tugas yang membutuhkan waktu lama
