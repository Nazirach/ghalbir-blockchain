import hashlib
import json
import time
import random
import binascii
import ecdsa

def calculate_hash(data):
    """
    Menghitung hash SHA-256 dari data yang diberikan.
    
    Args:
        data: Data yang akan di-hash (string atau dict)
        
    Returns:
        String hash dalam format hexadecimal
    """
    if isinstance(data, dict):
        data = json.dumps(data, sort_keys=True)
    
    if not isinstance(data, bytes):
        data = data.encode('utf-8')
        
    return hashlib.sha256(data).hexdigest()

def generate_keypair():
    """
    Menghasilkan pasangan kunci publik/privat menggunakan ECDSA.
    
    Returns:
        Tuple (private_key, public_key) dalam format hexadecimal
    """
    # Menggunakan kurva SECP256k1 seperti yang digunakan Ethereum
    private_key = ecdsa.SigningKey.generate(curve=ecdsa.SECP256k1)
    public_key = private_key.get_verifying_key()
    
    private_key_hex = private_key.to_string().hex()
    public_key_hex = public_key.to_string().hex()
    
    return private_key_hex, public_key_hex

def sign_data(private_key_hex, data):
    """
    Menandatangani data menggunakan kunci privat.
    
    Args:
        private_key_hex: Kunci privat dalam format hexadecimal
        data: Data yang akan ditandatangani
        
    Returns:
        Tanda tangan dalam format hexadecimal
    """
    if isinstance(data, dict):
        data = json.dumps(data, sort_keys=True)
    
    if not isinstance(data, bytes):
        data = data.encode('utf-8')
    
    private_key_bytes = bytes.fromhex(private_key_hex)
    private_key = ecdsa.SigningKey.from_string(private_key_bytes, curve=ecdsa.SECP256k1)
    signature = private_key.sign(data)
    
    return signature.hex()

def verify_signature(public_key_hex, signature_hex, data):
    """
    Memverifikasi tanda tangan menggunakan kunci publik.
    
    Args:
        public_key_hex: Kunci publik dalam format hexadecimal
        signature_hex: Tanda tangan dalam format hexadecimal
        data: Data yang ditandatangani
        
    Returns:
        Boolean yang menunjukkan apakah tanda tangan valid
    """
    if isinstance(data, dict):
        data = json.dumps(data, sort_keys=True)
    
    if not isinstance(data, bytes):
        data = data.encode('utf-8')
    
    public_key_bytes = bytes.fromhex(public_key_hex)
    signature_bytes = bytes.fromhex(signature_hex)
    
    try:
        public_key = ecdsa.VerifyingKey.from_string(public_key_bytes, curve=ecdsa.SECP256k1)
        return public_key.verify(signature_bytes, data)
    except:
        return False

def generate_address(public_key_hex):
    """
    Menghasilkan alamat dari kunci publik, mirip dengan cara Ethereum.
    
    Args:
        public_key_hex: Kunci publik dalam format hexadecimal
        
    Returns:
        Alamat dalam format hexadecimal
    """
    public_key_bytes = bytes.fromhex(public_key_hex)
    
    # Menggunakan Keccak-256 seperti Ethereum
    keccak = hashlib.sha3_256()
    keccak.update(public_key_bytes)
    
    # Mengambil 20 byte terakhir dari hash
    address = keccak.digest()[-20:].hex()
    
    # Menambahkan awalan '0x' seperti Ethereum
    return '0x' + address

def proof_of_work(block_header, difficulty):
    """
    Implementasi algoritma Proof of Work.
    
    Args:
        block_header: Header blok yang akan di-mining
        difficulty: Tingkat kesulitan (jumlah nol di awal hash)
        
    Returns:
        Tuple (nonce, hash) yang memenuhi tingkat kesulitan
    """
    target = '0' * difficulty
    nonce = 0
    
    while True:
        block_header['nonce'] = nonce
        block_hash = calculate_hash(block_header)
        
        if block_hash.startswith(target):
            return nonce, block_hash
        
        nonce += 1
