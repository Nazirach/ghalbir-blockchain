import json
import os
from flask import Flask, request, jsonify
from ..wallet.wallet import Wallet
from ..core.blockchain import Blockchain
from ..core.transaction import Transaction
from ..vm.virtual_machine import VirtualMachine
from ..vm.compiler import ContractCompiler

class MetaMaskAPI:
    """
    Kelas yang menyediakan API untuk integrasi dengan MetaMask.
    """
    def __init__(self, blockchain, vm):
        """
        Inisialisasi API MetaMask.
        
        Args:
            blockchain: Objek blockchain
            vm: Objek virtual machine
        """
        self.blockchain = blockchain
        self.vm = vm
        self.app = Flask(__name__)
        self.wallets = {}  # Menyimpan wallet yang terdaftar
        
        # Daftarkan endpoint API
        self.register_routes()
    
    def register_routes(self):
        """
        Mendaftarkan route untuk API.
        """
        # Endpoint untuk JSON-RPC
        @self.app.route('/api', methods=['POST'])
        def api():
            # Terima request JSON-RPC
            request_data = request.get_json()
            
            # Proses request
            response = self.process_jsonrpc(request_data)
            
            # Kirim response
            return jsonify(response)
    
    def process_jsonrpc(self, request_data):
        """
        Memproses request JSON-RPC.
        
        Args:
            request_data: Data request JSON-RPC
            
        Returns:
            Response JSON-RPC
        """
        # Validasi request
        if not isinstance(request_data, dict):
            return self.jsonrpc_error(-32600, "Invalid Request")
        
        # Dapatkan parameter request
        jsonrpc = request_data.get('jsonrpc')
        method = request_data.get('method')
        params = request_data.get('params', [])
        id = request_data.get('id')
        
        # Validasi versi JSON-RPC
        if jsonrpc != '2.0':
            return self.jsonrpc_error(-32600, "Invalid Request", id)
        
        # Proses method
        try:
            if method == 'eth_accounts':
                result = self.eth_accounts()
            elif method == 'eth_getBalance':
                result = self.eth_getBalance(params)
            elif method == 'eth_sendTransaction':
                result = self.eth_sendTransaction(params)
            elif method == 'eth_call':
                result = self.eth_call(params)
            elif method == 'eth_estimateGas':
                result = self.eth_estimateGas(params)
            elif method == 'eth_getTransactionCount':
                result = self.eth_getTransactionCount(params)
            elif method == 'eth_getBlockByNumber':
                result = self.eth_getBlockByNumber(params)
            elif method == 'eth_getBlockByHash':
                result = self.eth_getBlockByHash(params)
            elif method == 'eth_blockNumber':
                result = self.eth_blockNumber()
            elif method == 'eth_gasPrice':
                result = self.eth_gasPrice()
            elif method == 'eth_chainId':
                result = self.eth_chainId()
            elif method == 'net_version':
                result = self.net_version()
            elif method == 'personal_sign':
                result = self.personal_sign(params)
            elif method == 'eth_sign':
                result = self.eth_sign(params)
            elif method == 'eth_signTransaction':
                result = self.eth_signTransaction(params)
            else:
                return self.jsonrpc_error(-32601, f"Method {method} not found", id)
            
            # Buat response
            return {
                'jsonrpc': '2.0',
                'id': id,
                'result': result
            }
        except Exception as e:
            return self.jsonrpc_error(-32603, str(e), id)
    
    def jsonrpc_error(self, code, message, id=None):
        """
        Membuat response error JSON-RPC.
        
        Args:
            code: Kode error
            message: Pesan error
            id: ID request
            
        Returns:
            Response error JSON-RPC
        """
        return {
            'jsonrpc': '2.0',
            'id': id,
            'error': {
                'code': code,
                'message': message
            }
        }
    
    def eth_accounts(self):
        """
        Mendapatkan daftar alamat akun.
        
        Returns:
            Daftar alamat akun
        """
        return list(self.wallets.keys())
    
    def eth_getBalance(self, params):
        """
        Mendapatkan saldo akun.
        
        Args:
            params: Parameter request
            
        Returns:
            Saldo akun dalam format hexadecimal
        """
        address = params[0]
        # block_param = params[1]  # 'latest', 'earliest', 'pending', atau nomor blok
        
        # Dapatkan saldo dari blockchain
        balance = self.blockchain.get_balance(address)
        
        # Konversi ke format hexadecimal
        return hex(balance)
    
    def eth_sendTransaction(self, params):
        """
        Mengirim transaksi.
        
        Args:
            params: Parameter request
            
        Returns:
            Hash transaksi
        """
        tx_params = params[0]
        
        # Dapatkan parameter transaksi
        from_address = tx_params.get('from')
        to_address = tx_params.get('to')
        value = int(tx_params.get('value', '0x0'), 16)
        data = tx_params.get('data', '')
        gas_price = int(tx_params.get('gasPrice', '0x1'), 16)
        gas_limit = int(tx_params.get('gas', '0x5208'), 16)  # Default: 21000
        
        # Cek apakah wallet ada
        if from_address not in self.wallets:
            raise ValueError(f"Wallet for address {from_address} not found")
        
        wallet = self.wallets[from_address]
        
        # Buat dan tandatangani transaksi
        transaction = wallet.create_transaction(to_address, value, data, gas_price, gas_limit)
        
        # Tambahkan transaksi ke blockchain
        if not self.blockchain.add_transaction(transaction):
            raise ValueError("Failed to add transaction to blockchain")
        
        # Hitung hash transaksi
        from ..utils.crypto_utils import calculate_hash
        tx_hash = calculate_hash(transaction.to_dict())
        
        return f"0x{tx_hash}"
    
    def eth_call(self, params):
        """
        Memanggil metode kontrak tanpa membuat transaksi.
        
        Args:
            params: Parameter request
            
        Returns:
            Hasil eksekusi metode
        """
        tx_params = params[0]
        # block_param = params[1]  # 'latest', 'earliest', 'pending', atau nomor blok
        
        # Dapatkan parameter transaksi
        from_address = tx_params.get('from')
        to_address = tx_params.get('to')
        data = tx_params.get('data', '')
        value = int(tx_params.get('value', '0x0'), 16)
        
        # Parse data untuk mendapatkan metode dan parameter
        # Format data: 0x + keccak256(signature) + parameter yang di-encode
        # Untuk sederhananya, kita asumsikan data berisi nama metode dan parameter dalam format JSON
        
        try:
            # Decode data
            if data.startswith('0x'):
                data = data[2:]
            
            data_json = bytes.fromhex(data).decode('utf-8')
            data_obj = json.loads(data_json)
            
            method = data_obj.get('method')
            method_params = data_obj.get('params', {})
            
            # Panggil kontrak
            contract = self.vm.get_contract(to_address)
            if not contract:
                raise ValueError(f"Contract at address {to_address} not found")
            
            result = contract.execute(method, method_params, from_address, value)
            
            # Encode hasil
            result_json = json.dumps(result)
            result_hex = result_json.encode('utf-8').hex()
            
            return f"0x{result_hex}"
        except Exception as e:
            raise ValueError(f"Failed to execute contract method: {str(e)}")
    
    def eth_estimateGas(self, params):
        """
        Mengestimasi gas yang dibutuhkan untuk transaksi.
        
        Args:
            params: Parameter request
            
        Returns:
            Estimasi gas dalam format hexadecimal
        """
        tx_params = params[0]
        
        # Untuk sederhananya, kita gunakan nilai default
        # Dalam implementasi sebenarnya, ini akan menghitung gas berdasarkan operasi
        
        # Transaksi dasar: 21000 gas
        base_gas = 21000
        
        # Tambahan gas untuk data
        data = tx_params.get('data', '')
        data_gas = len(data) * 68 if data else 0
        
        total_gas = base_gas + data_gas
        
        return hex(total_gas)
    
    def eth_getTransactionCount(self, params):
        """
        Mendapatkan jumlah transaksi yang telah dikirim dari alamat.
        
        Args:
            params: Parameter request
            
        Returns:
            Jumlah transaksi dalam format hexadecimal
        """
        address = params[0]
        # block_param = params[1]  # 'latest', 'earliest', 'pending', atau nomor blok
        
        # Dapatkan nonce dari blockchain
        nonce = self.blockchain.transaction_pool.get(address, 0)
        
        return hex(nonce)
    
    def eth_getBlockByNumber(self, params):
        """
        Mendapatkan blok berdasarkan nomor.
        
        Args:
            params: Parameter request
            
        Returns:
            Data blok
        """
        block_number = int(params[0], 16) if params[0] != 'latest' else len(self.blockchain.chain) - 1
        full_tx = params[1]
        
        # Cek apakah nomor blok valid
        if block_number < 0 or block_number >= len(self.blockchain.chain):
            return None
        
        # Dapatkan blok
        block = self.blockchain.chain[block_number]
        
        # Konversi blok ke format yang sesuai
        return self.format_block(block, full_tx)
    
    def eth_getBlockByHash(self, params):
        """
        Mendapatkan blok berdasarkan hash.
        
        Args:
            params: Parameter request
            
        Returns:
            Data blok
        """
        block_hash = params[0]
        full_tx = params[1]
        
        # Cari blok dengan hash yang sesuai
        for block in self.blockchain.chain:
            if block.hash == block_hash[2:]:  # Hapus awalan '0x'
                return self.format_block(block, full_tx)
        
        return None
    
    def format_block(self, block, full_tx):
        """
        Memformat blok ke format yang sesuai dengan Ethereum.
        
        Args:
            block: Blok yang akan diformat
            full_tx: Boolean yang menunjukkan apakah transaksi lengkap atau hanya hash
            
        Returns:
            Data blok yang diformat
        """
        # Format transaksi
        transactions = []
        for tx in block.transactions:
            if full_tx:
                transactions.append({
                    'hash': f"0x{calculate_hash(tx.to_dict())}",
                    'from': tx.sender,
                    'to': tx.recipient,
                    'value': hex(tx.amount),
                    'gas': hex(tx.gas_limit),
                    'gasPrice': hex(tx.gas_price),
                    'nonce': hex(tx.nonce),
                    'input': f"0x{tx.data.encode('utf-8').hex() if tx.data else ''}"
                })
            else:
                transactions.append(f"0x{calculate_hash(tx.to_dict())}")
        
        # Format blok
        return {
            'number': hex(block.index),
            'hash': f"0x{block.hash}",
            'parentHash': f"0x{block.previous_hash}",
            'timestamp': hex(block.timestamp),
            'transactions': transactions,
            'difficulty': hex(block.difficulty),
            'nonce': hex(block.nonce)
        }
    
    def eth_blockNumber(self):
        """
        Mendapatkan nomor blok terbaru.
        
        Returns:
            Nomor blok terbaru dalam format hexadecimal
        """
        return hex(len(self.blockchain.chain) - 1)
    
    def eth_gasPrice(self):
        """
        Mendapatkan harga gas saat ini.
        
        Returns:
            Harga gas dalam format hexadecimal
        """
        # Untuk sederhananya, kita gunakan nilai default
        return '0x1'
    
    def eth_chainId(self):
        """
        Mendapatkan ID chain.
        
        Returns:
            ID chain dalam format hexadecimal
        """
        # Untuk Ghalbir, kita gunakan ID chain 1337 (untuk jaringan pengembangan)
        return '0x539'
    
    def net_version(self):
        """
        Mendapatkan versi jaringan.
        
        Returns:
            Versi jaringan
        """
        # Untuk Ghalbir, kita gunakan versi 1337 (untuk jaringan pengembangan)
        return '1337'
    
    def personal_sign(self, params):
        """
        Menandatangani pesan.
        
        Args:
            params: Parameter request
            
        Returns:
            Tanda tangan dalam format hexadecimal
        """
        data = params[0]
        address = params[1]
        # password = params[2]  # Tidak digunakan dalam implementasi ini
        
        # Cek apakah wallet ada
        if address not in self.wallets:
            raise ValueError(f"Wallet for address {address} not found")
        
        wallet = self.wallets[address]
        
        # Decode data
        if data.startswith('0x'):
            data = data[2:]
        
        data_bytes = bytes.fromhex(data)
        
        # Tandatangani data
        from ..utils.crypto_utils import sign_data
        signature = sign_data(wallet.private_key, data_bytes)
        
        return f"0x{signature}"
    
    def eth_sign(self, params):
        """
        Menandatangani data.
        
        Args:
            params: Parameter request
            
        Returns:
            Tanda tangan dalam format hexadecimal
        """
        address = params[0]
        data = params[1]
        
        # Implementasi sama dengan personal_sign
        return self.personal_sign([data, address])
    
    def eth_signTransaction(self, params):
        """
        Menandatangani transaksi tanpa mengirimkannya.
        
        Args:
            params: Parameter request
            
        Returns:
            Transaksi yang ditandatangani
        """
        tx_params = params[0]
        
        # Dapatkan parameter transaksi
        from_address = tx_params.get('from')
        to_address = tx_params.get('to')
        value = int(tx_params.get('value', '0x0'), 16)
        data = tx_params.get('data', '')
        gas_price = int(tx_params.get('gasPrice', '0x1'), 16)
        gas_limit = int(tx_params.get('gas', '0x5208'), 16)  # Default: 21000
        
        # Cek apakah wallet ada
        if from_address not in self.wallets:
            raise ValueError(f"Wallet for address {from_address} not found")
        
        wallet = self.wallets[from_address]
        
        # Buat dan tandatangani transaksi
        transaction = wallet.create_transaction(to_address, value, data, gas_price, gas_limit)
        
        # Konversi transaksi ke format yang sesuai
        from ..utils.crypto_utils import calculate_hash
        tx_hash = calculate_hash(transaction.to_dict())
        
        return {
            'raw': f"0x{tx_hash}",
            'tx': {
                'hash': f"0x{tx_hash}",
                'from': transaction.sender,
                'to': transaction.recipient,
                'value': hex(transaction.amount),
                'gas': hex(transaction.gas_limit),
                'gasPrice': hex(transaction.gas_price),
                'nonce': hex(transaction.nonce),
                'input': f"0x{transaction.data.encode('utf-8').hex() if transaction.data else ''}",
                'r': f"0x{transaction.signature[:64]}",
                's': f"0x{transaction.signature[64:128]}",
                'v': '0x1b'  # Nilai v default
            }
        }
    
    def register_wallet(self, wallet):
        """
        Mendaftarkan wallet ke API.
        
        Args:
            wallet: Objek Wallet
            
        Returns:
            Alamat wallet
        """
        self.wallets[wallet.address] = wallet
        return wallet.address
    
    def start(self, host='0.0.0.0', port=8545):
        """
        Memulai server API.
        
        Args:
            host: Host untuk menjalankan server
            port: Port untuk menjalankan server
        """
        self.app.run(host=host, port=port)
