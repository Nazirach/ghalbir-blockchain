import json
import os
import binascii
import ecdsa
from ..utils.crypto_utils import calculate_hash, generate_keypair, generate_address, sign_data, verify_signature

class Wallet:
    """
    Kelas yang merepresentasikan wallet dalam blockchain Ghalbir.
    """
    def __init__(self, private_key=None):
        """
        Inisialisasi wallet baru.
        
        Args:
            private_key: Kunci privat dalam format hexadecimal (opsional)
        """
        if private_key:
            self.private_key = private_key
            # Dapatkan kunci publik dari kunci privat
            private_key_bytes = bytes.fromhex(private_key)
            signing_key = ecdsa.SigningKey.from_string(private_key_bytes, curve=ecdsa.SECP256k1)
            verifying_key = signing_key.get_verifying_key()
            self.public_key = verifying_key.to_string().hex()
        else:
            # Buat pasangan kunci baru
            self.private_key, self.public_key = generate_keypair()
        
        # Buat alamat dari kunci publik
        self.address = generate_address(self.public_key)
    
    def sign_transaction(self, transaction):
        """
        Menandatangani transaksi.
        
        Args:
            transaction: Transaksi yang akan ditandatangani
            
        Returns:
            Transaksi yang telah ditandatangani
        """
        # Dapatkan data transaksi
        tx_data = transaction.get_transaction_data()
        
        # Tandatangani data
        signature = sign_data(self.private_key, tx_data)
        
        # Tambahkan tanda tangan ke transaksi
        transaction.signature = signature
        
        return transaction
    
    def create_transaction(self, recipient, amount, data="", gas_price=1, gas_limit=21000):
        """
        Membuat transaksi baru.
        
        Args:
            recipient: Alamat penerima
            amount: Jumlah token yang ditransfer
            data: Data tambahan (untuk smart contract)
            gas_price: Harga gas per unit
            gas_limit: Batas gas untuk transaksi
            
        Returns:
            Transaksi yang telah ditandatangani
        """
        from ..core.transaction import Transaction
        
        # Buat transaksi baru
        transaction = Transaction(self.address, recipient, amount, data, gas_price, gas_limit)
        
        # Tandatangani transaksi
        return self.sign_transaction(transaction)
    
    def export_keystore(self, password, filename=None):
        """
        Mengekspor wallet ke format keystore yang dienkripsi dengan password.
        
        Args:
            password: Password untuk enkripsi
            filename: Nama file untuk menyimpan keystore (opsional)
            
        Returns:
            Dictionary keystore atau path file jika filename diberikan
        """
        import hashlib
        import os
        import json
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import padding
        from cryptography.hazmat.backends import default_backend
        
        # Buat salt acak
        salt = os.urandom(16)
        
        # Buat kunci enkripsi dari password dan salt
        key = hashlib.scrypt(
            password.encode('utf-8'),
            salt=salt,
            n=2**14,
            r=8,
            p=1,
            dklen=32
        )
        
        # Buat IV acak
        iv = os.urandom(16)
        
        # Enkripsi kunci privat
        backend = default_backend()
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
        encryptor = cipher.encryptor()
        
        # Padding data
        padder = padding.PKCS7(128).padder()
        padded_data = padder.update(self.private_key.encode('utf-8')) + padder.finalize()
        
        # Enkripsi data
        ciphertext = encryptor.update(padded_data) + encryptor.finalize()
        
        # Buat keystore
        keystore = {
            "version": 3,
            "id": binascii.hexlify(os.urandom(16)).decode('utf-8'),
            "address": self.address[2:],  # Hapus awalan '0x'
            "crypto": {
                "ciphertext": binascii.hexlify(ciphertext).decode('utf-8'),
                "cipherparams": {
                    "iv": binascii.hexlify(iv).decode('utf-8')
                },
                "cipher": "aes-128-cbc",
                "kdf": "scrypt",
                "kdfparams": {
                    "dklen": 32,
                    "salt": binascii.hexlify(salt).decode('utf-8'),
                    "n": 2**14,
                    "r": 8,
                    "p": 1
                },
                "mac": binascii.hexlify(
                    hashlib.sha256(key[16:32] + ciphertext).digest()
                ).decode('utf-8')
            }
        }
        
        # Simpan ke file jika filename diberikan
        if filename:
            with open(filename, 'w') as f:
                json.dump(keystore, f, indent=4)
            return filename
        
        return keystore
    
    @classmethod
    def import_keystore(cls, keystore, password):
        """
        Mengimpor wallet dari keystore.
        
        Args:
            keystore: Dictionary keystore atau path file
            password: Password untuk dekripsi
            
        Returns:
            Objek Wallet
        """
        import hashlib
        import json
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import padding
        from cryptography.hazmat.backends import default_backend
        
        # Baca keystore dari file jika perlu
        if isinstance(keystore, str):
            with open(keystore, 'r') as f:
                keystore = json.load(f)
        
        # Dapatkan parameter dari keystore
        crypto = keystore["crypto"]
        kdfparams = crypto["kdfparams"]
        
        # Buat kunci dekripsi dari password dan salt
        salt = binascii.unhexlify(kdfparams["salt"])
        key = hashlib.scrypt(
            password.encode('utf-8'),
            salt=salt,
            n=kdfparams["n"],
            r=kdfparams["r"],
            p=kdfparams["p"],
            dklen=kdfparams["dklen"]
        )
        
        # Verifikasi MAC
        ciphertext = binascii.unhexlify(crypto["ciphertext"])
        mac = binascii.hexlify(
            hashlib.sha256(key[16:32] + ciphertext).digest()
        ).decode('utf-8')
        
        if mac != crypto["mac"]:
            raise ValueError("Invalid password or corrupted keystore")
        
        # Dekripsi kunci privat
        iv = binascii.unhexlify(crypto["cipherparams"]["iv"])
        backend = default_backend()
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=backend)
        decryptor = cipher.decryptor()
        
        # Dekripsi data
        decrypted_padded = decryptor.update(ciphertext) + decryptor.finalize()
        
        # Unpadding data
        unpadder = padding.PKCS7(128).unpadder()
        private_key = unpadder.update(decrypted_padded) + unpadder.finalize()
        
        # Buat wallet dari kunci privat
        return cls(private_key.decode('utf-8'))
    
    def export_private_key(self):
        """
        Mengekspor kunci privat.
        
        Returns:
            Kunci privat dalam format hexadecimal
        """
        return self.private_key
    
    @classmethod
    def import_private_key(cls, private_key):
        """
        Mengimpor wallet dari kunci privat.
        
        Args:
            private_key: Kunci privat dalam format hexadecimal
            
        Returns:
            Objek Wallet
        """
        return cls(private_key)
    
    def to_dict(self):
        """
        Mengkonversi wallet ke dictionary.
        
        Returns:
            Dictionary yang merepresentasikan wallet
        """
        return {
            "address": self.address,
            "public_key": self.public_key,
            "private_key": self.private_key
        }
    
    @classmethod
    def from_dict(cls, wallet_dict):
        """
        Membuat wallet dari dictionary.
        
        Args:
            wallet_dict: Dictionary yang merepresentasikan wallet
            
        Returns:
            Objek Wallet
        """
        return cls(wallet_dict["private_key"])
