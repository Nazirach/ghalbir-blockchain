import time
import json
import os
from .block import Block
from .transaction import Transaction
from ..utils.crypto_utils import calculate_hash, generate_keypair, generate_address

class Blockchain:
    """
    Kelas utama yang merepresentasikan blockchain Ghalbir.
    """
    def __init__(self, difficulty=4, mining_reward=50):
        """
        Inisialisasi blockchain baru.
        
        Args:
            difficulty: Tingkat kesulitan untuk proof of work
            mining_reward: Jumlah token yang diberikan sebagai reward mining
        """
        self.chain = []
        self.pending_transactions = []
        self.difficulty = difficulty
        self.mining_reward = mining_reward
        self.accounts = {}  # Menyimpan saldo akun
        self.contract_accounts = {}  # Menyimpan akun kontrak
        self.transaction_pool = {}  # Menyimpan nonce transaksi
        
        # Membuat genesis block
        self.create_genesis_block()
    
    def create_genesis_block(self):
        """
        Membuat blok genesis (blok pertama dalam blockchain).
        """
        genesis_block = Block(0, "0", int(time.time()), [], self.difficulty)
        genesis_block.hash = genesis_block.mine_block()
        self.chain.append(genesis_block)
    
    def get_latest_block(self):
        """
        Mendapatkan blok terbaru dalam blockchain.
        
        Returns:
            Blok terbaru
        """
        return self.chain[-1]
    
    def add_transaction(self, transaction):
        """
        Menambahkan transaksi ke daftar transaksi yang tertunda.
        
        Args:
            transaction: Transaksi yang akan ditambahkan
            
        Returns:
            Boolean yang menunjukkan apakah transaksi berhasil ditambahkan
        """
        # Validasi transaksi
        if not transaction.validate():
            return False
        
        # Validasi saldo pengirim
        if transaction.sender != "0x0":  # Bukan transaksi mining reward
            sender_balance = self.get_balance(transaction.sender)
            total_cost = transaction.amount + transaction.calculate_fee()
            
            if sender_balance < total_cost:
                return False
            
            # Validasi nonce
            expected_nonce = self.transaction_pool.get(transaction.sender, 0)
            if transaction.nonce != expected_nonce:
                return False
            
            # Update nonce
            self.transaction_pool[transaction.sender] = expected_nonce + 1
        
        # Tambahkan transaksi ke daftar yang tertunda
        self.pending_transactions.append(transaction)
        
        return True
    
    def mine_pending_transactions(self, miner_address):
        """
        Melakukan mining pada transaksi yang tertunda dan menambahkan blok baru ke blockchain.
        
        Args:
            miner_address: Alamat penambang yang akan menerima reward
            
        Returns:
            Blok baru yang ditambahkan
        """
        # Buat transaksi reward untuk penambang
        reward_tx = Transaction("0x0", miner_address, self.mining_reward)
        self.pending_transactions.append(reward_tx)
        
        # Buat blok baru
        block = Block(
            len(self.chain),
            self.get_latest_block().hash,
            int(time.time()),
            self.pending_transactions,
            self.difficulty
        )
        
        # Mining blok
        block.mine_block()
        
        # Tambahkan blok ke blockchain
        self.chain.append(block)
        
        # Proses transaksi
        self.process_transactions(block.transactions)
        
        # Reset daftar transaksi yang tertunda
        self.pending_transactions = []
        
        return block
    
    def process_transactions(self, transactions):
        """
        Memproses transaksi dalam blok.
        
        Args:
            transactions: Daftar transaksi yang akan diproses
        """
        for tx in transactions:
            # Kurangi saldo pengirim
            if tx.sender != "0x0":  # Bukan transaksi mining reward
                sender_balance = self.get_balance(tx.sender)
                fee = tx.calculate_fee()
                self.accounts[tx.sender] = sender_balance - tx.amount - fee
            
            # Tambah saldo penerima
            recipient_balance = self.get_balance(tx.recipient)
            self.accounts[tx.recipient] = recipient_balance + tx.amount
            
            # Proses data transaksi jika ada (untuk smart contract)
            if tx.data and tx.recipient in self.contract_accounts:
                # Implementasi eksekusi smart contract akan ditambahkan nanti
                pass
    
    def get_balance(self, address):
        """
        Mendapatkan saldo akun.
        
        Args:
            address: Alamat akun
            
        Returns:
            Saldo akun
        """
        return self.accounts.get(address, 0)
    
    def is_chain_valid(self):
        """
        Memvalidasi seluruh blockchain.
        
        Returns:
            Boolean yang menunjukkan apakah blockchain valid
        """
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i-1]
            
            # Validasi hash blok saat ini
            if not current_block.validate():
                return False
            
            # Validasi referensi ke blok sebelumnya
            if current_block.previous_hash != previous_block.hash:
                return False
        
        return True
    
    def to_dict(self):
        """
        Mengkonversi blockchain ke dictionary.
        
        Returns:
            Dictionary yang merepresentasikan blockchain
        """
        return {
            'chain': [block.to_dict() for block in self.chain],
            'pending_transactions': [tx.to_dict() for tx in self.pending_transactions],
            'difficulty': self.difficulty,
            'mining_reward': self.mining_reward,
            'accounts': self.accounts,
            'contract_accounts': self.contract_accounts,
            'transaction_pool': self.transaction_pool
        }
    
    def save_to_file(self, filename):
        """
        Menyimpan blockchain ke file.
        
        Args:
            filename: Nama file
        """
        with open(filename, 'w') as f:
            json.dump(self.to_dict(), f, indent=4)
    
    @classmethod
    def load_from_file(cls, filename):
        """
        Memuat blockchain dari file.
        
        Args:
            filename: Nama file
            
        Returns:
            Objek Blockchain
        """
        if not os.path.exists(filename):
            return cls()
        
        with open(filename, 'r') as f:
            data = json.load(f)
        
        blockchain = cls(data['difficulty'], data['mining_reward'])
        blockchain.chain = [Block.from_dict(block_dict) for block_dict in data['chain']]
        blockchain.pending_transactions = [Transaction.from_dict(tx_dict) for tx_dict in data['pending_transactions']]
        blockchain.accounts = data['accounts']
        blockchain.contract_accounts = data['contract_accounts']
        blockchain.transaction_pool = data['transaction_pool']
        
        return blockchain
