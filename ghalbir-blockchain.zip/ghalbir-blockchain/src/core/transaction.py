class Transaction:
    """
    Kelas yang merepresentasikan transaksi dalam blockchain Ghalbir.
    """
    def __init__(self, sender, recipient, amount, data="", gas_price=1, gas_limit=21000):
        """
        Inisialisasi transaksi baru.
        
        Args:
            sender: Alamat pengirim
            recipient: Alamat penerima
            amount: Jumlah token yang ditransfer
            data: Data tambahan (untuk smart contract)
            gas_price: Harga gas per unit
            gas_limit: Batas gas untuk transaksi
        """
        self.sender = sender
        self.recipient = recipient
        self.amount = amount
        self.data = data
        self.gas_price = gas_price
        self.gas_limit = gas_limit
        self.nonce = 0  # Akan diisi oleh blockchain
        self.signature = None
        
    def get_transaction_data(self):
        """
        Mendapatkan data transaksi untuk ditandatangani.
        
        Returns:
            Dictionary yang berisi data transaksi
        """
        return {
            'sender': self.sender,
            'recipient': self.recipient,
            'amount': self.amount,
            'data': self.data,
            'gas_price': self.gas_price,
            'gas_limit': self.gas_limit,
            'nonce': self.nonce
        }
    
    def sign(self, private_key):
        """
        Menandatangani transaksi dengan kunci privat.
        
        Args:
            private_key: Kunci privat pengirim
            
        Returns:
            Tanda tangan transaksi
        """
        from ..utils.crypto_utils import sign_data
        
        tx_data = self.get_transaction_data()
        self.signature = sign_data(private_key, tx_data)
        
        return self.signature
    
    def validate(self):
        """
        Memvalidasi transaksi.
        
        Returns:
            Boolean yang menunjukkan apakah transaksi valid
        """
        from ..utils.crypto_utils import verify_signature, generate_address
        
        # Transaksi harus ditandatangani
        if not self.signature:
            return False
        
        # Validasi tanda tangan
        tx_data = self.get_transaction_data()
        
        # Untuk transaksi dari alamat 0x0 (coinbase/mining reward), tidak perlu validasi tanda tangan
        if self.sender == "0x0":
            return True
        
        # Ekstrak kunci publik dari tanda tangan (implementasi sederhana)
        # Dalam implementasi sebenarnya, ini lebih kompleks
        try:
            # Verifikasi tanda tangan menggunakan alamat pengirim
            # Ini adalah penyederhanaan, dalam implementasi sebenarnya
            # kita perlu mengekstrak kunci publik dari tanda tangan
            return True
        except:
            return False
    
    def calculate_gas(self):
        """
        Menghitung total gas yang digunakan oleh transaksi.
        
        Returns:
            Total gas yang digunakan
        """
        # Implementasi sederhana
        # Transaksi dasar menggunakan 21000 gas
        base_gas = 21000
        
        # Tambahan gas untuk data
        data_gas = len(self.data) * 68 if self.data else 0
        
        total_gas = min(base_gas + data_gas, self.gas_limit)
        
        return total_gas
    
    def calculate_fee(self):
        """
        Menghitung biaya transaksi.
        
        Returns:
            Biaya transaksi dalam token
        """
        return self.calculate_gas() * self.gas_price
    
    def to_dict(self):
        """
        Mengkonversi transaksi ke dictionary.
        
        Returns:
            Dictionary yang merepresentasikan transaksi
        """
        return {
            'sender': self.sender,
            'recipient': self.recipient,
            'amount': self.amount,
            'data': self.data,
            'gas_price': self.gas_price,
            'gas_limit': self.gas_limit,
            'nonce': self.nonce,
            'signature': self.signature
        }
    
    @classmethod
    def from_dict(cls, tx_dict):
        """
        Membuat transaksi dari dictionary.
        
        Args:
            tx_dict: Dictionary yang merepresentasikan transaksi
            
        Returns:
            Objek Transaction
        """
        tx = cls(
            tx_dict['sender'],
            tx_dict['recipient'],
            tx_dict['amount'],
            tx_dict['data'],
            tx_dict['gas_price'],
            tx_dict['gas_limit']
        )
        
        tx.nonce = tx_dict['nonce']
        tx.signature = tx_dict['signature']
        
        return tx
