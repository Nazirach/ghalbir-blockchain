class Block:
    """
    Kelas yang merepresentasikan blok dalam blockchain Ghalbir.
    """
    def __init__(self, index, previous_hash, timestamp, transactions, difficulty=4):
        """
        Inisialisasi blok baru.
        
        Args:
            index: Indeks blok dalam blockchain
            previous_hash: Hash dari blok sebelumnya
            timestamp: Waktu pembuatan blok
            transactions: Daftar transaksi dalam blok
            difficulty: Tingkat kesulitan untuk proof of work
        """
        self.index = index
        self.previous_hash = previous_hash
        self.timestamp = timestamp
        self.transactions = transactions
        self.difficulty = difficulty
        self.nonce = 0
        self.hash = None
        
    def get_header(self):
        """
        Mendapatkan header blok untuk proses mining.
        
        Returns:
            Dictionary yang berisi header blok
        """
        return {
            'index': self.index,
            'previous_hash': self.previous_hash,
            'timestamp': self.timestamp,
            'merkle_root': self.calculate_merkle_root(),
            'difficulty': self.difficulty,
            'nonce': self.nonce
        }
    
    def calculate_merkle_root(self):
        """
        Menghitung Merkle root dari transaksi dalam blok.
        
        Returns:
            Hash Merkle root
        """
        from ..utils.crypto_utils import calculate_hash
        
        if not self.transactions:
            return calculate_hash("")
        
        # Implementasi sederhana dari Merkle tree
        transaction_hashes = [calculate_hash(tx) for tx in self.transactions]
        
        while len(transaction_hashes) > 1:
            if len(transaction_hashes) % 2 != 0:
                transaction_hashes.append(transaction_hashes[-1])
                
            next_level = []
            for i in range(0, len(transaction_hashes), 2):
                combined = transaction_hashes[i] + transaction_hashes[i+1]
                next_level.append(calculate_hash(combined))
                
            transaction_hashes = next_level
            
        return transaction_hashes[0]
    
    def mine_block(self):
        """
        Melakukan proses mining pada blok.
        
        Returns:
            Hash dari blok yang berhasil di-mining
        """
        from ..utils.crypto_utils import proof_of_work
        
        header = self.get_header()
        self.nonce, self.hash = proof_of_work(header, self.difficulty)
        
        return self.hash
    
    def validate(self):
        """
        Memvalidasi blok.
        
        Returns:
            Boolean yang menunjukkan apakah blok valid
        """
        from ..utils.crypto_utils import calculate_hash
        
        # Validasi hash
        header = self.get_header()
        calculated_hash = calculate_hash(header)
        
        if calculated_hash != self.hash:
            return False
        
        # Validasi proof of work
        if not self.hash.startswith('0' * self.difficulty):
            return False
        
        # Validasi transaksi
        for tx in self.transactions:
            if not tx.validate():
                return False
                
        return True
    
    def to_dict(self):
        """
        Mengkonversi blok ke dictionary.
        
        Returns:
            Dictionary yang merepresentasikan blok
        """
        return {
            'index': self.index,
            'previous_hash': self.previous_hash,
            'timestamp': self.timestamp,
            'transactions': [tx.to_dict() for tx in self.transactions],
            'difficulty': self.difficulty,
            'nonce': self.nonce,
            'hash': self.hash
        }
    
    @classmethod
    def from_dict(cls, block_dict):
        """
        Membuat blok dari dictionary.
        
        Args:
            block_dict: Dictionary yang merepresentasikan blok
            
        Returns:
            Objek Block
        """
        from .transaction import Transaction
        
        block = cls(
            block_dict['index'],
            block_dict['previous_hash'],
            block_dict['timestamp'],
            [Transaction.from_dict(tx) for tx in block_dict['transactions']],
            block_dict['difficulty']
        )
        
        block.nonce = block_dict['nonce']
        block.hash = block_dict['hash']
        
        return block
