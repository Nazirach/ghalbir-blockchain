class ContractCompiler:
    """
    Kelas yang merepresentasikan compiler untuk bahasa kontrak sederhana Ghalbir.
    """
    def __init__(self):
        """
        Inisialisasi compiler baru.
        """
        self.errors = []
    
    def compile(self, source_code):
        """
        Mengkompilasi kode sumber kontrak ke format yang dapat dieksekusi oleh VM.
        
        Args:
            source_code: Kode sumber kontrak dalam format string
            
        Returns:
            Kode kontrak yang dikompilasi dalam format dictionary
        """
        self.errors = []
        
        try:
            # Parse kode sumber
            parsed_code = self.parse(source_code)
            
            # Validasi kode
            if not self.validate(parsed_code):
                return {"error": "Validation failed", "details": self.errors}
            
            # Kompilasi kode
            compiled_code = self.compile_parsed_code(parsed_code)
            
            return compiled_code
        except Exception as e:
            self.errors.append(str(e))
            return {"error": "Compilation failed", "details": self.errors}
    
    def parse(self, source_code):
        """
        Mem-parsing kode sumber kontrak.
        
        Args:
            source_code: Kode sumber kontrak dalam format string
            
        Returns:
            Kode yang di-parse dalam format dictionary
        """
        # Implementasi sederhana untuk bahasa kontrak
        # Format:
        # contract {
        #   function name(param1, param2) {
        #     // statements
        #   }
        # }
        
        lines = source_code.strip().split('\n')
        contract_name = None
        functions = {}
        current_function = None
        function_body = []
        
        for line in lines:
            line = line.strip()
            
            if not line or line.startswith('//'):
                continue
            
            if line.startswith('contract '):
                # Parse nama kontrak
                contract_name = line[9:].split('{')[0].strip()
            
            elif line.startswith('function '):
                # Parse deklarasi fungsi
                if current_function:
                    # Simpan fungsi sebelumnya
                    functions[current_function['name']] = {
                        'params': current_function['params'],
                        'body': function_body
                    }
                
                # Parse nama fungsi dan parameter
                function_decl = line[9:].split('{')[0].strip()
                function_name = function_decl.split('(')[0].strip()
                params_str = function_decl.split('(')[1].split(')')[0].strip()
                params = [p.strip() for p in params_str.split(',')] if params_str else []
                
                current_function = {
                    'name': function_name,
                    'params': params
                }
                function_body = []
            
            elif line == '}' and current_function:
                # Akhir fungsi
                functions[current_function['name']] = {
                    'params': current_function['params'],
                    'body': function_body
                }
                current_function = None
                function_body = []
            
            elif current_function:
                # Baris kode dalam fungsi
                function_body.append(line)
        
        # Simpan fungsi terakhir jika ada
        if current_function:
            functions[current_function['name']] = {
                'params': current_function['params'],
                'body': function_body
            }
        
        return {
            'name': contract_name,
            'functions': functions
        }
    
    def validate(self, parsed_code):
        """
        Memvalidasi kode yang di-parse.
        
        Args:
            parsed_code: Kode yang di-parse dalam format dictionary
            
        Returns:
            Boolean yang menunjukkan apakah kode valid
        """
        # Validasi nama kontrak
        if not parsed_code.get('name'):
            self.errors.append("Contract name is required")
            return False
        
        # Validasi fungsi
        if not parsed_code.get('functions'):
            self.errors.append("Contract must have at least one function")
            return False
        
        # Validasi setiap fungsi
        for func_name, func_data in parsed_code['functions'].items():
            # Validasi nama fungsi
            if not func_name:
                self.errors.append("Function name is required")
                return False
            
            # Validasi parameter
            for param in func_data['params']:
                if not param:
                    self.errors.append(f"Invalid parameter in function {func_name}")
                    return False
        
        return True
    
    def compile_parsed_code(self, parsed_code):
        """
        Mengkompilasi kode yang di-parse ke format yang dapat dieksekusi oleh VM.
        
        Args:
            parsed_code: Kode yang di-parse dalam format dictionary
            
        Returns:
            Kode kontrak yang dikompilasi dalam format dictionary
        """
        compiled_code = {}
        
        for func_name, func_data in parsed_code['functions'].items():
            compiled_func = self.compile_function(func_name, func_data)
            compiled_code[func_name] = compiled_func
        
        return compiled_code
    
    def compile_function(self, func_name, func_data):
        """
        Mengkompilasi fungsi.
        
        Args:
            func_name: Nama fungsi
            func_data: Data fungsi
            
        Returns:
            Fungsi yang dikompilasi dalam format dictionary
        """
        body = func_data['body']
        
        # Implementasi sederhana untuk kompilasi fungsi
        # Hanya mendukung beberapa operasi dasar
        
        # Cek apakah fungsi hanya berisi satu operasi
        if len(body) == 1:
            return self.compile_statement(body[0])
        
        # Jika fungsi berisi beberapa operasi, kompilasi sebagai sequence
        compiled_statements = []
        for statement in body:
            compiled_statement = self.compile_statement(statement)
            compiled_statements.append(compiled_statement)
        
        return {
            "type": "sequence",
            "statements": compiled_statements
        }
    
    def compile_statement(self, statement):
        """
        Mengkompilasi statement.
        
        Args:
            statement: Statement yang akan dikompilasi
            
        Returns:
            Statement yang dikompilasi dalam format dictionary
        """
        statement = statement.strip()
        
        # Transfer token
        if statement.startswith('transfer('):
            # Format: transfer(to, amount)
            params_str = statement[9:-1].strip()
            params = [p.strip() for p in params_str.split(',')]
            
            if len(params) != 2:
                self.errors.append(f"Invalid transfer statement: {statement}")
                return {"type": "error", "message": f"Invalid transfer statement: {statement}"}
            
            return {
                "type": "transfer",
                "to": {"type": "param", "key": params[0]},
                "amount": {"type": "param", "key": params[1]}
            }
        
        # Store value
        elif statement.startswith('store('):
            # Format: store(key, value)
            params_str = statement[6:-1].strip()
            params = [p.strip() for p in params_str.split(',')]
            
            if len(params) != 2:
                self.errors.append(f"Invalid store statement: {statement}")
                return {"type": "error", "message": f"Invalid store statement: {statement}"}
            
            return {
                "type": "store",
                "key": params[0],
                "value": {"type": "param", "key": params[1]}
            }
        
        # Get value
        elif statement.startswith('get('):
            # Format: get(key)
            key = statement[4:-1].strip()
            
            return {
                "type": "get",
                "key": key
            }
        
        # Conditional
        elif statement.startswith('if('):
            # Format: if(condition) { statement } else { statement }
            condition_str = statement.split(')')[0][3:].strip()
            then_else = statement.split(')')[1].strip()
            
            # Parse condition
            condition = self.compile_condition(condition_str)
            
            # Parse then and else blocks
            then_block = then_else.split('else')[0].strip()
            then_statement = then_block[1:-1].strip()  # Remove { }
            
            else_block = then_else.split('else')[1].strip()
            else_statement = else_block[1:-1].strip()  # Remove { }
            
            return {
                "type": "conditional",
                "condition": condition,
                "if_true": self.compile_statement(then_statement),
                "if_false": self.compile_statement(else_statement)
            }
        
        # Unknown statement
        else:
            self.errors.append(f"Unknown statement: {statement}")
            return {"type": "error", "message": f"Unknown statement: {statement}"}
    
    def compile_condition(self, condition_str):
        """
        Mengkompilasi kondisi.
        
        Args:
            condition_str: String kondisi
            
        Returns:
            Kondisi yang dikompilasi dalam format dictionary
        """
        # Equal
        if '==' in condition_str:
            left, right = condition_str.split('==')
            return {
                "type": "eq",
                "left": self.compile_value(left.strip()),
                "right": self.compile_value(right.strip())
            }
        
        # Greater than
        elif '>' in condition_str:
            left, right = condition_str.split('>')
            return {
                "type": "gt",
                "left": self.compile_value(left.strip()),
                "right": self.compile_value(right.strip())
            }
        
        # Less than
        elif '<' in condition_str:
            left, right = condition_str.split('<')
            return {
                "type": "lt",
                "left": self.compile_value(left.strip()),
                "right": self.compile_value(right.strip())
            }
        
        # AND
        elif '&&' in condition_str:
            left, right = condition_str.split('&&')
            return {
                "type": "and",
                "left": self.compile_condition(left.strip()),
                "right": self.compile_condition(right.strip())
            }
        
        # OR
        elif '||' in condition_str:
            left, right = condition_str.split('||')
            return {
                "type": "or",
                "left": self.compile_condition(left.strip()),
                "right": self.compile_condition(right.strip())
            }
        
        # Unknown condition
        else:
            self.errors.append(f"Unknown condition: {condition_str}")
            return {"type": "error", "message": f"Unknown condition: {condition_str}"}
    
    def compile_value(self, value_str):
        """
        Mengkompilasi nilai.
        
        Args:
            value_str: String nilai
            
        Returns:
            Nilai yang dikompilasi
        """
        value_str = value_str.strip()
        
        # Storage value
        if value_str.startswith('storage.'):
            key = value_str[8:]
            return {"type": "storage", "key": key}
        
        # Parameter value
        elif value_str.startswith('params.'):
            key = value_str[7:]
            return {"type": "param", "key": key}
        
        # Sender
        elif value_str == 'sender':
            return {"type": "sender"}
        
        # Value
        elif value_str == 'value':
            return {"type": "value"}
        
        # Balance
        elif value_str == 'balance':
            return {"type": "balance"}
        
        # Owner
        elif value_str == 'owner':
            return {"type": "owner"}
        
        # Number
        elif value_str.isdigit():
            return int(value_str)
        
        # String
        elif value_str.startswith('"') and value_str.endswith('"'):
            return value_str[1:-1]
        
        # Unknown value
        else:
            return value_str
