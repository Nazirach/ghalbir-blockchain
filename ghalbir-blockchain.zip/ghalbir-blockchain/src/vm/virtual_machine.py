class VirtualMachine:
    """
    Kelas yang merepresentasikan mesin virtual untuk mengeksekusi smart contract dalam blockchain Ghalbir.
    """
    def __init__(self, blockchain):
        """
        Inisialisasi mesin virtual baru.
        
        Args:
            blockchain: Objek blockchain yang terkait dengan VM
        """
        self.blockchain = blockchain
        self.contracts = {}  # Menyimpan kontrak yang telah di-deploy
        self.gas_used = 0  # Menyimpan jumlah gas yang digunakan
        self.gas_limit = 0  # Batas gas untuk eksekusi saat ini
        self.gas_price = 0  # Harga gas untuk eksekusi saat ini
    
    def deploy_contract(self, code, sender, gas_limit=1000000, gas_price=1):
        """
        Men-deploy kontrak baru ke blockchain.
        
        Args:
            code: Kode kontrak
            sender: Alamat pengirim (pemilik kontrak)
            gas_limit: Batas gas untuk deployment
            gas_price: Harga gas untuk deployment
            
        Returns:
            Alamat kontrak yang di-deploy
        """
        from ..utils.crypto_utils import calculate_hash, generate_address
        from .contract import Contract
        
        # Reset gas yang digunakan
        self.gas_used = 0
        self.gas_limit = gas_limit
        self.gas_price = gas_price
        
        # Validasi kode kontrak
        if not self.validate_contract_code(code):
            return {"error": "Invalid contract code"}
        
        # Hitung alamat kontrak
        # Dalam Ethereum, alamat kontrak dihitung dari alamat pengirim dan nonce
        # Untuk sederhananya, kita gunakan hash dari kode dan timestamp
        import time
        contract_data = {
            "code": code,
            "sender": sender,
            "timestamp": int(time.time())
        }
        
        contract_hash = calculate_hash(contract_data)
        contract_address = "0x" + contract_hash[-40:]  # Ambil 20 byte terakhir seperti Ethereum
        
        # Buat kontrak baru
        contract = Contract(contract_address, code, sender)
        
        # Simpan kontrak
        self.contracts[contract_address] = contract
        
        # Hitung gas yang digunakan
        # Dalam implementasi sebenarnya, ini akan lebih kompleks
        self.gas_used = len(str(code)) * 100  # Estimasi sederhana
        
        if self.gas_used > self.gas_limit:
            return {"error": "Out of gas"}
        
        # Hitung biaya deployment
        deployment_cost = self.gas_used * self.gas_price
        
        # Kurangi saldo pengirim
        sender_balance = self.blockchain.get_balance(sender)
        if sender_balance < deployment_cost:
            return {"error": "Insufficient balance"}
        
        self.blockchain.accounts[sender] = sender_balance - deployment_cost
        
        # Tambahkan kontrak ke daftar akun kontrak blockchain
        self.blockchain.contract_accounts[contract_address] = True
        
        return {
            "success": True,
            "contract_address": contract_address,
            "gas_used": self.gas_used,
            "cost": deployment_cost
        }
    
    def call_contract(self, contract_address, method, params, sender, value=0, gas_limit=1000000, gas_price=1):
        """
        Memanggil metode kontrak.
        
        Args:
            contract_address: Alamat kontrak
            method: Nama metode yang akan dipanggil
            params: Parameter untuk metode
            sender: Alamat pengirim
            value: Nilai token yang dikirim ke kontrak
            gas_limit: Batas gas untuk eksekusi
            gas_price: Harga gas untuk eksekusi
            
        Returns:
            Hasil eksekusi metode
        """
        # Reset gas yang digunakan
        self.gas_used = 0
        self.gas_limit = gas_limit
        self.gas_price = gas_price
        
        # Cek apakah kontrak ada
        if contract_address not in self.contracts:
            return {"error": "Contract not found"}
        
        contract = self.contracts[contract_address]
        
        # Cek saldo pengirim jika ada nilai yang dikirim
        if value > 0:
            sender_balance = self.blockchain.get_balance(sender)
            if sender_balance < value:
                return {"error": "Insufficient balance for value transfer"}
        
        # Eksekusi metode kontrak
        result = contract.execute(method, params, sender, value)
        
        # Hitung gas yang digunakan
        # Dalam implementasi sebenarnya, ini akan lebih kompleks
        self.gas_used = 21000  # Gas dasar
        self.gas_used += len(str(params)) * 50  # Gas untuk parameter
        
        if isinstance(result, dict) and "error" in result:
            # Jika ada error, tetap gunakan gas dasar
            pass
        else:
            # Tambahkan gas untuk eksekusi yang berhasil
            self.gas_used += len(str(result)) * 50
        
        if self.gas_used > self.gas_limit:
            return {"error": "Out of gas"}
        
        # Hitung biaya eksekusi
        execution_cost = self.gas_used * self.gas_price
        
        # Kurangi saldo pengirim
        sender_balance = self.blockchain.get_balance(sender)
        if sender_balance < execution_cost + value:
            return {"error": "Insufficient balance"}
        
        self.blockchain.accounts[sender] = sender_balance - execution_cost - value
        
        # Jika ada nilai yang dikirim, tambahkan ke saldo kontrak
        if value > 0:
            contract.balance += value
        
        return {
            "success": True,
            "result": result,
            "gas_used": self.gas_used,
            "cost": execution_cost
        }
    
    def validate_contract_code(self, code):
        """
        Memvalidasi kode kontrak.
        
        Args:
            code: Kode kontrak
            
        Returns:
            Boolean yang menunjukkan apakah kode valid
        """
        # Implementasi sederhana untuk validasi kode
        # Dalam implementasi sebenarnya, ini akan lebih kompleks
        
        # Cek apakah kode adalah dictionary
        if not isinstance(code, dict):
            return False
        
        # Cek apakah kode memiliki metode
        for method_name, method_code in code.items():
            if not isinstance(method_code, dict):
                return False
            
            if "type" not in method_code:
                return False
        
        return True
    
    def get_contract(self, address):
        """
        Mendapatkan kontrak berdasarkan alamat.
        
        Args:
            address: Alamat kontrak
            
        Returns:
            Objek Contract
        """
        return self.contracts.get(address)
    
    def to_dict(self):
        """
        Mengkonversi VM ke dictionary.
        
        Returns:
            Dictionary yang merepresentasikan VM
        """
        return {
            "contracts": {addr: contract.to_dict() for addr, contract in self.contracts.items()}
        }
    
    @classmethod
    def from_dict(cls, vm_dict, blockchain):
        """
        Membuat VM dari dictionary.
        
        Args:
            vm_dict: Dictionary yang merepresentasikan VM
            blockchain: Objek blockchain yang terkait dengan VM
            
        Returns:
            Objek VirtualMachine
        """
        from .contract import Contract
        
        vm = cls(blockchain)
        
        contracts_dict = vm_dict.get("contracts", {})
        for addr, contract_dict in contracts_dict.items():
            vm.contracts[addr] = Contract.from_dict(contract_dict)
        
        return vm
