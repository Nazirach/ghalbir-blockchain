class Contract:
    """
    Kelas yang merepresentasikan smart contract dalam blockchain Ghalbir.
    """
    def __init__(self, address, code, owner):
        """
        Inisialisasi smart contract baru.
        
        Args:
            address: Alamat kontrak
            code: Kode kontrak
            owner: Alamat pemilik kontrak
        """
        self.address = address
        self.code = code
        self.owner = owner
        self.storage = {}  # Penyimpanan kontrak
        self.balance = 0  # Saldo kontrak
    
    def execute(self, method, params, sender, value=0):
        """
        Mengeksekusi metode kontrak.
        
        Args:
            method: Nama metode yang akan dieksekusi
            params: Parameter untuk metode
            sender: Alamat pengirim
            value: Nilai token yang dikirim ke kontrak
            
        Returns:
            Hasil eksekusi metode
        """
        # Tambahkan nilai ke saldo kontrak
        self.balance += value
        
        # Eksekusi metode
        try:
            # Dalam implementasi sebenarnya, ini akan menggunakan VM untuk mengeksekusi kode
            # Untuk saat ini, kita menggunakan pendekatan sederhana
            if method in self.code:
                # Eksekusi kode metode
                result = self.execute_code(self.code[method], params, sender, value)
                return result
            else:
                return {"error": "Method not found"}
        except Exception as e:
            return {"error": str(e)}
    
    def execute_code(self, code, params, sender, value):
        """
        Mengeksekusi kode kontrak.
        
        Args:
            code: Kode yang akan dieksekusi
            params: Parameter untuk kode
            sender: Alamat pengirim
            value: Nilai token yang dikirim ke kontrak
            
        Returns:
            Hasil eksekusi kode
        """
        # Buat konteks eksekusi
        context = {
            "storage": self.storage,
            "sender": sender,
            "value": value,
            "params": params,
            "balance": self.balance,
            "address": self.address,
            "owner": self.owner
        }
        
        # Dalam implementasi sebenarnya, ini akan menggunakan VM untuk mengeksekusi kode
        # Untuk saat ini, kita menggunakan pendekatan sederhana dengan evaluasi kode
        # CATATAN: Ini hanya untuk demonstrasi dan tidak aman untuk produksi
        
        # Implementasi sederhana untuk operasi dasar
        if code["type"] == "transfer":
            # Transfer token ke alamat tertentu
            to_address = params.get("to")
            amount = params.get("amount", 0)
            
            if amount > self.balance:
                return {"error": "Insufficient balance"}
            
            # Dalam implementasi sebenarnya, ini akan memanggil fungsi transfer blockchain
            self.balance -= amount
            
            return {"success": True, "transferred": amount, "to": to_address}
        
        elif code["type"] == "store":
            # Simpan nilai ke storage
            key = params.get("key")
            value = params.get("value")
            
            if key:
                self.storage[key] = value
                return {"success": True, "stored": {key: value}}
            else:
                return {"error": "Key not provided"}
        
        elif code["type"] == "get":
            # Ambil nilai dari storage
            key = params.get("key")
            
            if key in self.storage:
                return {"success": True, "value": self.storage[key]}
            else:
                return {"error": "Key not found"}
        
        elif code["type"] == "conditional":
            # Eksekusi kondisional
            condition = code.get("condition")
            if_true = code.get("if_true")
            if_false = code.get("if_false")
            
            # Evaluasi kondisi
            condition_result = self.evaluate_condition(condition, context)
            
            if condition_result:
                return self.execute_code(if_true, params, sender, value)
            else:
                return self.execute_code(if_false, params, sender, value)
        
        return {"error": "Unknown code type"}
    
    def evaluate_condition(self, condition, context):
        """
        Mengevaluasi kondisi.
        
        Args:
            condition: Kondisi yang akan dievaluasi
            context: Konteks eksekusi
            
        Returns:
            Boolean hasil evaluasi
        """
        # Implementasi sederhana untuk evaluasi kondisi
        if condition["type"] == "eq":
            left = self.get_value(condition["left"], context)
            right = self.get_value(condition["right"], context)
            return left == right
        
        elif condition["type"] == "gt":
            left = self.get_value(condition["left"], context)
            right = self.get_value(condition["right"], context)
            return left > right
        
        elif condition["type"] == "lt":
            left = self.get_value(condition["left"], context)
            right = self.get_value(condition["right"], context)
            return left < right
        
        elif condition["type"] == "and":
            left = self.evaluate_condition(condition["left"], context)
            right = self.evaluate_condition(condition["right"], context)
            return left and right
        
        elif condition["type"] == "or":
            left = self.evaluate_condition(condition["left"], context)
            right = self.evaluate_condition(condition["right"], context)
            return left or right
        
        return False
    
    def get_value(self, value_expr, context):
        """
        Mendapatkan nilai dari ekspresi.
        
        Args:
            value_expr: Ekspresi nilai
            context: Konteks eksekusi
            
        Returns:
            Nilai hasil evaluasi
        """
        if isinstance(value_expr, dict):
            if value_expr["type"] == "storage":
                key = value_expr["key"]
                return context["storage"].get(key)
            
            elif value_expr["type"] == "param":
                key = value_expr["key"]
                return context["params"].get(key)
            
            elif value_expr["type"] == "sender":
                return context["sender"]
            
            elif value_expr["type"] == "value":
                return context["value"]
            
            elif value_expr["type"] == "balance":
                return context["balance"]
            
            elif value_expr["type"] == "owner":
                return context["owner"]
        
        # Nilai literal
        return value_expr
    
    def to_dict(self):
        """
        Mengkonversi kontrak ke dictionary.
        
        Returns:
            Dictionary yang merepresentasikan kontrak
        """
        return {
            "address": self.address,
            "code": self.code,
            "owner": self.owner,
            "storage": self.storage,
            "balance": self.balance
        }
    
    @classmethod
    def from_dict(cls, contract_dict):
        """
        Membuat kontrak dari dictionary.
        
        Args:
            contract_dict: Dictionary yang merepresentasikan kontrak
            
        Returns:
            Objek Contract
        """
        contract = cls(
            contract_dict["address"],
            contract_dict["code"],
            contract_dict["owner"]
        )
        
        contract.storage = contract_dict["storage"]
        contract.balance = contract_dict["balance"]
        
        return contract
