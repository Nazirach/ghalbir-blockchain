import socket
import threading
import json
import time
from ..core.blockchain import Blockchain
from ..core.transaction import Transaction
from ..utils.crypto_utils import calculate_hash

class Node:
    """
    Kelas yang merepresentasikan node dalam jaringan blockchain Ghalbir.
    """
    def __init__(self, host='0.0.0.0', port=5000):
        """
        Inisialisasi node baru.
        
        Args:
            host: Host untuk menjalankan node
            port: Port untuk menjalankan node
        """
        self.host = host
        self.port = port
        self.blockchain = Blockchain()
        self.peers = set()  # Daftar peer dalam jaringan
        self.running = False
    
    def start(self):
        """
        Memulai node.
        """
        self.running = True
        
        # Mulai server
        server_thread = threading.Thread(target=self.run_server)
        server_thread.daemon = True
        server_thread.start()
        
        # Mulai sinkronisasi dengan peer
        sync_thread = threading.Thread(target=self.sync_with_peers)
        sync_thread.daemon = True
        sync_thread.start()
        
        print(f"Node started on {self.host}:{self.port}")
    
    def stop(self):
        """
        Menghentikan node.
        """
        self.running = False
        print("Node stopped")
    
    def run_server(self):
        """
        Menjalankan server untuk menerima koneksi dari peer.
        """
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((self.host, self.port))
        server.listen(5)
        
        while self.running:
            try:
                client, address = server.accept()
                client_thread = threading.Thread(target=self.handle_client, args=(client,))
                client_thread.daemon = True
                client_thread.start()
            except:
                pass
        
        server.close()
    
    def handle_client(self, client):
        """
        Menangani koneksi dari client.
        
        Args:
            client: Socket client
        """
        try:
            # Terima data dari client
            data = client.recv(4096)
            if data:
                message = json.loads(data.decode('utf-8'))
                response = self.process_message(message)
                
                # Kirim respons ke client
                client.send(json.dumps(response).encode('utf-8'))
        except:
            pass
        finally:
            client.close()
    
    def process_message(self, message):
        """
        Memproses pesan dari peer.
        
        Args:
            message: Pesan yang diterima
            
        Returns:
            Respons untuk peer
        """
        message_type = message.get('type')
        
        if message_type == 'get_chain':
            # Kirim blockchain ke peer
            return {
                'type': 'chain',
                'chain': self.blockchain.to_dict()
            }
        
        elif message_type == 'chain':
            # Terima blockchain dari peer
            chain_dict = message.get('chain')
            self.replace_chain(chain_dict)
            return {'type': 'ack'}
        
        elif message_type == 'transaction':
            # Terima transaksi dari peer
            tx_dict = message.get('transaction')
            tx = Transaction.from_dict(tx_dict)
            
            if self.blockchain.add_transaction(tx):
                return {'type': 'ack', 'status': 'success'}
            else:
                return {'type': 'ack', 'status': 'failed'}
        
        elif message_type == 'block':
            # Terima blok dari peer
            block_dict = message.get('block')
            # Implementasi validasi dan penambahan blok
            return {'type': 'ack'}
        
        elif message_type == 'get_peers':
            # Kirim daftar peer ke peer
            return {
                'type': 'peers',
                'peers': list(self.peers)
            }
        
        elif message_type == 'peers':
            # Terima daftar peer dari peer
            new_peers = message.get('peers', [])
            for peer in new_peers:
                self.add_peer(peer)
            return {'type': 'ack'}
        
        return {'type': 'error', 'message': 'Unknown message type'}
    
    def add_peer(self, peer):
        """
        Menambahkan peer ke daftar peer.
        
        Args:
            peer: Alamat peer (host:port)
        """
        if peer not in self.peers and peer != f"{self.host}:{self.port}":
            self.peers.add(peer)
    
    def broadcast(self, message):
        """
        Menyebarkan pesan ke semua peer.
        
        Args:
            message: Pesan yang akan disebarkan
        """
        for peer in self.peers:
            try:
                host, port = peer.split(':')
                self.send_to_peer(host, int(port), message)
            except:
                pass
    
    def send_to_peer(self, host, port, message):
        """
        Mengirim pesan ke peer tertentu.
        
        Args:
            host: Host peer
            port: Port peer
            message: Pesan yang akan dikirim
            
        Returns:
            Respons dari peer
        """
        try:
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.connect((host, port))
            client.send(json.dumps(message).encode('utf-8'))
            
            # Terima respons
            response = client.recv(4096)
            client.close()
            
            if response:
                return json.loads(response.decode('utf-8'))
        except:
            pass
        
        return None
    
    def sync_with_peers(self):
        """
        Melakukan sinkronisasi dengan peer secara berkala.
        """
        while self.running:
            for peer in self.peers:
                try:
                    host, port = peer.split(':')
                    
                    # Dapatkan blockchain dari peer
                    response = self.send_to_peer(host, int(port), {'type': 'get_chain'})
                    
                    if response and response.get('type') == 'chain':
                        chain_dict = response.get('chain')
                        self.replace_chain(chain_dict)
                    
                    # Dapatkan daftar peer dari peer
                    response = self.send_to_peer(host, int(port), {'type': 'get_peers'})
                    
                    if response and response.get('type') == 'peers':
                        new_peers = response.get('peers', [])
                        for new_peer in new_peers:
                            self.add_peer(new_peer)
                except:
                    pass
            
            # Tunggu sebelum sinkronisasi berikutnya
            time.sleep(60)
    
    def replace_chain(self, chain_dict):
        """
        Mengganti blockchain lokal dengan blockchain yang lebih panjang dan valid.
        
        Args:
            chain_dict: Dictionary yang merepresentasikan blockchain
        """
        # Implementasi sederhana, dalam implementasi sebenarnya perlu validasi lebih lanjut
        new_blockchain = Blockchain.from_dict(chain_dict)
        
        if len(new_blockchain.chain) > len(self.blockchain.chain) and new_blockchain.is_chain_valid():
            self.blockchain = new_blockchain
    
    def broadcast_transaction(self, transaction):
        """
        Menyebarkan transaksi ke semua peer.
        
        Args:
            transaction: Transaksi yang akan disebarkan
        """
        message = {
            'type': 'transaction',
            'transaction': transaction.to_dict()
        }
        
        self.broadcast(message)
    
    def broadcast_block(self, block):
        """
        Menyebarkan blok ke semua peer.
        
        Args:
            block: Blok yang akan disebarkan
        """
        message = {
            'type': 'block',
            'block': block.to_dict()
        }
        
        self.broadcast(message)
