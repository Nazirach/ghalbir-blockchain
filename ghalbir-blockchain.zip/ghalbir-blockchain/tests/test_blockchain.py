import unittest
import time
import json
import os
from src.utils.crypto_utils import calculate_hash, generate_keypair, generate_address, sign_data, verify_signature
from src.core.block import Block
from src.core.transaction import Transaction
from src.core.blockchain import Blockchain
from src.vm.contract import Contract
from src.vm.virtual_machine import VirtualMachine
from src.vm.compiler import ContractCompiler
from src.wallet.wallet import Wallet

class TestGhalbirBlockchain(unittest.TestCase):
    def setUp(self):
        # Inisialisasi blockchain untuk pengujian
        self.blockchain = Blockchain(difficulty=2)  # Difficulty rendah untuk pengujian cepat
        self.wallet1 = Wallet()
        self.wallet2 = Wallet()
        
        # Tambahkan saldo ke wallet1 untuk pengujian
        self.blockchain.accounts[self.wallet1.address] = 1000
        
        # Inisialisasi VM
        self.vm = VirtualMachine(self.blockchain)
        
        # Inisialisasi compiler
        self.compiler = ContractCompiler()
    
    def test_block_creation(self):
        """Pengujian pembuatan blok"""
        # Buat blok baru
        block = Block(1, self.blockchain.get_latest_block().hash, int(time.time()), [], 2)
        
        # Mine blok
        block_hash = block.mine_block()
        
        # Verifikasi hash blok dimulai dengan '00' (difficulty=2)
        self.assertTrue(block_hash.startswith('00'))
        
        # Verifikasi blok valid
        self.assertTrue(block.validate())
    
    def test_transaction_creation(self):
        """Pengujian pembuatan dan validasi transaksi"""
        # Buat transaksi
        tx = Transaction(self.wallet1.address, self.wallet2.address, 100)
        
        # Tandatangani transaksi
        tx = self.wallet1.sign_transaction(tx)
        
        # Verifikasi transaksi valid
        self.assertTrue(tx.validate())
        
        # Tambahkan transaksi ke blockchain
        result = self.blockchain.add_transaction(tx)
        self.assertTrue(result)
        
        # Verifikasi transaksi ada dalam daftar transaksi tertunda
        self.assertIn(tx, self.blockchain.pending_transactions)
    
    def test_mining(self):
        """Pengujian proses mining"""
        # Buat dan tambahkan beberapa transaksi
        tx1 = self.wallet1.create_transaction(self.wallet2.address, 50)
        tx2 = self.wallet1.create_transaction(self.wallet2.address, 30)
        
        self.blockchain.add_transaction(tx1)
        self.blockchain.add_transaction(tx2)
        
        # Dapatkan jumlah blok sebelum mining
        block_count_before = len(self.blockchain.chain)
        
        # Mine transaksi tertunda
        new_block = self.blockchain.mine_pending_transactions(self.wallet2.address)
        
        # Verifikasi blok baru ditambahkan ke blockchain
        self.assertEqual(len(self.blockchain.chain), block_count_before + 1)
        
        # Verifikasi transaksi tertunda telah diproses
        self.assertEqual(len(self.blockchain.pending_transactions), 0)
        
        # Verifikasi saldo wallet1 berkurang
        self.assertEqual(self.blockchain.get_balance(self.wallet1.address), 1000 - 50 - 30 - tx1.calculate_fee() - tx2.calculate_fee())
        
        # Verifikasi saldo wallet2 bertambah (termasuk reward mining)
        self.assertEqual(self.blockchain.get_balance(self.wallet2.address), 50 + 30 + self.blockchain.mining_reward)
    
    def test_blockchain_validation(self):
        """Pengujian validasi blockchain"""
        # Tambahkan beberapa blok
        for i in range(3):
            tx = self.wallet1.create_transaction(self.wallet2.address, 10)
            self.blockchain.add_transaction(tx)
            self.blockchain.mine_pending_transactions(self.wallet2.address)
        
        # Verifikasi blockchain valid
        self.assertTrue(self.blockchain.is_chain_valid())
        
        # Coba manipulasi blok
        self.blockchain.chain[1].transactions[0].amount = 1000
        
        # Verifikasi blockchain tidak valid setelah manipulasi
        self.assertFalse(self.blockchain.is_chain_valid())
    
    def test_smart_contract_deployment(self):
        """Pengujian deployment smart contract"""
        # Buat kode kontrak sederhana
        contract_code = """
        contract SimpleStorage {
          function store(key, value) {
            store(key, value)
          }
          
          function get(key) {
            get(key)
          }
        }
        """
        
        # Kompilasi kontrak
        compiled_code = self.compiler.compile(contract_code)
        
        # Deploy kontrak
        result = self.vm.deploy_contract(compiled_code, self.wallet1.address)
        
        # Verifikasi deployment berhasil
        self.assertTrue('success' in result and result['success'])
        self.assertTrue('contract_address' in result)
        
        # Verifikasi kontrak ada dalam VM
        contract_address = result['contract_address']
        self.assertIn(contract_address, self.vm.contracts)
    
    def test_smart_contract_execution(self):
        """Pengujian eksekusi smart contract"""
        # Buat dan deploy kontrak sederhana
        contract_code = {
            "store": {
                "type": "store",
                "key": "test_key",
                "value": {"type": "param", "key": "value"}
            },
            "get": {
                "type": "get",
                "key": "test_key"
            }
        }
        
        result = self.vm.deploy_contract(contract_code, self.wallet1.address)
        contract_address = result['contract_address']
        
        # Panggil metode store
        store_result = self.vm.call_contract(
            contract_address,
            "store",
            {"value": "test_value"},
            self.wallet1.address
        )
        
        # Verifikasi eksekusi berhasil
        self.assertTrue('success' in store_result and store_result['success'])
        
        # Panggil metode get
        get_result = self.vm.call_contract(
            contract_address,
            "get",
            {},
            self.wallet1.address
        )
        
        # Verifikasi nilai yang disimpan benar
        self.assertTrue('success' in get_result and get_result['success'])
        self.assertEqual(get_result['result']['value'], "test_value")
    
    def test_wallet_functionality(self):
        """Pengujian fungsionalitas wallet"""
        # Buat wallet baru
        wallet = Wallet()
        
        # Verifikasi alamat dan kunci publik/privat dibuat dengan benar
        self.assertIsNotNone(wallet.address)
        self.assertIsNotNone(wallet.public_key)
        self.assertIsNotNone(wallet.private_key)
        
        # Buat transaksi menggunakan wallet
        tx = wallet.create_transaction(self.wallet2.address, 50)
        
        # Verifikasi transaksi ditandatangani dengan benar
        self.assertIsNotNone(tx.signature)
        
        # Ekspor dan impor wallet dengan keystore
        password = "test_password"
        keystore = wallet.export_keystore(password)
        
        imported_wallet = Wallet.import_keystore(keystore, password)
        
        # Verifikasi wallet yang diimpor sama dengan wallet asli
        self.assertEqual(wallet.address, imported_wallet.address)
        self.assertEqual(wallet.private_key, imported_wallet.private_key)
        self.assertEqual(wallet.public_key, imported_wallet.public_key)
    
    def test_crypto_utils(self):
        """Pengujian utilitas kriptografi"""
        # Pengujian hash
        data = "test_data"
        hash_result = calculate_hash(data)
        self.assertIsNotNone(hash_result)
        
        # Pengujian generate keypair
        private_key, public_key = generate_keypair()
        self.assertIsNotNone(private_key)
        self.assertIsNotNone(public_key)
        
        # Pengujian generate address
        address = generate_address(public_key)
        self.assertTrue(address.startswith('0x'))
        self.assertEqual(len(address), 42)  # 0x + 40 karakter hex
        
        # Pengujian sign dan verify
        signature = sign_data(private_key, data)
        self.assertTrue(verify_signature(public_key, signature, data))
        
        # Pengujian verify dengan data yang diubah
        self.assertFalse(verify_signature(public_key, signature, "modified_data"))
    
    def test_proof_of_work(self):
        """Pengujian algoritma Proof of Work"""
        from src.utils.crypto_utils import proof_of_work
        
        # Buat header blok
        block_header = {
            'index': 1,
            'previous_hash': '0000000000000000000000000000000000000000000000000000000000000000',
            'timestamp': int(time.time()),
            'merkle_root': calculate_hash([]),
            'difficulty': 3,
            'nonce': 0
        }
        
        # Jalankan proof of work
        nonce, hash_result = proof_of_work(block_header, 3)
        
        # Verifikasi hash memenuhi tingkat kesulitan
        self.assertTrue(hash_result.startswith('000'))
        
        # Verifikasi nonce diperbarui
        self.assertNotEqual(nonce, 0)
    
    def test_compiler(self):
        """Pengujian compiler smart contract"""
        # Kode kontrak sederhana
        contract_code = """
        contract TestContract {
          function transfer(to, amount) {
            transfer(to, amount)
          }
          
          function conditionalTransfer(to, amount) {
            if(amount > 10) {
              transfer(to, amount)
            } else {
              store("error", "Amount too small")
            }
          }
        }
        """
        
        # Kompilasi kontrak
        compiled_code = self.compiler.compile(contract_code)
        
        # Verifikasi kompilasi berhasil
        self.assertIsInstance(compiled_code, dict)
        self.assertIn('transfer', compiled_code)
        self.assertIn('conditionalTransfer', compiled_code)
        
        # Verifikasi struktur kode yang dikompilasi
        self.assertEqual(compiled_code['transfer']['type'], 'transfer')
        self.assertEqual(compiled_code['conditionalTransfer']['type'], 'conditional')

if __name__ == '__main__':
    unittest.main()
