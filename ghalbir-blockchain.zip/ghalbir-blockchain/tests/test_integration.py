import unittest
import time
import json
import os
import sys
import threading
from src.network.node import Node
from src.api.metamask_api import MetaMaskAPI
from src.core.blockchain import Blockchain
from src.vm.virtual_machine import VirtualMachine
from src.wallet.wallet import Wallet

class TestIntegration(unittest.TestCase):
    def setUp(self):
        # Inisialisasi blockchain untuk pengujian
        self.blockchain = Blockchain(difficulty=2)  # Difficulty rendah untuk pengujian cepat
        
        # Inisialisasi VM
        self.vm = VirtualMachine(self.blockchain)
        
        # Inisialisasi wallet
        self.wallet = Wallet()
        
        # Tambahkan saldo ke wallet untuk pengujian
        self.blockchain.accounts[self.wallet.address] = 1000
        
        # Inisialisasi node
        self.node = Node(host='127.0.0.1', port=5000)
        self.node.blockchain = self.blockchain
        
        # Inisialisasi API MetaMask
        self.api = MetaMaskAPI(self.blockchain, self.vm)
        self.api.register_wallet(self.wallet)
    
    def test_node_start_stop(self):
        """Pengujian memulai dan menghentikan node"""
        # Mulai node
        self.node.start()
        
        # Verifikasi node berjalan
        self.assertTrue(self.node.running)
        
        # Tunggu sebentar
        time.sleep(1)
        
        # Hentikan node
        self.node.stop()
        
        # Verifikasi node berhenti
        self.assertFalse(self.node.running)
    
    def test_peer_connection(self):
        """Pengujian koneksi peer"""
        # Tambahkan peer
        self.node.add_peer("127.0.0.1:5001")
        
        # Verifikasi peer ditambahkan
        self.assertIn("127.0.0.1:5001", self.node.peers)
    
    def test_metamask_api(self):
        """Pengujian API MetaMask"""
        # Pengujian eth_accounts
        accounts = self.api.eth_accounts()
        self.assertIn(self.wallet.address, accounts)
        
        # Pengujian eth_getBalance
        balance = self.api.eth_getBalance([self.wallet.address, "latest"])
        self.assertEqual(balance, hex(1000))
        
        # Pengujian eth_blockNumber
        block_number = self.api.eth_blockNumber()
        self.assertEqual(block_number, hex(0))  # Genesis block
        
        # Pengujian eth_chainId
        chain_id = self.api.eth_chainId()
        self.assertEqual(chain_id, '0x539')  # 1337 in hex
        
        # Pengujian net_version
        net_version = self.api.net_version()
        self.assertEqual(net_version, '1337')
    
    def test_transaction_flow(self):
        """Pengujian alur transaksi lengkap"""
        # Buat wallet penerima
        recipient_wallet = Wallet()
        
        # Buat transaksi melalui API
        tx_params = {
            'from': self.wallet.address,
            'to': recipient_wallet.address,
            'value': '0x64',  # 100 in hex
            'gas': '0x5208',  # 21000 in hex
            'gasPrice': '0x1'
        }
        
        # Kirim transaksi
        tx_hash = self.api.eth_sendTransaction([tx_params])
        
        # Verifikasi transaksi ditambahkan ke pool
        self.assertEqual(len(self.blockchain.pending_transactions), 1)
        
        # Mine transaksi
        self.blockchain.mine_pending_transactions(self.wallet.address)
        
        # Verifikasi saldo penerima
        recipient_balance = self.blockchain.get_balance(recipient_wallet.address)
        self.assertEqual(recipient_balance, 100)
    
    def test_contract_deployment_and_interaction(self):
        """Pengujian deployment dan interaksi kontrak melalui API"""
        # Buat kode kontrak sederhana
        contract_code = {
            "store": {
                "type": "store",
                "key": "test_key",
                "value": {"type": "param", "key": "value"}
            },
            "get": {
                "type": "get",
                "key": "test_key"
            }
        }
        
        # Deploy kontrak
        result = self.vm.deploy_contract(contract_code, self.wallet.address)
        contract_address = result['contract_address']
        
        # Verifikasi kontrak di-deploy
        self.assertIn(contract_address, self.vm.contracts)
        
        # Buat data untuk memanggil kontrak
        method_data = {
            "method": "store",
            "params": {
                "value": "test_value"
            }
        }
        
        # Encode data
        data_json = json.dumps(method_data)
        data_hex = data_json.encode('utf-8').hex()
        
        # Buat parameter untuk eth_call
        call_params = [
            {
                'from': self.wallet.address,
                'to': contract_address,
                'data': '0x' + data_hex
            },
            'latest'
        ]
        
        # Panggil kontrak
        result_hex = self.api.eth_call(call_params)
        
        # Decode hasil
        result_json = bytes.fromhex(result_hex[2:]).decode('utf-8')
        result = json.loads(result_json)
        
        # Verifikasi hasil
        self.assertTrue('success' in result)
    
    def test_web_interface_api_compatibility(self):
        """Pengujian kompatibilitas API dengan antarmuka web"""
        # Simulasi request dari antarmuka web
        
        # 1. Dapatkan blok terbaru
        block_number = self.api.eth_blockNumber()
        block_params = [block_number, True]  # nomor blok, full transactions
        block = self.api.eth_getBlockByNumber(block_params)
        
        # Verifikasi format blok sesuai dengan yang diharapkan antarmuka web
        self.assertIn('number', block)
        self.assertIn('hash', block)
        self.assertIn('transactions', block)
        
        # 2. Dapatkan saldo wallet
        balance_hex = self.api.eth_getBalance([self.wallet.address, 'latest'])
        balance = int(balance_hex, 16)
        
        # Verifikasi saldo
        self.assertEqual(balance, 1000)
        
        # 3. Estimasi gas untuk transaksi
        tx_params = {
            'from': self.wallet.address,
            'to': '0x1234567890123456789012345678901234567890',
            'value': '0x64',
            'data': ''
        }
        
        gas_estimate = self.api.eth_estimateGas([tx_params])
        
        # Verifikasi estimasi gas
        self.assertEqual(gas_estimate, hex(21000))  # Gas dasar untuk transaksi

if __name__ == '__main__':
    unittest.main()
