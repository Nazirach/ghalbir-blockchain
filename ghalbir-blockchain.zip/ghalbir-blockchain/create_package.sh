#!/bin/bash

# Script untuk membuat paket distribusi Ghalbir Blockchain

echo "Membuat paket distribusi Ghalbir Blockchain..."

# Buat direktori untuk paket
PACKAGE_DIR="ghalbir-blockchain-package"
mkdir -p $PACKAGE_DIR

# Salin file-file yang diperlukan
echo "Menyalin file-file ke paket distribusi..."
cp -r src $PACKAGE_DIR/
cp -r web $PACKAGE_DIR/
cp -r docs $PACKAGE_DIR/
cp -r tests $PACKAGE_DIR/
cp setup_package.py $PACKAGE_DIR/
cp run_tests.py $PACKAGE_DIR/
cp todo.md $PACKAGE_DIR/
cp README.md $PACKAGE_DIR/

# Buat file README untuk paket
cat > $PACKAGE_DIR/README.txt << EOL
=== GHALBIR BLOCKCHAIN ===

Terima kasih telah mengunduh Ghalbir Blockchain!

== CARA MEMULAI ==

1. Jalankan setup_package.py untuk menyiapkan lingkungan:
   python setup_package.py

2. Ikuti instruksi yang ditampilkan untuk menjalankan node, API, dan membuat wallet.

3. Untuk dokumentasi lengkap, lihat direktori docs/

== KONTAK ==

Jika Anda memiliki pertanyaan atau masalah, silakan hubungi kami di:
Email: support@ghalbir.com
Website: https://ghalbir.com

== LISENSI ==

Ghalbir Blockchain dilisensikan di bawah Lisensi MIT.
Lihat file LICENSE untuk informasi lebih lanjut.
EOL

# Buat file ZIP
echo "Membuat file ZIP..."
zip -r ghalbir-blockchain.zip $PACKAGE_DIR

# Bersihkan
echo "Membersihkan..."
rm -rf $PACKAGE_DIR

echo "Paket distribusi berhasil dibuat: ghalbir-blockchain.zip"
echo "Anda dapat mendistribusikan file ini kepada pengguna."
