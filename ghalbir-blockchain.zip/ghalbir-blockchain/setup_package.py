#!/usr/bin/env python3

import os
import sys
import json
import argparse
import importlib.util

# Cek dependensi yang diperlukan
def check_dependencies():
    required_packages = [
        'ecdsa',
        'flask',
        'cryptography',
        'web3'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        spec = importlib.util.find_spec(package)
        if spec is None:
            missing_packages.append(package)
    
    if missing_packages:
        print("Beberapa paket yang diperlukan belum terinstal:")
        for package in missing_packages:
            print(f"  - {package}")
        print("\nSilakan instal paket-paket tersebut dengan perintah:")
        print(f"pip install {' '.join(missing_packages)}")
        return False
    
    return True

# Buat file konfigurasi
def create_config():
    config = {
        "node": {
            "host": "0.0.0.0",
            "port": 5000,
            "difficulty": 4,
            "mining_reward": 50,
            "peers": []
        },
        "api": {
            "host": "0.0.0.0",
            "port": 8545
        },
        "web": {
            "host": "0.0.0.0",
            "port": 8080
        }
    }
    
    with open('config.json', 'w') as f:
        json.dump(config, f, indent=2)
    
    print("File konfigurasi config.json telah dibuat.")

# Buat file run_node.py
def create_run_node():
    content = """#!/usr/bin/env python3

import os
import sys
import json
import argparse
from src.network.node import Node
from src.core.blockchain import Blockchain

def main():
    parser = argparse.ArgumentParser(description='Jalankan node Ghalbir Blockchain')
    parser.add_argument('--host', type=str, help='Host untuk menjalankan node')
    parser.add_argument('--port', type=int, help='Port untuk menjalankan node')
    parser.add_argument('--difficulty', type=int, help='Tingkat kesulitan untuk proof of work')
    parser.add_argument('--mining-reward', type=int, help='Reward untuk mining')
    parser.add_argument('--verbose', action='store_true', help='Mode verbose')
    args = parser.parse_args()
    
    # Baca konfigurasi
    config = {}
    if os.path.exists('config.json'):
        with open('config.json', 'r') as f:
            config = json.load(f)
    
    # Gunakan argumen command line jika ada, jika tidak gunakan konfigurasi
    host = args.host or config.get('node', {}).get('host', '0.0.0.0')
    port = args.port or config.get('node', {}).get('port', 5000)
    difficulty = args.difficulty or config.get('node', {}).get('difficulty', 4)
    mining_reward = args.mining_reward or config.get('node', {}).get('mining_reward', 50)
    
    # Inisialisasi blockchain
    blockchain = Blockchain(difficulty=difficulty, mining_reward=mining_reward)
    
    # Inisialisasi node
    node = Node(host=host, port=port)
    node.blockchain = blockchain
    
    # Tambahkan peer dari konfigurasi
    for peer in config.get('node', {}).get('peers', []):
        node.add_peer(peer)
    
    print(f"Memulai node Ghalbir Blockchain di {host}:{port}")
    print(f"Tingkat kesulitan: {difficulty}")
    print(f"Mining reward: {mining_reward}")
    
    # Mulai node
    node.start()
    
    try:
        # Jaga agar program tetap berjalan
        while True:
            cmd = input("Masukkan 'exit' untuk keluar: ")
            if cmd.lower() == 'exit':
                break
    except KeyboardInterrupt:
        print("\\nMenghentikan node...")
    finally:
        node.stop()

if __name__ == '__main__':
    main()
"""
    
    with open('run_node.py', 'w') as f:
        f.write(content)
    
    os.chmod('run_node.py', 0o755)
    print("File run_node.py telah dibuat.")

# Buat file run_api.py
def create_run_api():
    content = """#!/usr/bin/env python3

import os
import sys
import json
import argparse
from src.core.blockchain import Blockchain
from src.vm.virtual_machine import VirtualMachine
from src.api.metamask_api import MetaMaskAPI

def main():
    parser = argparse.ArgumentParser(description='Jalankan API Ghalbir Blockchain')
    parser.add_argument('--host', type=str, help='Host untuk menjalankan API')
    parser.add_argument('--port', type=int, help='Port untuk menjalankan API')
    parser.add_argument('--blockchain-file', type=str, help='File blockchain')
    parser.add_argument('--verbose', action='store_true', help='Mode verbose')
    args = parser.parse_args()
    
    # Baca konfigurasi
    config = {}
    if os.path.exists('config.json'):
        with open('config.json', 'r') as f:
            config = json.load(f)
    
    # Gunakan argumen command line jika ada, jika tidak gunakan konfigurasi
    host = args.host or config.get('api', {}).get('host', '0.0.0.0')
    port = args.port or config.get('api', {}).get('port', 8545)
    blockchain_file = args.blockchain_file or 'blockchain.json'
    
    # Inisialisasi blockchain
    if os.path.exists(blockchain_file):
        blockchain = Blockchain.load_from_file(blockchain_file)
    else:
        blockchain = Blockchain()
    
    # Inisialisasi VM
    vm = VirtualMachine(blockchain)
    
    # Inisialisasi API
    api = MetaMaskAPI(blockchain, vm)
    
    print(f"Memulai API Ghalbir Blockchain di {host}:{port}")
    
    # Mulai API
    api.start(host=host, port=port)

if __name__ == '__main__':
    main()
"""
    
    with open('run_api.py', 'w') as f:
        f.write(content)
    
    os.chmod('run_api.py', 0o755)
    print("File run_api.py telah dibuat.")

# Buat file create_wallet.py
def create_wallet_script():
    content = """#!/usr/bin/env python3

import os
import sys
import json
import argparse
from src.wallet.wallet import Wallet

def main():
    parser = argparse.ArgumentParser(description='Buat wallet Ghalbir Blockchain')
    parser.add_argument('--keystore', type=str, help='File keystore untuk menyimpan wallet')
    parser.add_argument('--password', type=str, help='Password untuk enkripsi keystore')
    args = parser.parse_args()
    
    # Buat wallet baru
    wallet = Wallet()
    
    print("Wallet baru berhasil dibuat!")
    print(f"Alamat: {wallet.address}")
    print(f"Kunci Publik: {wallet.public_key}")
    print(f"Kunci Privat: {wallet.private_key}")
    print("\\nPENTING: Simpan kunci privat Anda dengan aman!")
    
    # Simpan ke keystore jika diminta
    if args.keystore:
        if not args.password:
            password = input("Masukkan password untuk enkripsi keystore: ")
        else:
            password = args.password
        
        keystore_file = wallet.export_keystore(password, args.keystore)
        print(f"\\nWallet telah disimpan ke file keystore: {keystore_file}")

if __name__ == '__main__':
    main()
"""
    
    with open('create_wallet.py', 'w') as f:
        f.write(content)
    
    os.chmod('create_wallet.py', 0o755)
    print("File create_wallet.py telah dibuat.")

# Buat file mine.py
def create_mine_script():
    content = """#!/usr/bin/env python3

import os
import sys
import json
import time
import argparse
from src.core.blockchain import Blockchain

def main():
    parser = argparse.ArgumentParser(description='Mining Ghalbir Blockchain')
    parser.add_argument('--address', type=str, required=True, help='Alamat wallet untuk menerima reward')
    parser.add_argument('--blockchain-file', type=str, help='File blockchain')
    parser.add_argument('--blocks', type=int, help='Jumlah blok yang akan di-mining')
    parser.add_argument('--auto', action='store_true', help='Mode mining otomatis')
    args = parser.parse_args()
    
    blockchain_file = args.blockchain_file or 'blockchain.json'
    
    # Inisialisasi blockchain
    if os.path.exists(blockchain_file):
        blockchain = Blockchain.load_from_file(blockchain_file)
    else:
        blockchain = Blockchain()
    
    # Mining
    if args.blocks:
        # Mining sejumlah blok tertentu
        for i in range(args.blocks):
            print(f"Mining blok {i+1}/{args.blocks}...")
            block = blockchain.mine_pending_transactions(args.address)
            print(f"Blok berhasil di-mining! Hash: {block.hash}")
            
            # Simpan blockchain
            blockchain.save_to_file(blockchain_file)
    elif args.auto:
        # Mining otomatis
        try:
            print("Memulai mining otomatis. Tekan Ctrl+C untuk berhenti.")
            while True:
                # Tambahkan transaksi dummy jika tidak ada transaksi tertunda
                if len(blockchain.pending_transactions) == 0:
                    from src.core.transaction import Transaction
                    tx = Transaction("0x0", args.address, 0)
                    blockchain.add_transaction(tx)
                
                print("Mining blok...")
                block = blockchain.mine_pending_transactions(args.address)
                print(f"Blok berhasil di-mining! Hash: {block.hash}")
                
                # Simpan blockchain
                blockchain.save_to_file(blockchain_file)
                
                # Tunggu sebentar
                time.sleep(10)
        except KeyboardInterrupt:
            print("\\nMining dihentikan.")
    else:
        # Mining satu blok
        print("Mining blok...")
        block = blockchain.mine_pending_transactions(args.address)
        print(f"Blok berhasil di-mining! Hash: {block.hash}")
        
        # Simpan blockchain
        blockchain.save_to_file(blockchain_file)
    
    # Tampilkan saldo
    balance = blockchain.get_balance(args.address)
    print(f"Saldo: {balance} GBR")

if __name__ == '__main__':
    main()
"""
    
    with open('mine.py', 'w') as f:
        f.write(content)
    
    os.chmod('mine.py', 0o755)
    print("File mine.py telah dibuat.")

# Buat file requirements.txt
def create_requirements():
    content = """ecdsa==0.18.0
flask==2.0.1
cryptography==36.0.1
web3==5.24.0
"""
    
    with open('requirements.txt', 'w') as f:
        f.write(content)
    
    print("File requirements.txt telah dibuat.")

# Buat file README.md
def create_readme():
    content = """# Ghalbir Blockchain

Ghalbir Blockchain adalah implementasi blockchain yang terinspirasi dari Ethereum dengan fitur-fitur utama seperti transaksi, smart contract, dan integrasi dengan MetaMask.

## Fitur Utama

- Implementasi blockchain lengkap dengan Proof of Work
- Smart contract dengan bahasa kontrak sederhana
- Wallet dengan manajemen kunci publik/privat
- Integrasi dengan MetaMask
- Antarmuka web untuk interaksi dengan blockchain
- API yang kompatibel dengan Ethereum

## Memulai

### Instalasi

```bash
# Kloning repositori
git clone https://github.com/yourusername/ghalbir-blockchain.git
cd ghalbir-blockchain

# Instal dependensi
pip install -r requirements.txt
```

### Menjalankan Node

```bash
python run_node.py
```

### Membuat Wallet

```bash
python create_wallet.py
```

### Menjalankan API

```bash
python run_api.py
```

### Mining

```bash
python mine.py --address YOUR_WALLET_ADDRESS
```

## Dokumentasi

Dokumentasi lengkap tersedia di direktori `docs/`:

- [Instalasi](docs/installation.md)
- [Penggunaan](docs/usage.md)
- [API Reference](docs/api_reference.md)
- [Panduan Pengembang](docs/developer_guide.md)

## Lisensi

MIT License
"""
    
    with open('README.md', 'w') as f:
        f.write(content)
    
    print("File README.md telah dibuat.")

# Buat file LICENSE
def create_license():
    content = """MIT License

Copyright (c) 2025 Ghalbir Blockchain

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
    
    with open('LICENSE', 'w') as f:
        f.write(content)
    
    print("File LICENSE telah dibuat.")

# Buat file .gitignore
def create_gitignore():
    content = """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
*.egg-info/
.installed.cfg
*.egg

# Virtual Environment
venv/
ENV/

# IDE
.idea/
.vscode/
*.swp
*.swo

# Blockchain data
blockchain.json
keystore/

# Config
config.json

# Logs
*.log
"""
    
    with open('.gitignore', 'w') as f:
        f.write(content)
    
    print("File .gitignore telah dibuat.")

# Buat file setup.py
def create_setup():
    content = """from setuptools import setup, find_packages

setup(
    name="ghalbir-blockchain",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "ecdsa",
        "flask",
        "cryptography",
        "web3",
    ],
    entry_points={
        'console_scripts': [
            'ghalbir-node=run_node:main',
            'ghalbir-api=run_api:main',
            'ghalbir-wallet=create_wallet:main',
            'ghalbir-mine=mine:main',
        ],
    },
    author="Ghalbir Team",
    author_email="info@ghalbir.com",
    description="Implementasi blockchain yang terinspirasi dari Ethereum",
    keywords="blockchain, ethereum, cryptocurrency",
    url="https://github.com/yourusername/ghalbir-blockchain",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
    python_requires=">=3.8",
)
"""
    
    with open('setup.py', 'w') as f:
        f.write(content)
    
    print("File setup.py telah dibuat.")

# Buat file deployment.md
def create_deployment_guide():
    content = """# Ghalbir Blockchain - Panduan Deployment

## Daftar Isi
1. [Deployment Lokal](#deployment-lokal)
2. [Deployment Server](#deployment-server)
3. [Deployment Docker](#deployment-docker)
4. [Deployment Cloud](#deployment-cloud)

## Deployment Lokal

### Persyaratan
- Python 3.8 atau lebih tinggi
- pip
- Node.js dan npm (untuk antarmuka web)

### Langkah-langkah
1. Kloning repositori:
   ```bash
   git clone https://github.com/yourusername/ghalbir-blockchain.git
   cd ghalbir-blockchain
   ```

2. Instal dependensi:
   ```bash
   pip install -r requirements.txt
   ```

3. Buat konfigurasi:
   ```bash
   cp config.example.json config.json
   ```
   Edit `config.json` sesuai kebutuhan.

4. Jalankan node:
   ```bash
   python run_node.py
   ```

5. Jalankan API:
   ```bash
   python run_api.py
   ```

6. Jalankan antarmuka web:
   ```bash
   cd web
   python -m http.server 8080
   ```

## Deployment Server

### Persyaratan
- Server Linux (Ubuntu 20.04 LTS direkomendasikan)
- Python 3.8 atau lebih tinggi
- pip
- Node.js dan npm (untuk antarmuka web)
- Nginx (opsional, untuk reverse proxy)

### Langkah-langkah
1. Persiapkan server:
   ```bash
   sudo apt update
   sudo apt install -y python3 python3-pip python3-venv git nginx
   ```

2. Kloning repositori:
   ```bash
   git clone https://github.com/yourusername/ghalbir-blockchain.git
   cd ghalbir-blockchain
   ```

3. Buat dan aktifkan lingkungan virtual:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

4. Instal dependensi:
   ```bash
   pip install -r requirements.txt
   ```

5. Buat konfigurasi:
   ```bash
   cp config.example.json config.json
   ```
   Edit `config.json` sesuai kebutuhan.

6. Buat service untuk node:
   ```bash
   sudo nano /etc/systemd/system/ghalbir-node.service
   ```
   
   Isi dengan:
   ```
   [Unit]
   Description=Ghalbir Blockchain Node
   After=network.target

   [Service]
   User=ubuntu
   WorkingDirectory=/home/ubuntu/ghalbir-blockchain
   ExecStart=/home/ubuntu/ghalbir-blockchain/venv/bin/python run_node.py
   Restart=always

   [Install]
   WantedBy=multi-user.target
   ```

7. Buat service untuk API:
   ```bash
   sudo nano /etc/systemd/system/ghalbir-api.service
   ```
   
   Isi dengan:
   ```
   [Unit]
   Description=Ghalbir Blockchain API
   After=network.target

   [Service]
   User=ubuntu
   WorkingDirectory=/home/ubuntu/ghalbir-blockchain
   ExecStart=/home/ubuntu/ghalbir-blockchain/venv/bin/python run_api.py
   Restart=always

   [Install]
   WantedBy=multi-user.target
   ```

8. Aktifkan dan jalankan service:
   ```bash
   sudo systemctl enable ghalbir-node
   sudo systemctl start ghalbir-node
   sudo systemctl enable ghalbir-api
   sudo systemctl start ghalbir-api
   ```

9. Konfigurasi Nginx sebagai reverse proxy:
   ```bash
   sudo nano /etc/nginx/sites-available/ghalbir
   ```
   
   Isi dengan:
   ```
   server {
       listen 80;
       server_name your-domain.com;

       location /api/ {
           proxy_pass http://localhost:8545/;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }

       location / {
           root /home/ubuntu/ghalbir-blockchain/web;
           index index.html;
           try_files $uri $uri/ /index.html;
       }
   }
   ```

10. Aktifkan konfigurasi Nginx:
    ```bash
    sudo ln -s /etc/nginx/sites-available/ghalbir /etc/nginx/sites-enabled/
    sudo nginx -t
    sudo systemctl restart nginx
    ```

## Deployment Docker

### Persyaratan
- Docker
- Docker Compose

### Langkah-langkah
1. Buat Dockerfile:
   ```bash
   nano Dockerfile
   ```
   
   Isi dengan:
   ```dockerfile
   FROM python:3.9-slim

   WORKDIR /app

   COPY requirements.txt .
   RUN pip install --no-cache-dir -r requirements.txt

   COPY . .

   EXPOSE 5000 8545 8080

   CMD ["python", "run_node.py"]
   ```

2. Buat docker-compose.yml:
   ```bash
   nano docker-compose.yml
   ```
   
   Isi dengan:
   ```yaml
   version: '3'

   services:
     node:
       build: .
       ports:
         - "5000:5000"
       volumes:
         - ./data:/app/data
       command: python run_node.py
       restart: always

     api:
       build: .
       ports:
         - "8545:8545"
       volumes:
         - ./data:/app/data
       command: python run_api.py
       depends_on:
         - node
       restart: always

     web:
       image: nginx:alpine
       ports:
         - "8080:80"
       volumes:
         - ./web:/usr/share/nginx/html
       depends_on:
         - api
       restart: always
   ```

3. Jalankan dengan Docker Compose:
   ```bash
   docker-compose up -d
   ```

## Deployment Cloud

### AWS

1. Buat EC2 instance:
   - Ubuntu Server 20.04 LTS
   - t2.micro (untuk pengujian) atau t2.medium (untuk produksi)
   - Buka port 22 (SSH), 80 (HTTP), 443 (HTTPS), 5000 (Node), 8545 (API)

2. Connect ke instance dan ikuti langkah-langkah deployment server di atas.

### Google Cloud Platform

1. Buat VM instance:
   - Ubuntu 20.04 LTS
   - e2-micro (untuk pengujian) atau e2-medium (untuk produksi)
   - Buka port 22 (SSH), 80 (HTTP), 443 (HTTPS), 5000 (Node), 8545 (API)

2. Connect ke instance dan ikuti langkah-langkah deployment server di atas.

### Microsoft Azure

1. Buat Virtual Machine:
   - Ubuntu Server 20.04 LTS
   - B1s (untuk pengujian) atau B2s (untuk produksi)
   - Buka port 22 (SSH), 80 (HTTP), 443 (HTTPS), 5000 (Node), 8545 (API)

2. Connect ke VM dan ikuti langkah-langkah deployment server di atas.

### Heroku

1. Buat Procfile:
   ```
   web: gunicorn -b 0.0.0.0:$PORT run_api:app
   worker: python run_node.py
   ```

2. Deploy ke Heroku:
   ```bash
   heroku create ghalbir-blockchain
   git push heroku main
   ```

3. Skala worker:
   ```bash
   heroku ps:scale web=1 worker=1
   ```

### DigitalOcean

1. Buat Droplet:
   - Ubuntu 20.04 LTS
   - Basic plan ($5/mo untuk pengujian, $10/mo untuk produksi)

2. Connect ke Droplet dan ikuti langkah-langkah deployment server di atas.
"""
    
    with open('docs/deployment.md', 'w') as f:
        f.write(content)
    
    print("File docs/deployment.md telah dibuat.")

# Buat file web/js/web3.min.js
def create_web3_min_js():
    # Buat file kosong untuk web3.min.js
    # Dalam implementasi sebenarnya, ini akan berisi kode web3.js yang diminifikasi
    with open('web/js/web3.min.js', 'w') as f:
        f.write("// Web3.js library akan diunduh saat runtime")
    
    print("File web/js/web3.min.js telah dibuat.")

# Buat file __init__.py di setiap direktori
def create_init_files():
    directories = [
        'src',
        'src/core',
        'src/vm',
        'src/wallet',
        'src/network',
        'src/api',
        'src/utils',
        'tests'
    ]
    
    for directory in directories:
        with open(f'{directory}/__init__.py', 'w') as f:
            f.write("")
    
    print("File __init__.py telah dibuat di setiap direktori.")

# Fungsi utama
def main():
    parser = argparse.ArgumentParser(description='Persiapan paket Ghalbir Blockchain')
    parser.add_argument('--check-only', action='store_true', help='Hanya cek dependensi tanpa membuat file')
    args = parser.parse_args()
    
    # Cek dependensi
    if not check_dependencies():
        if args.check_only:
            sys.exit(1)
        
        # Tanya pengguna apakah ingin melanjutkan
        response = input("Apakah Anda ingin melanjutkan tanpa menginstal dependensi? (y/n): ")
        if response.lower() != 'y':
            sys.exit(1)
    
    if args.check_only:
        print("Semua dependensi terpenuhi.")
        sys.exit(0)
    
    # Buat file-file yang diperlukan
    create_config()
    create_run_node()
    create_run_api()
    create_wallet_script()
    create_mine_script()
    create_requirements()
    create_readme()
    create_license()
    create_gitignore()
    create_setup()
    create_deployment_guide()
    create_web3_min_js()
    create_init_files()
    
    print("\nPersiapan paket Ghalbir Blockchain selesai!")
    print("Anda dapat menjalankan node dengan perintah: python run_node.py")
    print("Anda dapat menjalankan API dengan perintah: python run_api.py")
    print("Anda dapat membuat wallet dengan perintah: python create_wallet.py")
    print("Anda dapat melakukan mining dengan perintah: python mine.py --address YOUR_WALLET_ADDRESS")
    print("\nUntuk informasi lebih lanjut, silakan baca dokumentasi di direktori docs/")

if __name__ == '__main__':
    main()
