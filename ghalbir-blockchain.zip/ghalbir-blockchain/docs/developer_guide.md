# Ghalbir Blockchain - Panduan Pengembang

## Daftar Isi
1. [Pengenalan](#pengenalan)
2. [Arsitektur](#arsitektur)
3. [Struktur Kode](#struktur-kode)
4. [Pengembangan Fitur Baru](#pengembangan-fitur-baru)
5. [Pengujian](#pengujian)
6. [Praktik Terbaik](#praktik-terbaik)
7. [Kontribusi](#kontribusi)

## Pengenalan

Dokumen ini ditujukan untuk pengembang yang ingin memahami, memodifikasi, atau berkontribusi pada proyek Ghalbir Blockchain. Dokumen ini menjelaskan arsitektur, struktur kode, dan praktik terbaik untuk pengembangan.

## Arsitektur

Ghalbir Blockchain dibangun dengan arsitektur modular yang terdiri dari beberapa komponen utama:

### Core
Komponen inti yang menangani fungsi blockchain dasar:
- **Block**: Representasi blok dalam blockchain
- **Transaction**: Representasi transaksi
- **Blockchain**: Pengelolaan rantai blok dan state

### VM (Virtual Machine)
Komponen yang menangani eksekusi smart contract:
- **Contract**: Representasi smart contract
- **VirtualMachine**: Mesin virtual untuk eksekusi kontrak
- **Compiler**: Kompiler untuk bahasa kontrak

### Wallet
Komponen yang menangani manajemen kunci dan transaksi:
- **Wallet**: Pengelolaan kunci publik/privat dan tanda tangan

### Network
Komponen yang menangani komunikasi P2P:
- **Node**: Representasi node dalam jaringan
- **P2P**: Protokol komunikasi antar node

### API
Komponen yang menyediakan interface untuk aplikasi eksternal:
- **MetaMaskAPI**: API yang kompatibel dengan MetaMask
- **JSONRPC**: Implementasi JSON-RPC

### Utils
Komponen utilitas yang digunakan oleh komponen lain:
- **CryptoUtils**: Fungsi kriptografi
- **Serialization**: Fungsi serialisasi/deserialisasi

## Struktur Kode

```
ghalbir-blockchain/
├── src/
│   ├── core/
│   │   ├── block.py
│   │   ├── transaction.py
│   │   └── blockchain.py
│   ├── vm/
│   │   ├── contract.py
│   │   ├── virtual_machine.py
│   │   └── compiler.py
│   ├── wallet/
│   │   └── wallet.py
│   ├── network/
│   │   └── node.py
│   ├── api/
│   │   └── metamask_api.py
│   └── utils/
│       └── crypto_utils.py
├── web/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── app.js
│   └── index.html
├── tests/
│   ├── test_blockchain.py
│   └── test_integration.py
├── docs/
│   ├── blockchain_fundamentals.md
│   ├── installation.md
│   ├── usage.md
│   └── api_reference.md
└── run_tests.py
```

## Pengembangan Fitur Baru

### Langkah-langkah Pengembangan

1. **Perencanaan**: Tentukan fitur yang akan dikembangkan dan bagaimana fitur tersebut akan terintegrasi dengan sistem yang ada.
2. **Implementasi**: Tulis kode untuk fitur baru, ikuti konvensi kode yang ada.
3. **Pengujian**: Tulis pengujian untuk fitur baru, pastikan semua pengujian lulus.
4. **Dokumentasi**: Perbarui dokumentasi untuk mencerminkan fitur baru.
5. **Review**: Minta review dari pengembang lain sebelum mengintegrasikan fitur baru.

### Contoh: Menambahkan Fitur Baru

Berikut adalah contoh langkah-langkah untuk menambahkan fitur baru, misalnya implementasi mekanisme konsensus baru:

1. Buat file baru di direktori yang sesuai, misalnya `src/core/consensus.py`.
2. Implementasikan kelas dan metode yang diperlukan.
3. Integrasikan dengan komponen yang ada, misalnya dengan memodifikasi `blockchain.py`.
4. Tulis pengujian di `tests/test_consensus.py`.
5. Perbarui dokumentasi di `docs/`.

## Pengujian

### Jenis Pengujian

Ghalbir Blockchain menggunakan beberapa jenis pengujian:

1. **Unit Test**: Pengujian komponen individual.
2. **Integration Test**: Pengujian interaksi antar komponen.
3. **End-to-End Test**: Pengujian sistem secara keseluruhan.

### Menjalankan Pengujian

```bash
# Menjalankan semua pengujian
python run_tests.py

# Menjalankan pengujian spesifik
python -m unittest tests.test_blockchain
```

### Menulis Pengujian Baru

Pengujian baru harus ditulis untuk setiap fitur baru. Berikut adalah contoh pengujian:

```python
import unittest
from src.core.block import Block

class TestBlock(unittest.TestCase):
    def test_block_creation(self):
        block = Block(1, "previous_hash", 123456789, [])
        self.assertEqual(block.index, 1)
        self.assertEqual(block.previous_hash, "previous_hash")
        self.assertEqual(block.timestamp, 123456789)
        self.assertEqual(block.transactions, [])
```

## Praktik Terbaik

### Konvensi Kode

- Ikuti [PEP 8](https://www.python.org/dev/peps/pep-0008/) untuk gaya kode Python.
- Gunakan docstring untuk mendokumentasikan kelas dan metode.
- Gunakan type hints untuk memperjelas tipe parameter dan return value.

### Pengelolaan Versi

- Gunakan [Semantic Versioning](https://semver.org/) untuk penomoran versi.
- Buat tag untuk setiap rilis.
- Gunakan branch untuk pengembangan fitur baru.

### Keamanan

- Selalu validasi input dari pengguna.
- Gunakan fungsi kriptografi yang aman.
- Hindari menyimpan kunci privat dalam kode.
- Lakukan audit keamanan secara berkala.

### Performa

- Optimalkan operasi yang sering digunakan.
- Gunakan profiling untuk mengidentifikasi bottleneck.
- Pertimbangkan penggunaan caching untuk operasi yang mahal.

## Kontribusi

### Proses Kontribusi

1. Fork repositori.
2. Buat branch baru untuk fitur atau perbaikan.
3. Implementasikan perubahan.
4. Pastikan semua pengujian lulus.
5. Buat pull request.

### Panduan Kontribusi

- Pastikan kode Anda mengikuti konvensi kode yang ada.
- Tambahkan pengujian untuk fitur baru atau perbaikan.
- Perbarui dokumentasi jika diperlukan.
- Jelaskan perubahan Anda dengan jelas dalam deskripsi pull request.

### Pelaporan Bug

Jika Anda menemukan bug, silakan buat issue baru dengan informasi berikut:
- Deskripsi bug
- Langkah-langkah untuk mereproduksi
- Perilaku yang diharapkan
- Perilaku aktual
- Informasi lingkungan (OS, versi Python, dll.)

### Permintaan Fitur

Jika Anda memiliki ide untuk fitur baru, silakan buat issue baru dengan informasi berikut:
- Deskripsi fitur
- Alasan mengapa fitur ini diperlukan
- Contoh penggunaan
- Implementasi yang diusulkan (opsional)
