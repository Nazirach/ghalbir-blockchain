# Dasar-Dasar Blockchain untuk Ghalbir

Blockchain adalah teknologi buku besar terdistribusi yang memungkinkan pencatatan transaksi secara aman, transparan, dan tidak dapat diubah. Berikut adalah konsep-konsep dasar yang akan diimplementasikan dalam Ghalbir Blockchain:

## Konsep Dasar Blockchain

1. **Blok**: Unit dasar dalam blockchain yang berisi kumpulan transaksi. Setiap blok terhubung ke blok sebelumnya melalui hash kriptografis, membentuk "rantai".

2. **Hash**: Fungsi matematika satu arah yang mengubah data menjadi string karakter dengan panjang tetap. Digunakan untuk mengamankan integritas data dalam blockchain.

3. **Konsensus**: Mekanisme yang memungkinkan semua node dalam jaringan untuk menyetujui status blockchain. Ghalbir akan menggunakan Proof of Work (PoW) seperti Ethereum klasik.

4. **Proof of Work (PoW)**: Mekanisme konsensus di mana node (penambang) harus menyelesaikan teka-teki komputasi yang sulit untuk menambahkan blok baru ke blockchain.

5. **Transaksi**: Transfer nilai atau data antara alamat di blockchain. Transaksi ditandatangani secara kriptografis untuk memastikan keamanan.

6. **Kunci Publik/Privat**: Pasangan kunci kriptografis yang digunakan untuk mengamankan transaksi. Kunci privat digunakan untuk menandatangani transaksi, sementara kunci publik digunakan untuk memverifikasi tanda tangan.

## Cara Kerja Ethereum yang Akan Diadaptasi

1. **Akun**: Ethereum memiliki dua jenis akun: akun eksternal (dimiliki oleh pengguna) dan akun kontrak (berisi kode smart contract). Ghalbir akan mengimplementasikan kedua jenis akun ini.

2. **Gas**: Mekanisme untuk mengukur biaya komputasi dalam eksekusi transaksi dan smart contract. Ghalbir akan mengimplementasikan sistem gas untuk mencegah spam dan loop tak terbatas.

3. **Smart Contract**: Program yang berjalan di blockchain dan dieksekusi secara otomatis ketika kondisi tertentu terpenuhi. Ghalbir akan mendukung smart contract dengan fungsionalitas dasar.

4. **Ethereum Virtual Machine (EVM)**: Mesin virtual yang mengeksekusi smart contract. Ghalbir akan mengimplementasikan versi sederhana dari EVM.

5. **Solidity**: Bahasa pemrograman untuk menulis smart contract di Ethereum. Ghalbir akan mendukung subset dari Solidity untuk smart contract.

## Mekanisme Konsensus

Ghalbir akan menggunakan Proof of Work (PoW) sebagai mekanisme konsensus awal:

1. **Penambang** mengumpulkan transaksi yang valid dari pool transaksi.
2. **Penambang** mencoba menemukan nonce yang, ketika digabungkan dengan data blok, menghasilkan hash yang memenuhi tingkat kesulitan tertentu.
3. Ketika solusi ditemukan, blok disebarkan ke jaringan.
4. **Node lain** memverifikasi solusi dan menambahkan blok ke blockchain mereka jika valid.
5. **Penambang** yang berhasil menerima reward dalam bentuk token Ghalbir.

## Integrasi dengan MetaMask

MetaMask adalah dompet Ethereum berbasis browser yang memungkinkan pengguna berinteraksi dengan aplikasi terdesentralisasi (dApps). Ghalbir akan diimplementasikan dengan kompatibilitas MetaMask:

1. **Web3.js**: Library JavaScript yang memungkinkan interaksi dengan blockchain Ethereum. Ghalbir akan mengimplementasikan API yang kompatibel dengan Web3.js.

2. **JSON-RPC**: Protokol yang digunakan oleh MetaMask untuk berkomunikasi dengan node Ethereum. Ghalbir akan mengimplementasikan endpoint JSON-RPC yang diperlukan.

3. **Tanda Tangan Transaksi**: Proses penandatanganan transaksi menggunakan kunci privat. Ghalbir akan mendukung format tanda tangan yang kompatibel dengan MetaMask.

## Arsitektur Ghalbir

Ghalbir akan diimplementasikan dengan arsitektur modular:

1. **Core**: Modul inti yang menangani konsensus, validasi blok, dan manajemen state.
2. **Network**: Modul yang menangani komunikasi P2P antara node.
3. **VM**: Modul yang mengeksekusi smart contract.
4. **API**: Modul yang menyediakan interface untuk berinteraksi dengan blockchain.
5. **Wallet**: Modul yang menangani manajemen kunci dan tanda tangan transaksi.

Dengan pemahaman dasar ini, kita dapat mulai mengimplementasikan Ghalbir Blockchain yang tangguh dan fungsional.
