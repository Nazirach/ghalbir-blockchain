# Ghalbir Blockchain - Panduan Penggunaan

## Daftar Isi
1. [Pengenalan](#pengenalan)
2. [Memulai](#memulai)
3. [Menggunakan Wallet](#menggunakan-wallet)
4. [Transaksi](#transaksi)
5. [Smart Contract](#smart-contract)
6. [Integrasi dengan MetaMask](#integrasi-dengan-metamask)
7. [Antarmuka Web](#antarmuka-web)
8. [Perintah CLI](#perintah-cli)
9. [Tips dan Trik](#tips-dan-trik)

## Pengenalan

Ghalbir Blockchain adalah implementasi blockchain yang terinspirasi dari Ethereum dengan fitur-fitur utama seperti transaksi, smart contract, dan integrasi dengan MetaMask. Dokumen ini akan memandu Anda dalam menggunakan Ghalbir Blockchain.

## Memulai

Setelah menginstal Ghalbir Blockchain (lihat [Dokumentasi Instalasi](installation.md)), Anda perlu menjalankan node dan membuat wallet.

### Menjalankan Node

```bash
python run_node.py
```

### Membuat Wallet

```bash
python create_wallet.py
```

Perintah ini akan menghasilkan output seperti berikut:

```
Wallet baru berhasil dibuat!
Alamat: 0x1234567890abcdef1234567890abcdef12345678
Kunci Publik: 0x...
Kunci Privat: 0x...

PENTING: Simpan kunci privat Anda dengan aman!
```

## Menggunakan Wallet

### Memeriksa Saldo

```bash
python wallet.py balance --address 0x1234567890abcdef1234567890abcdef12345678
```

### Mengimpor Wallet dari Kunci Privat

```bash
python wallet.py import --private-key 0x...
```

### Mengekspor Wallet ke Keystore

```bash
python wallet.py export --address 0x1234567890abcdef1234567890abcdef12345678 --password YourSecurePassword
```

### Mengimpor Wallet dari Keystore

```bash
python wallet.py import --keystore path/to/keystore.json --password YourSecurePassword
```

## Transaksi

### Mengirim Transaksi

```bash
python wallet.py send --from 0x1234567890abcdef1234567890abcdef12345678 --to 0xabcdef1234567890abcdef1234567890abcdef12 --amount 10 --private-key 0x...
```

### Melihat Status Transaksi

```bash
python wallet.py tx-status --hash 0x...
```

### Melihat Riwayat Transaksi

```bash
python wallet.py history --address 0x1234567890abcdef1234567890abcdef12345678
```

## Smart Contract

### Menulis Smart Contract

Ghalbir mendukung bahasa kontrak sederhana yang mirip dengan Solidity. Berikut adalah contoh kontrak sederhana:

```
contract SimpleStorage {
  function store(key, value) {
    store(key, value)
  }
  
  function get(key) {
    get(key)
  }
}
```

Simpan kontrak dalam file, misalnya `simple_storage.contract`.

### Mengkompilasi Smart Contract

```bash
python contract.py compile --file simple_storage.contract --output simple_storage.json
```

### Men-deploy Smart Contract

```bash
python contract.py deploy --file simple_storage.json --from 0x1234567890abcdef1234567890abcdef12345678 --private-key 0x...
```

Perintah ini akan menghasilkan output seperti berikut:

```
Kontrak berhasil di-deploy!
Alamat Kontrak: 0xabcdef1234567890abcdef1234567890abcdef12
Gas yang Digunakan: 100000
```

### Memanggil Metode Kontrak

```bash
python contract.py call --address 0xabcdef1234567890abcdef1234567890abcdef12 --method store --params '{"key": "test_key", "value": "test_value"}' --from 0x1234567890abcdef1234567890abcdef12345678 --private-key 0x...
```

### Mendapatkan Nilai dari Kontrak

```bash
python contract.py call --address 0xabcdef1234567890abcdef1234567890abcdef12 --method get --params '{"key": "test_key"}' --from 0x1234567890abcdef1234567890abcdef12345678
```

## Integrasi dengan MetaMask

### Menambahkan Jaringan Ghalbir ke MetaMask

1. Buka MetaMask dan klik menu jaringan di bagian atas
2. Pilih "Add Network"
3. Isi detail berikut:
   - Network Name: Ghalbir
   - New RPC URL: http://localhost:8545
   - Chain ID: 1337
   - Currency Symbol: GBR
   - Block Explorer URL: (kosongkan)
4. Klik "Save"

### Mengimpor Akun ke MetaMask

1. Buka MetaMask dan klik menu akun di bagian atas
2. Pilih "Import Account"
3. Pilih "Private Key"
4. Masukkan kunci privat Anda (tanpa awalan 0x)
5. Klik "Import"

### Menggunakan MetaMask dengan Ghalbir

Setelah mengimpor akun, Anda dapat menggunakan MetaMask untuk:
- Melihat saldo
- Mengirim transaksi
- Berinteraksi dengan smart contract

## Antarmuka Web

### Mengakses Antarmuka Web

Setelah menjalankan antarmuka web (lihat [Dokumentasi Instalasi](installation.md)), buka browser dan akses:

```
http://localhost:8080
```

### Fitur Antarmuka Web

Antarmuka web Ghalbir menyediakan fitur-fitur berikut:

#### Dashboard
- Melihat status blockchain
- Melihat blok terbaru
- Melihat transaksi terbaru

#### Wallet
- Menghubungkan dengan MetaMask
- Membuat wallet baru
- Melihat saldo
- Mengirim transaksi
- Melihat riwayat transaksi

#### Transaksi
- Mencari transaksi berdasarkan hash
- Melihat detail transaksi

#### Smart Contract
- Men-deploy smart contract
- Berinteraksi dengan smart contract
- Melihat hasil eksekusi

#### Explorer
- Mencari blok berdasarkan nomor
- Melihat detail blok
- Melihat daftar blok terbaru

## Perintah CLI

Ghalbir menyediakan berbagai perintah CLI untuk berinteraksi dengan blockchain:

### Node

```bash
# Menjalankan node
python run_node.py

# Menjalankan node dengan opsi kustom
python run_node.py --host 127.0.0.1 --port 5001 --difficulty 3

# Menjalankan node dengan mode verbose
python run_node.py --verbose
```

### Mining

```bash
# Memulai mining
python mine.py --address 0x1234567890abcdef1234567890abcdef12345678

# Mining dengan jumlah blok tertentu
python mine.py --address 0x1234567890abcdef1234567890abcdef12345678 --blocks 10

# Mining dengan mode otomatis
python mine.py --address 0x1234567890abcdef1234567890abcdef12345678 --auto
```

### Blockchain

```bash
# Melihat status blockchain
python blockchain.py status

# Melihat blok berdasarkan nomor
python blockchain.py block --number 10

# Melihat blok berdasarkan hash
python blockchain.py block --hash 0x...

# Memvalidasi blockchain
python blockchain.py validate
```

## Tips dan Trik

### Meningkatkan Performa

- Gunakan difficulty yang lebih rendah untuk pengembangan
- Batasi jumlah transaksi per blok
- Gunakan mode produksi untuk antarmuka web

### Keamanan

- Selalu simpan kunci privat dengan aman
- Gunakan keystore dengan password yang kuat
- Jangan pernah membagikan kunci privat Anda

### Pengembangan

- Gunakan mode verbose untuk debugging
- Jalankan pengujian secara teratur
- Gunakan lingkungan virtual Python

### Jaringan

- Tambahkan peer terpercaya ke konfigurasi
- Gunakan port yang tidak terblokir oleh firewall
- Periksa koneksi peer secara berkala
