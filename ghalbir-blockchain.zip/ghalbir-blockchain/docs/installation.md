# Ghalbir Blockchain - Dokumentasi Instalasi

## Daftar Isi
1. [Persyaratan Sistem](#persyaratan-sistem)
2. [Instalasi](#instalasi)
3. [Konfigurasi](#konfigurasi)
4. [Menjalankan Node](#menjalankan-node)
5. [Menjalankan API MetaMask](#menjalankan-api-metamask)
6. [Menjalankan Antarmuka Web](#menjalankan-antarmuka-web)
7. [Pengujian](#pengujian)
8. [Pemecahan Masalah](#pemecahan-masalah)

## Persyaratan Sistem

Sebelum menginstal Ghalbir Blockchain, pastikan sistem Anda memenuhi persyaratan berikut:

- **Sistem Operasi**: Linux, macOS, atau Windows dengan WSL
- **Python**: Versi 3.8 atau lebih tinggi
- **Pip**: Pengelola paket Python
- **Node.js**: Versi 14 atau lebih tinggi (untuk antarmuka web)
- **npm**: Pengelola paket Node.js
- **Git**: Untuk mengkloning repositori

## Instalasi

### 1. Kloning Repositori

```bash
git clone https://github.com/yourusername/ghalbir-blockchain.git
cd ghalbir-blockchain
```

### 2. Instalasi Dependensi Python

Buat dan aktifkan lingkungan virtual Python (opsional tetapi direkomendasikan):

```bash
python3 -m venv venv
source venv/bin/activate  # Untuk Linux/macOS
# atau
venv\Scripts\activate  # Untuk Windows
```

Instal dependensi Python:

```bash
pip install -r requirements.txt
```

### 3. Instalasi Dependensi Node.js

Untuk antarmuka web, instal dependensi Node.js:

```bash
cd web
npm install
```

## Konfigurasi

### 1. Konfigurasi Blockchain

Salin file konfigurasi contoh:

```bash
cp config.example.json config.json
```

Edit `config.json` sesuai kebutuhan Anda:

```json
{
  "node": {
    "host": "0.0.0.0",
    "port": 5000,
    "difficulty": 4,
    "mining_reward": 50
  },
  "api": {
    "host": "0.0.0.0",
    "port": 8545
  },
  "web": {
    "host": "0.0.0.0",
    "port": 8080
  }
}
```

### 2. Konfigurasi Jaringan

Jika Anda ingin terhubung ke node lain, tambahkan daftar peer di file konfigurasi:

```json
{
  "node": {
    "host": "0.0.0.0",
    "port": 5000,
    "difficulty": 4,
    "mining_reward": 50,
    "peers": [
      "192.168.1.100:5000",
      "example.com:5000"
    ]
  },
  ...
}
```

## Menjalankan Node

### 1. Menjalankan Node Blockchain

Untuk menjalankan node Ghalbir Blockchain:

```bash
python run_node.py
```

Node akan mulai berjalan dan mendengarkan koneksi pada port yang dikonfigurasi (default: 5000).

### 2. Membuat Wallet

Untuk membuat wallet baru:

```bash
python create_wallet.py
```

Perintah ini akan menghasilkan pasangan kunci publik/privat baru dan menyimpannya dalam file keystore. Simpan kunci privat dengan aman!

### 3. Mining

Untuk memulai proses mining:

```bash
python mine.py --address YOUR_WALLET_ADDRESS
```

Ganti `YOUR_WALLET_ADDRESS` dengan alamat wallet Anda untuk menerima reward mining.

## Menjalankan API MetaMask

Untuk menjalankan API yang kompatibel dengan MetaMask:

```bash
python run_api.py
```

API akan berjalan pada port yang dikonfigurasi (default: 8545).

## Menjalankan Antarmuka Web

### 1. Mode Pengembangan

Untuk menjalankan antarmuka web dalam mode pengembangan:

```bash
cd web
npm run dev
```

Antarmuka web akan tersedia di `http://localhost:8080`.

### 2. Mode Produksi

Untuk membangun dan menjalankan antarmuka web dalam mode produksi:

```bash
cd web
npm run build
npm run start
```

## Pengujian

### 1. Menjalankan Pengujian

Untuk menjalankan semua pengujian:

```bash
python run_tests.py
```

### 2. Pengujian Spesifik

Untuk menjalankan pengujian spesifik:

```bash
python -m unittest tests.test_blockchain
python -m unittest tests.test_integration
```

## Pemecahan Masalah

### 1. Masalah Koneksi

Jika Anda mengalami masalah koneksi ke node:

- Pastikan port tidak diblokir oleh firewall
- Periksa konfigurasi host dan port
- Pastikan node berjalan

### 2. Masalah MetaMask

Jika MetaMask tidak dapat terhubung:

- Pastikan API berjalan pada port 8545
- Tambahkan jaringan kustom di MetaMask dengan URL RPC `http://localhost:8545`
- Gunakan Chain ID 1337

### 3. Log

Untuk melihat log lebih detail, tambahkan flag `--verbose`:

```bash
python run_node.py --verbose
python run_api.py --verbose
```

### 4. Reset Blockchain

Untuk mereset blockchain dan memulai dari awal:

```bash
python reset_blockchain.py
```

Perintah ini akan menghapus semua data blockchain dan memulai dengan blok genesis baru.
