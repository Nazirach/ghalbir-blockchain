# Ghalbir Blockchain - API Reference

## Daftar Isi
1. [Pengenalan](#pengenalan)
2. [JSON-RPC API](#json-rpc-api)
3. [Web3.js Integration](#web3js-integration)
4. [Python API](#python-api)
5. [Contoh Penggunaan](#contoh-penggunaan)

## Pengenalan

Ghalbir Blockchain menyediakan API yang kompatibel dengan Ethereum untuk memudahkan integrasi dengan aplikasi dan tools yang sudah ada. Dokumen ini menjelaskan API yang tersedia dan cara menggunakannya.

## JSON-RPC API

Ghalbir menyediakan JSON-RPC API yang kompatibel dengan Ethereum. API ini berjalan pada port 8545 secara default.

### Endpoint

```
http://localhost:8545
```

### Metode yang Didukung

#### Akun dan Saldo

| Metode | Parameter | Deskripsi |
|--------|-----------|-----------|
| `eth_accounts` | None | Mengembalikan daftar alamat akun |
| `eth_getBalance` | `[address, block_parameter]` | Mendapatkan saldo akun |
| `eth_getTransactionCount` | `[address, block_parameter]` | Mendapatkan jumlah transaksi yang telah dikirim dari alamat |

#### Transaksi

| Metode | Parameter | Deskripsi |
|--------|-----------|-----------|
| `eth_sendTransaction` | `[transaction_object]` | Mengirim transaksi |
| `eth_signTransaction` | `[transaction_object]` | Menandatangani transaksi tanpa mengirimkannya |
| `eth_estimateGas` | `[transaction_object]` | Mengestimasi gas yang dibutuhkan untuk transaksi |
| `eth_getTransactionByHash` | `[transaction_hash]` | Mendapatkan transaksi berdasarkan hash |
| `eth_getTransactionReceipt` | `[transaction_hash]` | Mendapatkan receipt transaksi |

#### Blok

| Metode | Parameter | Deskripsi |
|--------|-----------|-----------|
| `eth_blockNumber` | None | Mendapatkan nomor blok terbaru |
| `eth_getBlockByNumber` | `[block_number, full_transactions]` | Mendapatkan blok berdasarkan nomor |
| `eth_getBlockByHash` | `[block_hash, full_transactions]` | Mendapatkan blok berdasarkan hash |

#### Smart Contract

| Metode | Parameter | Deskripsi |
|--------|-----------|-----------|
| `eth_call` | `[transaction_object, block_parameter]` | Memanggil metode kontrak tanpa membuat transaksi |
| `eth_sendRawTransaction` | `[signed_transaction_data]` | Mengirim transaksi yang sudah ditandatangani |

#### Tanda Tangan

| Metode | Parameter | Deskripsi |
|--------|-----------|-----------|
| `eth_sign` | `[address, data]` | Menandatangani data |
| `personal_sign` | `[data, address, password]` | Menandatangani pesan |

#### Jaringan

| Metode | Parameter | Deskripsi |
|--------|-----------|-----------|
| `net_version` | None | Mendapatkan versi jaringan |
| `eth_chainId` | None | Mendapatkan ID chain |
| `eth_gasPrice` | None | Mendapatkan harga gas saat ini |

### Format Parameter

#### Transaction Object

```json
{
  "from": "0x1234567890123456789012345678901234567890",
  "to": "0x0987654321098765432109876543210987654321",
  "value": "0x64",
  "gas": "0x5208",
  "gasPrice": "0x1",
  "data": "0x",
  "nonce": "0x0"
}
```

#### Block Parameter

- `"latest"`: Blok terbaru
- `"earliest"`: Blok genesis
- `"pending"`: Blok yang sedang di-mining
- `"0x1"`, `"0x2"`, dll.: Nomor blok dalam format hexadecimal

### Contoh Request dan Response

#### Request

```json
{
  "jsonrpc": "2.0",
  "method": "eth_getBalance",
  "params": ["0x1234567890123456789012345678901234567890", "latest"],
  "id": 1
}
```

#### Response

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": "0x3e8"
}
```

## Web3.js Integration

Ghalbir dapat diintegrasikan dengan Web3.js, library JavaScript populer untuk berinteraksi dengan blockchain Ethereum.

### Inisialisasi Web3

```javascript
// Menggunakan HTTP Provider
const web3 = new Web3('http://localhost:8545');

// Atau menggunakan provider dari MetaMask
if (window.ethereum) {
  const web3 = new Web3(window.ethereum);
  try {
    // Request akses ke akun
    await window.ethereum.enable();
  } catch (error) {
    console.error("User denied account access");
  }
}
```

### Contoh Penggunaan Web3.js

```javascript
// Mendapatkan saldo akun
const getBalance = async (address) => {
  const balance = await web3.eth.getBalance(address);
  return web3.utils.fromWei(balance, 'ether');
};

// Mengirim transaksi
const sendTransaction = async (from, to, value) => {
  const tx = {
    from: from,
    to: to,
    value: web3.utils.toWei(value, 'ether')
  };
  
  return await web3.eth.sendTransaction(tx);
};

// Berinteraksi dengan smart contract
const interactWithContract = async (contractAddress, abi, method, params, from) => {
  const contract = new web3.eth.Contract(abi, contractAddress);
  return await contract.methods[method](...params).send({ from });
};
```

## Python API

Ghalbir juga menyediakan API Python untuk berinteraksi dengan blockchain secara langsung dari kode Python.

### Inisialisasi

```python
from ghalbir.core.blockchain import Blockchain
from ghalbir.wallet.wallet import Wallet
from ghalbir.vm.virtual_machine import VirtualMachine

# Inisialisasi blockchain
blockchain = Blockchain()

# Inisialisasi wallet
wallet = Wallet()

# Inisialisasi VM
vm = VirtualMachine(blockchain)
```

### Contoh Penggunaan API Python

```python
# Membuat transaksi
tx = wallet.create_transaction(recipient_address, amount, data)

# Menambahkan transaksi ke blockchain
blockchain.add_transaction(tx)

# Mining
blockchain.mine_pending_transactions(miner_address)

# Mendapatkan saldo
balance = blockchain.get_balance(wallet.address)

# Deploy smart contract
contract_code = {...}  # Kode kontrak yang sudah dikompilasi
result = vm.deploy_contract(contract_code, wallet.address)
contract_address = result['contract_address']

# Memanggil metode kontrak
result = vm.call_contract(
    contract_address,
    "store",
    {"key": "test_key", "value": "test_value"},
    wallet.address
)
```

## Contoh Penggunaan

### Contoh 1: Mengirim Transaksi dengan curl

```bash
curl -X POST --data '{
  "jsonrpc": "2.0",
  "method": "eth_sendTransaction",
  "params": [{
    "from": "0x1234567890123456789012345678901234567890",
    "to": "0x0987654321098765432109876543210987654321",
    "value": "0x64"
  }],
  "id": 1
}' -H "Content-Type: application/json" http://localhost:8545
```

### Contoh 2: Mendapatkan Saldo dengan Web3.js

```javascript
const Web3 = require('web3');
const web3 = new Web3('http://localhost:8545');

async function getAccountBalance(address) {
  try {
    const balance = await web3.eth.getBalance(address);
    console.log(`Balance: ${web3.utils.fromWei(balance, 'ether')} GBR`);
  } catch (error) {
    console.error('Error:', error);
  }
}

getAccountBalance('0x1234567890123456789012345678901234567890');
```

### Contoh 3: Deploy Smart Contract dengan Python

```python
from ghalbir.wallet.wallet import Wallet
from ghalbir.core.blockchain import Blockchain
from ghalbir.vm.virtual_machine import VirtualMachine
from ghalbir.vm.compiler import ContractCompiler

# Inisialisasi
blockchain = Blockchain()
wallet = Wallet()
vm = VirtualMachine(blockchain)
compiler = ContractCompiler()

# Tambahkan saldo ke wallet
blockchain.accounts[wallet.address] = 1000

# Kompilasi kontrak
contract_code = """
contract SimpleStorage {
  function store(key, value) {
    store(key, value)
  }
  
  function get(key) {
    get(key)
  }
}
"""

compiled_code = compiler.compile(contract_code)

# Deploy kontrak
result = vm.deploy_contract(compiled_code, wallet.address)
contract_address = result['contract_address']
print(f"Contract deployed at: {contract_address}")

# Panggil metode kontrak
store_result = vm.call_contract(
    contract_address,
    "store",
    {"key": "test_key", "value": "test_value"},
    wallet.address
)
print(f"Store result: {store_result}")

get_result = vm.call_contract(
    contract_address,
    "get",
    {"key": "test_key"},
    wallet.address
)
print(f"Get result: {get_result}")
```
