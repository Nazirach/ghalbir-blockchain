// Ghalbir Blockchain Web Interface

// Global variables
let web3;
let currentAccount;
let ghalbir;
let isMetaMaskConnected = false;

// DOM Elements
const alertContainer = document.getElementById('alert-container');
const sections = {
    dashboard: document.getElementById('dashboard-section'),
    wallet: document.getElementById('wallet-section'),
    transactions: document.getElementById('transactions-section'),
    contracts: document.getElementById('contracts-section'),
    explorer: document.getElementById('explorer-section')
};

// Navigation
document.getElementById('nav-dashboard').addEventListener('click', (e) => {
    e.preventDefault();
    showSection('dashboard');
});

document.getElementById('nav-wallet').addEventListener('click', (e) => {
    e.preventDefault();
    showSection('wallet');
});

document.getElementById('nav-transactions').addEventListener('click', (e) => {
    e.preventDefault();
    showSection('transactions');
});

document.getElementById('nav-contracts').addEventListener('click', (e) => {
    e.preventDefault();
    showSection('contracts');
});

document.getElementById('nav-explorer').addEventListener('click', (e) => {
    e.preventDefault();
    showSection('explorer');
});

// Show section and hide others
function showSection(sectionName) {
    for (const [name, section] of Object.entries(sections)) {
        section.style.display = name === sectionName ? 'block' : 'none';
    }
    
    // Update data for the selected section
    if (sectionName === 'dashboard') {
        updateDashboard();
    } else if (sectionName === 'wallet') {
        updateWalletSection();
    } else if (sectionName === 'explorer') {
        loadRecentBlocks();
    }
}

// Initialize the application
async function init() {
    try {
        // Check if MetaMask is installed
        if (window.ethereum) {
            // Create Web3 instance
            web3 = new Web3(window.ethereum);
            
            // Setup event listeners for MetaMask
            window.ethereum.on('accountsChanged', handleAccountsChanged);
            window.ethereum.on('chainChanged', () => window.location.reload());
            
            // Check if already connected
            const accounts = await web3.eth.getAccounts();
            if (accounts.length > 0) {
                handleAccountsChanged(accounts);
            }
        } else {
            showAlert('MetaMask tidak terdeteksi. Silakan instal MetaMask untuk pengalaman terbaik.', 'warning');
        }
        
        // Initialize Ghalbir API connection
        initGhalbirConnection();
        
        // Load initial data
        updateDashboard();
        
        // Setup event listeners
        document.getElementById('connect-metamask').addEventListener('click', connectMetaMask);
        document.getElementById('create-wallet').addEventListener('click', createWallet);
        document.getElementById('send-transaction').addEventListener('click', () => showSection('wallet'));
        document.getElementById('transaction-form').addEventListener('submit', sendTransaction);
        document.getElementById('search-transaction-form').addEventListener('submit', searchTransaction);
        document.getElementById('deploy-contract-form').addEventListener('submit', deployContract);
        document.getElementById('interact-contract-form').addEventListener('submit', interactWithContract);
        document.getElementById('search-block-form').addEventListener('submit', searchBlock);
        
    } catch (error) {
        console.error('Initialization error:', error);
        showAlert('Terjadi kesalahan saat inisialisasi aplikasi.', 'danger');
    }
}

// Initialize connection to Ghalbir API
function initGhalbirConnection() {
    // In a real implementation, this would connect to the Ghalbir JSON-RPC API
    // For this example, we'll create a simple mock
    ghalbir = {
        getLatestBlock: async () => {
            return {
                number: 1234,
                hash: '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef',
                difficulty: 4,
                transactions: []
            };
        },
        getTransactionCount: async () => {
            return 42;
        },
        getRecentTransactions: async () => {
            return [
                {
                    hash: '0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890',
                    from: '0x1234567890123456789012345678901234567890',
                    to: '0x0987654321098765432109876543210987654321',
                    value: 10,
                    timestamp: Date.now() - 60000
                },
                {
                    hash: '0x9876543210abcdef9876543210abcdef9876543210abcdef9876543210abcdef',
                    from: '0x0987654321098765432109876543210987654321',
                    to: '0x1234567890123456789012345678901234567890',
                    value: 5,
                    timestamp: Date.now() - 120000
                }
            ];
        },
        getBalance: async (address) => {
            return 100;
        },
        getWalletTransactions: async (address) => {
            return [
                {
                    hash: '0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890',
                    from: address,
                    to: '0x0987654321098765432109876543210987654321',
                    value: 10,
                    timestamp: Date.now() - 60000
                }
            ];
        },
        getTransaction: async (hash) => {
            return {
                hash: hash,
                from: '0x1234567890123456789012345678901234567890',
                to: '0x0987654321098765432109876543210987654321',
                value: 10,
                gas: 21000,
                gasPrice: 1,
                nonce: 0,
                data: '',
                timestamp: Date.now() - 60000,
                blockNumber: 1234,
                blockHash: '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'
            };
        },
        sendTransaction: async (tx) => {
            return {
                success: true,
                hash: '0x' + Math.random().toString(16).substring(2) + Math.random().toString(16).substring(2)
            };
        },
        deployContract: async (code, sender, gasLimit) => {
            return {
                success: true,
                contractAddress: '0x' + Math.random().toString(16).substring(2) + Math.random().toString(16).substring(2)
            };
        },
        callContract: async (address, method, params, sender, value) => {
            return {
                success: true,
                result: { value: 42 }
            };
        },
        getBlock: async (number) => {
            return {
                number: number,
                hash: '0x' + Math.random().toString(16).substring(2) + Math.random().toString(16).substring(2),
                previousHash: '0x' + Math.random().toString(16).substring(2) + Math.random().toString(16).substring(2),
                timestamp: Date.now() - number * 15000,
                difficulty: 4,
                nonce: 12345,
                transactions: []
            };
        },
        getRecentBlocks: async () => {
            const blocks = [];
            for (let i = 0; i < 5; i++) {
                blocks.push({
                    number: 1234 - i,
                    hash: '0x' + Math.random().toString(16).substring(2) + Math.random().toString(16).substring(2),
                    timestamp: Date.now() - i * 15000,
                    transactions: []
                });
            }
            return blocks;
        }
    };
}

// Connect to MetaMask
async function connectMetaMask() {
    try {
        if (!window.ethereum) {
            showAlert('MetaMask tidak terdeteksi. Silakan instal MetaMask terlebih dahulu.', 'warning');
            return;
        }
        
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        handleAccountsChanged(accounts);
        showAlert('Berhasil terhubung dengan MetaMask!', 'success');
    } catch (error) {
        console.error('MetaMask connection error:', error);
        showAlert('Gagal terhubung dengan MetaMask.', 'danger');
    }
}

// Handle account changes in MetaMask
function handleAccountsChanged(accounts) {
    if (accounts.length === 0) {
        // MetaMask is locked or user has no accounts
        currentAccount = null;
        isMetaMaskConnected = false;
        document.getElementById('wallet-status').style.display = 'block';
        document.getElementById('wallet-info').style.display = 'none';
    } else {
        // Update current account
        currentAccount = accounts[0];
        isMetaMaskConnected = true;
        document.getElementById('wallet-status').style.display = 'none';
        document.getElementById('wallet-info').style.display = 'block';
        document.getElementById('wallet-address').textContent = currentAccount;
        document.getElementById('wallet-address-details').textContent = currentAccount;
        
        // Update wallet balance
        updateWalletBalance();
    }
}

// Create a new wallet
function createWallet() {
    try {
        // In a real implementation, this would create a new wallet
        // For this example, we'll simulate it
        const newWallet = {
            address: '0x' + Math.random().toString(16).substring(2, 42),
            privateKey: '0x' + Math.random().toString(16).substring(2, 66)
        };
        
        currentAccount = newWallet.address;
        isMetaMaskConnected = false;
        
        document.getElementById('wallet-status').style.display = 'none';
        document.getElementById('wallet-info').style.display = 'block';
        document.getElementById('wallet-address').textContent = currentAccount;
        document.getElementById('wallet-address-details').textContent = currentAccount;
        
        // Update wallet balance
        updateWalletBalance();
        
        showAlert('Wallet baru berhasil dibuat! Alamat: ' + currentAccount, 'success');
        
        // Show private key warning
        const privateKeyWarning = `
            <div class="alert alert-warning">
                <strong>Peringatan!</strong> Simpan kunci privat Anda dengan aman:
                <code>${newWallet.privateKey}</code>
                <br>
                Jangan pernah membagikan kunci privat Anda kepada siapapun!
            </div>
        `;
        alertContainer.innerHTML += privateKeyWarning;
    } catch (error) {
        console.error('Wallet creation error:', error);
        showAlert('Gagal membuat wallet baru.', 'danger');
    }
}

// Update wallet balance
async function updateWalletBalance() {
    if (!currentAccount) return;
    
    try {
        const balance = await ghalbir.getBalance(currentAccount);
        document.getElementById('wallet-balance').textContent = `${balance} GBR`;
        document.getElementById('wallet-balance-details').textContent = `${balance} GBR`;
    } catch (error) {
        console.error('Balance update error:', error);
    }
}

// Update dashboard data
async function updateDashboard() {
    try {
        // Get latest block
        const latestBlock = await ghalbir.getLatestBlock();
        document.getElementById('latest-block-number').textContent = latestBlock.number;
        document.getElementById('latest-block-hash').textContent = latestBlock.hash;
        document.getElementById('difficulty').textContent = latestBlock.difficulty;
        
        // Get transaction count
        const txCount = await ghalbir.getTransactionCount();
        document.getElementById('transaction-count').textContent = txCount;
        
        // Get recent transactions
        const recentTxs = await ghalbir.getRecentTransactions();
        const txList = document.getElementById('recent-transactions');
        txList.innerHTML = '';
        
        if (recentTxs.length === 0) {
            txList.innerHTML = '<li class="transaction-item">Tidak ada transaksi.</li>';
        } else {
            recentTxs.forEach(tx => {
                const txItem = document.createElement('li');
                txItem.className = 'transaction-item';
                txItem.innerHTML = `
                    <div class="transaction-hash">${tx.hash}</div>
                    <div class="transaction-amount">${tx.value} GBR</div>
                    <div class="transaction-addresses">
                        Dari: ${tx.from}<br>
                        Ke: ${tx.to}
                    </div>
                    <div class="transaction-time">${new Date(tx.timestamp).toLocaleString()}</div>
                `;
                txList.appendChild(txItem);
            });
        }
        
        // Update wallet balance if connected
        if (currentAccount) {
            updateWalletBalance();
        }
    } catch (error) {
        console.error('Dashboard update error:', error);
        showAlert('Gagal memperbarui data dashboard.', 'danger');
    }
}

// Update wallet section
async function updateWalletSection() {
    if (!currentAccount) return;
    
    try {
        // Update wallet balance
        await updateWalletBalance();
        
        // Get wallet transactions
        const walletTxs = await ghalbir.getWalletTransactions(currentAccount);
        const txList = document.getElementById('wallet-transactions');
        txList.innerHTML = '';
        
        if (walletTxs.length === 0) {
            txList.innerHTML = '<li class="transaction-item">Tidak ada transaksi.</li>';
        } else {
            walletTxs.forEach(tx => {
                const txItem = document.createElement('li');
                txItem.className = 'transaction-item';
                txItem.innerHTML = `
                    <div class="transaction-hash">${tx.hash}</div>
                    <div class="transaction-amount">${tx.value} GBR</div>
                    <div class="transaction-addresses">
                        Dari: ${tx.from}<br>
                        Ke: ${tx.to}
                    </div>
                    <div class="transaction-time">${new Date(tx.timestamp).toLocaleString()}</div>
                `;
                txList.appendChild(txItem);
            });
        }
        
        // Update transaction count
        document.getElementById('wallet-transaction-count').textContent = walletTxs.length;
    } catch (error) {
        console.error('Wallet section update error:', error);
        showAlert('Gagal memperbarui data wallet.', 'danger');
    }
}

// Send transaction
async function sendTransaction(e) {
    e.preventDefault();
    
    if (!currentAccount) {
        showAlert('Silakan hubungkan wallet terlebih dahulu.', 'warning');
        return;
    }
    
    try {
        const recipient = document.getElementById('tx-recipient').value;
        const amount = parseFloat(document.getElementById('tx-amount').value);
        const data = document.getElementById('tx-data').value;
        const gasPrice = parseInt(document.getElementById('tx-gas-price').value);
        const gasLimit = parseInt(document.getElementById('tx-gas-limit').value);
        
        if (!recipient || isNaN(amount) || amount <= 0) {
            showAlert('Silakan isi alamat penerima dan jumlah dengan benar.', 'warning');
            return;
        }
        
        // Create transaction object
        const tx = {
            from: currentAccount,
            to: recipient,
            value: amount,
            data: data,
            gasPrice: gasPrice,
            gasLimit: gasLimit
        };
        
        // Send transaction
        const result = await ghalbir.sendTransaction(tx);
        
        if (result.success) {
            showAlert(`Transaksi berhasil dikirim! Hash: ${result.hash}`, 'success');
            
            // Reset form
            document.getElementById('transaction-form').reset();
            
            // Update wallet section
            updateWalletSection();
            
            // Update dashboard
            updateDashboard();
        } else {
            showAlert('Gagal mengirim transaksi: ' + result.error, 'danger');
        }
    } catch (error) {
        console.error('Transaction error:', error);
        showAlert('Gagal mengirim transaksi.', 'danger');
    }
}

// Search transaction
async function searchTransaction(e) {
    e.preventDefault();
    
    try {
        const txHash = document.getElementById('transaction-hash').value;
        
        if (!txHash) {
            showAlert('Silakan masukkan hash transaksi.', 'warning');
            return;
        }
        
        // Get transaction details
        const tx = await ghalbir.getTransaction(txHash);
        
        if (!tx) {
            showAlert('Transaksi tidak ditemukan.', 'warning');
            return;
        }
        
        // Display transaction details
        const txDetails = document.getElementById('transaction-details');
        txDetails.innerHTML = `
            <div class="form-group">
                <label>Hash:</label>
                <div class="transaction-hash">${tx.hash}</div>
            </div>
            <div class="form-group">
                <label>Dari:</label>
                <div>${tx.from}</div>
            </div>
            <div class="form-group">
                <label>Ke:</label>
                <div>${tx.to}</div>
            </div>
            <div class="form-group">
                <label>Nilai:</label>
                <div>${tx.value} GBR</div>
            </div>
            <div class="form-group">
                <label>Gas:</label>
                <div>${tx.gas}</div>
            </div>
            <div class="form-group">
                <label>Harga Gas:</label>
                <div>${tx.gasPrice}</div>
            </div>
            <div class="form-group">
                <label>Nonce:</label>
                <div>${tx.nonce}</div>
            </div>
            <div class="form-group">
                <label>Data:</label>
                <div class="contract-code">${tx.data || '(tidak ada data)'}</div>
            </div>
            <div class="form-group">
                <label>Waktu:</label>
                <div>${new Date(tx.timestamp).toLocaleString()}</div>
            </div>
            <div class="form-group">
                <label>Blok:</label>
                <div>${tx.blockNumber} (${tx.blockHash})</div>
            </div>
        `;
    } catch (error) {
        console.error('Transaction search error:', error);
        showAlert('Gagal mencari transaksi.', 'danger');
    }
}

// Deploy contract
async function deployContract(e) {
    e.preventDefault();
    
    if (!currentAccount) {
        showAlert('Silakan hubungkan wallet terlebih dahulu.', 'warning');
        return;
    }
    
    try {
        const code = document.getElementById('contract-code').value;
        const gasLimit = parseInt(document.getElementById('contract-gas-limit').value);
        
        if (!code) {
            showAlert('Silakan masukkan kode kontrak.', 'warning');
            return;
        }
        
        // Show loading
        document.getElementById('contract-result').innerHTML = `
            <div class="loading">
                <div class="spinner"></div>
                <p>Deploying contract...</p>
            </div>
        `;
        
        // Deploy contract
        const result = await ghalbir.deployContract(code, currentAccount, gasLimit);
        
        if (result.success) {
            document.getElementById('contract-result').innerHTML = `
                <div class="alert alert-success">
                    Kontrak berhasil di-deploy!
                </div>
                <div class="form-group">
                    <label>Alamat Kontrak:</label>
                    <div class="wallet-address">${result.contractAddress}</div>
                </div>
            `;
            
            // Update contract address field
            document.getElementById('contract-address').value = result.contractAddress;
            
            // Update dashboard
            updateDashboard();
        } else {
            document.getElementById('contract-result').innerHTML = `
                <div class="alert alert-danger">
                    Gagal men-deploy kontrak: ${result.error}
                </div>
            `;
        }
    } catch (error) {
        console.error('Contract deployment error:', error);
        document.getElementById('contract-result').innerHTML = `
            <div class="alert alert-danger">
                Gagal men-deploy kontrak: ${error.message}
            </div>
        `;
    }
}

// Interact with contract
async function interactWithContract(e) {
    e.preventDefault();
    
    if (!currentAccount) {
        showAlert('Silakan hubungkan wallet terlebih dahulu.', 'warning');
        return;
    }
    
    try {
        const contractAddress = document.getElementById('contract-address').value;
        const method = document.getElementById('contract-method').value;
        const paramsStr = document.getElementById('contract-params').value;
        const value = parseFloat(document.getElementById('contract-value').value);
        
        if (!contractAddress || !method) {
            showAlert('Silakan masukkan alamat kontrak dan metode.', 'warning');
            return;
        }
        
        // Parse parameters
        let params = {};
        if (paramsStr) {
            try {
                params = JSON.parse(paramsStr);
            } catch (e) {
                showAlert('Format parameter tidak valid. Gunakan format JSON.', 'warning');
                return;
            }
        }
        
        // Show loading
        document.getElementById('contract-result').innerHTML = `
            <div class="loading">
                <div class="spinner"></div>
                <p>Memanggil kontrak...</p>
            </div>
        `;
        
        // Call contract
        const result = await ghalbir.callContract(contractAddress, method, params, currentAccount, value);
        
        if (result.success) {
            document.getElementById('contract-result').innerHTML = `
                <div class="alert alert-success">
                    Kontrak berhasil dipanggil!
                </div>
                <div class="form-group">
                    <label>Hasil:</label>
                    <pre>${JSON.stringify(result.result, null, 2)}</pre>
                </div>
            `;
            
            // Update dashboard
            updateDashboard();
        } else {
            document.getElementById('contract-result').innerHTML = `
                <div class="alert alert-danger">
                    Gagal memanggil kontrak: ${result.error}
                </div>
            `;
        }
    } catch (error) {
        console.error('Contract interaction error:', error);
        document.getElementById('contract-result').innerHTML = `
            <div class="alert alert-danger">
                Gagal memanggil kontrak: ${error.message}
            </div>
        `;
    }
}

// Search block
async function searchBlock(e) {
    e.preventDefault();
    
    try {
        const blockNumber = parseInt(document.getElementById('block-number').value);
        
        if (isNaN(blockNumber) || blockNumber < 0) {
            showAlert('Silakan masukkan nomor blok yang valid.', 'warning');
            return;
        }
        
        // Get block details
        const block = await ghalbir.getBlock(blockNumber);
        
        if (!block) {
            showAlert('Blok tidak ditemukan.', 'warning');
            return;
        }
        
        // Display block details
        const blockDetails = document.getElementById('block-details');
        blockDetails.innerHTML = `
            <div class="form-group">
                <label>Nomor Blok:</label>
                <div>${block.number}</div>
            </div>
            <div class="form-group">
                <label>Hash:</label>
                <div class="block-hash">${block.hash}</div>
            </div>
            <div class="form-group">
                <label>Hash Blok Sebelumnya:</label>
                <div class="block-hash">${block.previousHash}</div>
            </div>
            <div class="form-group">
                <label>Waktu:</label>
                <div>${new Date(block.timestamp).toLocaleString()}</div>
            </div>
            <div class="form-group">
                <label>Tingkat Kesulitan:</label>
                <div>${block.difficulty}</div>
            </div>
            <div class="form-group">
                <label>Nonce:</label>
                <div>${block.nonce}</div>
            </div>
            <div class="form-group">
                <label>Jumlah Transaksi:</label>
                <div>${block.transactions.length}</div>
            </div>
        `;
        
        if (block.transactions.length > 0) {
            blockDetails.innerHTML += `
                <div class="form-group">
                    <label>Transaksi:</label>
                    <ul class="transaction-list">
                        ${block.transactions.map(tx => `
                            <li class="transaction-item">
                                <div class="transaction-hash">${tx.hash}</div>
                                <div class="transaction-amount">${tx.value} GBR</div>
                                <div class="transaction-addresses">
                                    Dari: ${tx.from}<br>
                                    Ke: ${tx.to}
                                </div>
                            </li>
                        `).join('')}
                    </ul>
                </div>
            `;
        }
    } catch (error) {
        console.error('Block search error:', error);
        showAlert('Gagal mencari blok.', 'danger');
    }
}

// Load recent blocks
async function loadRecentBlocks() {
    try {
        const blocks = await ghalbir.getRecentBlocks();
        const blocksList = document.getElementById('recent-blocks');
        blocksList.innerHTML = '';
        
        if (blocks.length === 0) {
            blocksList.innerHTML = '<li class="transaction-item">Tidak ada blok.</li>';
        } else {
            blocks.forEach(block => {
                const blockItem = document.createElement('li');
                blockItem.className = 'transaction-item';
                blockItem.innerHTML = `
                    <div class="block-info">
                        <span class="block-number">Blok #${block.number}</span>
                        <span>${new Date(block.timestamp).toLocaleString()}</span>
                    </div>
                    <div class="block-hash">${block.hash}</div>
                    <div>Transaksi: ${block.transactions.length}</div>
                `;
                blocksList.appendChild(blockItem);
            });
        }
    } catch (error) {
        console.error('Recent blocks loading error:', error);
        showAlert('Gagal memuat blok terbaru.', 'danger');
    }
}

// Show alert message
function showAlert(message, type) {
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.innerHTML = message;
    
    alertContainer.innerHTML = '';
    alertContainer.appendChild(alert);
    
    // Auto-remove alert after 5 seconds
    setTimeout(() => {
        alert.remove();
    }, 5000);
}

// Initialize the application when the DOM is loaded
document.addEventListener('DOMContentLoaded', init);
