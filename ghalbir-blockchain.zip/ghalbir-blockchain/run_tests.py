#!/usr/bin/env python3

import unittest
import sys
import os

# Tambahkan direktori root ke path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Import test suite
from tests.test_blockchain import TestGhalbirBlockchain
from tests.test_integration import TestIntegration

if __name__ == '__main__':
    # Buat test loader
    loader = unittest.TestLoader()
    
    # Buat test suite
    test_suite = unittest.TestSuite()
    
    # Tambahkan test case ke test suite
    test_suite.addTest(loader.loadTestsFromTestCase(TestGhalbirBlockchain))
    test_suite.addTest(loader.loadTestsFromTestCase(TestIntegration))
    
    # Buat test runner
    runner = unittest.TextTestRunner(verbosity=2)
    
    # Jalankan test
    result = runner.run(test_suite)
    
    # Keluar dengan kode status sesuai hasil test
    sys.exit(not result.wasSuccessful())
